import bcrypt from "bcryptjs";

// This is a simple in-memory session-based data store for the demo.
// In a real application, this would be a SQL database with parameterized queries.

export interface User {
  id: string;
  email: string;
  password: string; // Hashed
  role: 'patient' | 'hospital' | 'admin';
  name: string;
}

export interface PatientProfile {
  id: string;
  userId: string;
  name: string;
  dob: string;
  bloodGroup: string;
  phone: string;
  emergency: string;
  allergies: string;
}

export interface TransferRequest {
  id: string;
  patientId: string;
  from: string;
  to: string;
  status: 'Pending' | 'In Transit' | 'Received' | 'Verified' | 'Rejected';
  date: string;
  patientName: string;
  records: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  hospitalId: string;
  patientName: string;
  doctorName: string;
  dept: string;
  date: string;
  time: string;
  reason: string;
  status: 'Pending' | 'Confirmed' | 'Completed' | 'Cancelled';
}

class Database {
  private users: User[] = [
    { id: "HOSP001", email: "HOSP001", password: bcrypt.hashSync("hospital123", 10), role: "hospital", name: "KR Hospital" },
    { id: "HOSP002", email: "HOSP002", password: bcrypt.hashSync("hospital123", 10), role: "hospital", name: "JSS Hospital" },
    { id: "PT-VIN-001", email: "vinaym200746@gmail.com", password: bcrypt.hashSync("patient123", 10), role: "patient", name: "Vinay M." },
    { id: "PT-MYS-001", email: "patient@mail.com", password: bcrypt.hashSync("patient123", 10), role: "patient", name: "Basavaraju M." },
    { id: "ADMIN001", email: "admin@medireach.gov.in", password: bcrypt.hashSync("admin123", 10), role: "admin", name: "System Admin" }
  ];

  private profiles: PatientProfile[] = [
    {
      id: "PROF-VIN-001",
      userId: "PT-VIN-001",
      name: "Vinay M.",
      dob: "1985-06-15",
      bloodGroup: "O+",
      phone: "9845000000",
      emergency: "9886000000",
      allergies: "None"
    },
    {
      id: "PROF001",
      userId: "PT-MYS-001",
      name: "Basavaraju M.",
      dob: "1985-06-15",
      bloodGroup: "B+",
      phone: "9845012345",
      emergency: "9886054321",
      allergies: "None"
    }
  ];

  private transfers: TransferRequest[] = [];
  
  private appointments: Appointment[] = [
    { id: 'APT-101', patientId: 'PT-MYS-001', hospitalId: 'HOSP001', patientName: 'Basavaraju M.', doctorName: 'Dr. Ramesh Rao', dept: 'Cardiology', date: '2026-04-25', time: '10:30 AM', reason: 'Routine Checkup', status: 'Pending' }
  ];

  // Secured Data Access Layer (Simulating Parameterized Queries)
  
  findUserByEmail(email: string) {
    // Sanitized search
    return this.users.find(u => u.email.toUpperCase() === email.toUpperCase());
  }

  getPatientProfile(userId: string) {
    // Enforces user restriction
    return this.profiles.find(p => p.userId === userId);
  }

  updatePatientProfile(userId: string, data: Partial<PatientProfile>) {
    const idx = this.profiles.findIndex(p => p.userId === userId);
    if (idx !== -1) {
      // Prevent ID spoofing
      const { id, userId: targetUserId, ...safeData } = data;
      this.profiles[idx] = { ...this.profiles[idx], ...safeData };
      return this.profiles[idx];
    }
    return null;
  }

  getTransfersForPatient(userId: string) {
    return this.transfers.filter(t => t.patientId === userId);
  }

  getTransfersForHospital(hospitalId: string, hospitalName: string) {
    // Hospital can only see transfers intended for them
    return this.transfers.filter(t => t.to === hospitalName);
  }

  addTransfer(transfer: TransferRequest) {
    this.transfers.push(transfer);
    return transfer;
  }

  addAppointment(appointment: Appointment) {
    this.appointments.push(appointment);
    return appointment;
  }

  updateTransferStatus(transferId: string, status: TransferRequest['status']) {
    const t = this.transfers.find(trn => trn.id === transferId);
    if (t) {
      t.status = status;
      return t;
    }
    return null;
  }

  getAppointmentsForPatient(userId: string) {
    return this.appointments.filter(a => a.patientId === userId);
  }

  getAppointmentsForHospital(hospitalId: string) {
    return this.appointments.filter(a => a.hospitalId === hospitalId);
  }

  updateAppointmentStatus(id: string, status: Appointment['status']) {
    const a = this.appointments.find(apt => apt.id === id);
    if (a) {
      a.status = status;
      return a;
    }
    return null;
  }

  getPatientsByHospital(hospitalId: string) {
    // Return unique patients who have appointments at this hospital
    const patientIds = new Set(this.appointments.filter(a => a.hospitalId === hospitalId).map(a => a.patientId));
    return this.profiles.filter(p => patientIds.has(p.userId));
  }
}

export const db = new Database();
