import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Menu, X, Home, Search, MapPin, User, BarChart3, Pill, ShieldCheck, ClipboardList, Stethoscope, AlertTriangle, Truck, Globe, HeartPulse } from 'lucide-react';
import { cn } from '../lib/utils';
import { useLanguage, TranslationKey } from '../contexts/LanguageContext';

interface NavItem {
  labelKey: TranslationKey;
  id: string;
  icon: React.ReactNode;
}

const navItems: NavItem[] = [
  { labelKey: 'home', id: 'home', icon: <Home className="w-4 h-4" /> },
  { labelKey: 'findHospitals', id: 'hospitals', icon: <Search className="w-4 h-4" /> },
  { labelKey: 'ambulance', id: 'ambulance', icon: <Truck className="w-4 h-4" /> },
  { labelKey: 'doctors', id: 'doctors', icon: <Stethoscope className="w-4 h-4" /> },
  { labelKey: 'symptomCheck', id: 'symptoms', icon: <AlertTriangle className="w-4 h-4" /> },
  { labelKey: 'compare', id: 'compare', icon: <BarChart3 className="w-4 h-4" /> },
  { labelKey: 'medicines', id: 'medicines', icon: <Pill className="w-4 h-4" /> },
  { labelKey: 'insurance', id: 'insurance', icon: <ShieldCheck className="w-4 h-4" /> },
  { labelKey: 'specialServices', id: 'special_services', icon: <HeartPulse className="w-4 h-4" /> },
  { labelKey: 'myRecords', id: 'records', icon: <ClipboardList className="w-4 h-4" /> },
];

interface NavbarProps {
  activeTab: string;
  setActiveTab: (id: string) => void;
  user: { role: 'patient' | 'hospital', name: string, id: string } | null;
  onLogout: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab, user, onLogout }) => {
  const [isOpen, setIsOpen] = useState(false);
  const { t, language, setLanguage } = useLanguage();

  const initials = (user?.name || 'Guest')
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <nav className="bg-white border-b border-slate-200 sticky top-10 md:top-8 z-40">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex justify-between items-center h-16">
          <div 
            className="flex items-center gap-2 cursor-pointer group" 
            onClick={() => setActiveTab('home')}
          >
            <div className="w-8 h-8 bg-[#0d9e6e] rounded-lg flex items-center justify-center text-white font-bold transition-transform group-hover:scale-105">M</div>
            <span className="text-xl font-bold text-slate-800 tracking-tight font-display">
              MediReach <span className="text-[#0d9e6e]">Karnataka</span>
            </span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center space-x-6 h-16">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={cn(
                  "flex items-center gap-1.5 h-16 px-1 text-sm font-medium transition-all relative group",
                  activeTab === item.id 
                    ? "text-[#0d9e6e]" 
                    : "text-slate-600 hover:text-[#0d9e6e]"
                )}
              >
                {t(item.labelKey)}
                {activeTab === item.id && (
                  <motion.div 
                    layoutId="activeTab"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#0d9e6e]"
                  />
                )}
              </button>
            ))}
            {user?.role === 'hospital' && (
              <button
                onClick={() => setActiveTab('hospital-dashboard')}
                className={cn(
                  "flex items-center gap-1.5 h-16 px-1 text-sm font-medium transition-all relative group",
                  activeTab === 'hospital-dashboard' 
                    ? "text-[#0d9e6e]" 
                    : "text-slate-600 hover:text-[#0d9e6e]"
                )}
              >
                {t('hospitalDashboard')}
                {activeTab === 'hospital-dashboard' && (
                  <motion.div 
                    layoutId="activeTab"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#0d9e6e]"
                  />
                )}
              </button>
            )}
          </div>

          <div className="flex items-center gap-4 lg:gap-6">
            {/* Language Selector */}
            <div className="flex items-center bg-slate-100 rounded-lg p-1 mr-2 md:mr-0">
              <button
                onClick={() => setLanguage('en')}
                className={cn(
                  "px-2 py-1 text-[10px] font-black rounded-md transition-all",
                  language === 'en' ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-700"
                )}
              >
                EN
              </button>
              <button
                onClick={() => setLanguage('kn')}
                className={cn(
                  "px-2 py-1 text-[10px] font-black rounded-md transition-all",
                  language === 'kn' ? "bg-white text-slate-800 shadow-sm" : "text-slate-500 hover:text-slate-700"
                )}
              >
                ಕನ್ನಡ
              </button>
            </div>

            {user ? (
               <div className="hidden md:flex items-center gap-3">
                <div className="text-right hidden sm:block">
                  <p className="text-xs font-bold text-slate-800">{user.name}</p>
                  <p className="text-[10px] text-slate-500">{user.id}</p>
                </div>
                <div 
                  onClick={onLogout}
                  className="w-10 h-10 rounded-full bg-slate-100 border-2 border-white shadow-sm flex items-center justify-center text-slate-500 font-bold overflow-hidden cursor-pointer hover:border-red-500 hover:text-red-500 transition-colors group relative"
                  title={t('logout')}
                >
                  <span className="text-xs group-hover:hidden">{initials}</span>
                  <LogOut className="w-5 h-5 hidden group-hover:block" />
                </div>
              </div>
            ) : (
              <button 
                onClick={() => setActiveTab('login')}
                className="hidden md:block px-6 py-2 bg-[#0d9e6e] text-white rounded-xl text-xs font-black uppercase tracking-widest hover:shadow-lg hover:shadow-[#0d9e6e]/20 transition-all"
              >
                {t('login')}
              </button>
            )}

            {/* Mobile menu button */}
            <div className="lg:hidden flex items-center">
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="text-gray-500 hover:text-gray-600 p-2"
              >
                {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      {isOpen && (
        <div className="lg:hidden bg-white border-t border-gray-100 py-2 animate-in slide-in-from-top duration-300">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                setIsOpen(false);
              }}
              className={cn(
                "flex items-center gap-3 w-full px-4 py-3 text-left text-base font-medium",
                activeTab === item.id ? "text-[#0d9e6e] bg-[#0d9e6e]/5" : "text-gray-600"
              )}
            >
              {item.icon}
              {t(item.labelKey)}
            </button>
          ))}
          {user?.role === 'hospital' && (
             <button
              onClick={() => {
                setActiveTab('hospital-dashboard');
                setIsOpen(false);
              }}
              className={cn(
                "flex items-center gap-3 w-full px-4 py-3 text-left text-base font-medium",
                activeTab === 'hospital-dashboard' ? "text-[#0d9e6e] bg-[#0d9e6e]/5" : "text-gray-600"
              )}
            >
              <User className="w-4 h-4" />
              {t('hospitalDashboard')}
            </button>
          )}
          <div className="p-4 border-t border-gray-100 flex gap-4">
            {user ? (
               <button 
                 onClick={() => { onLogout(); setIsOpen(false); }}
                 className="flex-1 bg-red-50 text-red-600 py-3 rounded-xl font-black uppercase tracking-widest text-xs"
               >
                 {t('logout')}
               </button>
            ) : (
               <>
                <button onClick={() => { setActiveTab('login'); setIsOpen(false); }} className="flex-1 bg-[#0d9e6e] text-white py-3 rounded-lg font-semibold">{t('login')}</button>
                <button className="flex-1 bg-gray-100 text-gray-700 py-3 rounded-lg font-semibold">{t('signup')}</button>
               </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

import { LogOut } from 'lucide-react';

