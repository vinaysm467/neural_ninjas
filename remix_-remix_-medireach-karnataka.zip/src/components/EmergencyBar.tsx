import React from 'react';
import { Phone, AlertTriangle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface EmergencyBarProps {
  onFindAmbulance: () => void;
}

export const EmergencyBar: React.FC<EmergencyBarProps> = ({ onFindAmbulance }) => {
  const { t } = useLanguage();
  
  return (
    <div className="h-10 md:h-8 bg-[#dc2626] text-white flex items-center justify-center text-[10px] md:text-xs font-bold tracking-wide uppercase px-4 z-50 shrink-0 sticky top-0">
      <div className="flex items-center gap-4 md:gap-8">
        <span className="flex items-center gap-2">
          <AlertTriangle className="w-3 h-3" />
          {t('emergencyText')}
        </span>
        <div className="flex items-center gap-4">
          <button 
            onClick={onFindAmbulance}
            className="hover:opacity-80 transition-opacity flex items-center gap-1.5 bg-white/20 px-2 py-0.5 rounded"
          >
            🚑 {t('findAmbulance')}
          </button>
        </div>
      </div>
    </div>
  );
};
