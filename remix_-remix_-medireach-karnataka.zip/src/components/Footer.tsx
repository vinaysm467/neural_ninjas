import React from 'react';
import { Phone, Mail, MapPin, ExternalLink, ShieldCheck } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export const Footer: React.FC = () => {
  const { t } = useLanguage();
  
  return (
    <footer className="bg-slate-800 text-slate-400 py-6 px-6 border-t border-slate-700">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 text-[10px] uppercase tracking-wider font-medium">
        <div className="flex flex-wrap justify-center gap-6">
          <span className="flex items-center gap-2"><div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" /> 108 {t('ambulance')}</span>
          <span>{t('helpline104')}</span>
          <span>{t('elderCare14567')}</span>
        </div>
        <div className="text-center">
          © 2026 MediReach • {t('footerDisclaimer')}
        </div>
        <div className="flex gap-6">
          <span className="hover:text-white cursor-pointer transition-colors">{t('privacyPolicy')}</span>
          <span className="hover:text-white cursor-pointer transition-colors">{t('termsOfService')}</span>
        </div>
      </div>
    </footer>
  );
};
