import React, { useState, useEffect } from 'react';
import { User, Shield, ClipboardList, Database, FileText, Send, CheckCircle2, ChevronRight, Lock, Eye, AlertCircle, ArrowLeftRight, Clock, MapPin, Building2, LayoutDashboard } from 'lucide-react';
import { HOSPITALS } from '../data';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../contexts/LanguageContext';

interface TransferRequest {
  id: string;
  from: string;
  to: string;
  status: 'Pending' | 'In Transit' | 'Received' | 'Verified';
  date: string;
  patientName: string;
}

export const MyHealthRecords: React.FC = () => {
  const [activeView, setActiveView] = useState<'profile' | 'transfer' | 'track'>('profile');
  const [profileSaved, setProfileSaved] = useState(false);
  const [transferSubmitted, setTransferSubmitted] = useState(false);
  const { t } = useLanguage();
  
  const [patientData, setPatientData] = useState({
    name: 'Loading...',
    bloodGroup: '',
    phone: '',
    id: '',
    dob: '',
    emergency: '',
    allergies: ''
  });

  const [transfers, setTransfers] = useState<TransferRequest[]>([]);

  const [transferForm, setTransferForm] = useState({
    from: 'JSS Hospital',
    to: 'Apollo BGS Hospital'
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [profileRes, transfersRes] = await Promise.all([
          fetch('/api/patient/profile'),
          fetch('/api/patient/transfers')
        ]);
        
        if (profileRes.ok) {
          const data = await profileRes.json();
          if (data) setPatientData(data);
        }
        
        if (transfersRes.ok) {
          const data = await transfersRes.json();
          setTransfers(data);
        }
      } catch (err) {
        console.error("Error fetching patient data:", err);
      }
    };
    fetchData();
  }, []);

  const [activeSimulations] = useState(new Set<string>());

  const resumeSimulation = (transferId: string, currentStatus: string) => {
    if (activeSimulations.has(transferId)) return;
    activeSimulations.add(transferId);

    const statusOrder = ['Pending', 'In Transit', 'Received', 'Verified'];
    let idx = statusOrder.indexOf(currentStatus);
    
    // If it's already verified, don't simulate
    if (idx >= statusOrder.length - 1) {
      activeSimulations.delete(transferId);
      return;
    }

    const interval = setInterval(() => {
      setTransfers(prev => {
        const found = prev.find(t => t.id === transferId);
        if (!found) {
          clearInterval(interval);
          activeSimulations.delete(transferId);
          return prev;
        }
        
        const currentIdx = statusOrder.indexOf(found.status);
        if (currentIdx < statusOrder.length - 1) {
          const nextStatus = statusOrder[currentIdx + 1];
          return prev.map(t => t.id === transferId ? { ...t, status: nextStatus as any } : t);
        } else {
          clearInterval(interval);
          activeSimulations.delete(transferId);
          return prev;
        }
      });
    }, 10000);
  };

  useEffect(() => {
    localStorage.setItem('medi_reach_transfers', JSON.stringify(transfers));
    
    // Resume simulation for any non-verified transfers found on load
    transfers.forEach(t => {
      if (t.status !== 'Verified' && !activeSimulations.has(t.id)) {
        resumeSimulation(t.id, t.status);
      }
    });
  }, [transfers]);

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/patient/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(patientData)
      });
      if (response.ok) {
        setProfileSaved(true);
        setTimeout(() => setProfileSaved(false), 3000);
      }
    } catch (err) {
      console.error("Profile update error:", err);
    }
  };

  const handleInitiateTransfer = async () => {
    // Basic validation
    if (!transferForm.to || transferForm.from === transferForm.to) {
      alert("Please select a different destination hospital.");
      return;
    }

    const consentCheck = document.getElementById('consent') as HTMLInputElement;
    if (!consentCheck?.checked) {
      alert("Please provide consent to proceed.");
      return;
    }

    setTransferSubmitted(true);
    
    try {
      const response = await fetch('/api/patient/transfers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from: transferForm.from,
          to: transferForm.to,
          records: 'Clinical, Imaging, Medication'
        })
      });
      
      if (response.ok) {
        const newTransfer = await response.json();
        setTransfers(prev => [newTransfer, ...prev]);
        
        setTimeout(() => {
          setTransferSubmitted(false);
          setActiveView('track');
          resumeSimulation(newTransfer.id, 'Pending');
        }, 2000);
      }
    } catch (err) {
      console.error("Transfer error:", err);
      setTransferSubmitted(false);
    }
  };

  const records = [
    { title: 'Lab Report - Blood Work', date: '12 Jan 2026', type: 'Clinical' },
    { title: 'X-Ray - Knee Joint', date: '05 Feb 2026', type: 'Imaging' },
    { title: 'Prescription - Cardiology', date: '20 Mar 2026', type: 'Medication' },
  ];

  return (
    <div className="bg-[#f8fafb] min-h-screen py-12 px-4 shadow-inner">
      <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Sidebar Nav */}
        <div className="lg:col-span-1 space-y-4">
          <div className="bg-white p-8 rounded-[48px] border border-slate-200 shadow-sm">
            <div className="flex flex-col items-center mb-8">
              <div className="w-20 h-20 bg-[#0d9e6e]/10 rounded-[28px] flex items-center justify-center text-[#0d9e6e] mb-4 shadow-inner">
                {patientData.name.charAt(0)}
              </div>
              <h3 className="text-xl font-black text-slate-800 text-center line-clamp-1">{patientData.name}</h3>
              <p className="text-[10px] font-black text-slate-400 tracking-[0.2em] uppercase mt-1">{patientData.id}</p>
            </div>
            
            <div className="space-y-2">
              <button 
                onClick={() => setActiveView('profile')}
                className={cn(
                  "w-full flex items-center gap-3 px-5 py-4 rounded-2xl transition-all text-sm font-black uppercase tracking-widest",
                  activeView === 'profile' ? "bg-slate-900 text-white shadow-xl shadow-slate-900/20" : "text-slate-400 hover:bg-slate-50"
                )}
              >
                <Database className="w-4 h-4" /> {t('myProfile')}
              </button>
              <button 
                onClick={() => setActiveView('transfer')}
                className={cn(
                  "w-full flex items-center gap-3 px-5 py-4 rounded-2xl transition-all text-sm font-black uppercase tracking-widest",
                  activeView === 'transfer' ? "bg-slate-900 text-white shadow-xl shadow-slate-900/20" : "text-slate-400 hover:bg-slate-50"
                )}
              >
                <ArrowLeftRight className="w-4 h-4" /> {t('newTransfer')}
              </button>
              <button 
                onClick={() => setActiveView('track')}
                className={cn(
                  "w-full flex items-center gap-3 px-5 py-4 rounded-2xl transition-all text-sm font-black uppercase tracking-widest",
                  activeView === 'track' ? "bg-slate-900 text-white shadow-xl shadow-slate-900/20" : "text-slate-400 hover:bg-slate-50"
                )}
              >
                <Clock className="w-4 h-4" /> {t('trackStatus')}
              </button>
            </div>
          </div>

          <div className="bg-[#0891b2] p-8 rounded-[48px] text-white overflow-hidden relative shadow-xl shadow-[#0891b2]/20 group">
            <div className="relative z-10">
              <h4 className="font-black mb-3 flex items-center gap-2 italic uppercase tracking-tight">
                <Shield className="w-5 h-5" /> {t('ultraSecured')}
              </h4>
              <p className="text-[10px] text-white/80 leading-relaxed uppercase font-black tracking-[0.2em]">
                {t('blockchainVerification')} <br />{t('aesEncryption')} <br />{t('patientOwnedKeys')}
              </p>
            </div>
            <div className="absolute -bottom-12 -right-12 w-32 h-32 bg-white/10 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-700" />
          </div>
        </div>

        {/* Main View Area */}
        <div className="lg:col-span-3">
          <AnimatePresence mode="wait">
            {activeView === 'profile' && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="space-y-8"
              >
                <div className="bg-white p-10 md:p-14 rounded-[56px] border border-slate-200 shadow-sm relative overflow-hidden">
                  <div className="flex items-center justify-between mb-12 relative z-10">
                    <div>
                      <h2 className="text-3xl font-black text-slate-800 italic tracking-tight uppercase">{t('myRecords')}</h2>
                      <p className="text-slate-400 text-sm font-bold mt-1">{t('manageDigitalIdentity')}</p>
                    </div>
                    <AnimatePresence>
                      {profileSaved && (
                        <motion.span 
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          exit={{ opacity: 0 }}
                          className="flex items-center gap-2 px-4 py-2 bg-[#0d9e6e]/10 text-[#0d9e6e] rounded-full text-[10px] font-black uppercase tracking-widest border border-[#0d9e6e]/20"
                        >
                          <CheckCircle2 className="w-4 h-4" /> {t('recordsUpdated')}
                        </motion.span>
                      )}
                    </AnimatePresence>
                  </div>

                  <form onSubmit={handleSaveProfile} className="relative z-10">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                      <div className="space-y-8">
                        <label className="block group">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-3 group-focus-within:text-[#0d9e6e] transition-colors">{t('patientName')}</span>
                          <input 
                            type="text" 
                            className="w-full h-14 bg-slate-50 border-2 border-slate-50 rounded-[20px] px-6 outline-none font-bold text-slate-700 focus:bg-white focus:border-[#0d9e6e]/20 transition-all" 
                            value={patientData.name}
                            onChange={(e) => setPatientData({...patientData, name: e.target.value})}
                          />
                        </label>
                        <label className="block group">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-3 group-focus-within:text-[#0d9e6e] transition-colors">{t('dateOfBirth')}</span>
                          <input 
                            type="date" 
                            className="w-full h-14 bg-slate-50 border-2 border-slate-50 rounded-[20px] px-6 outline-none font-bold text-slate-700 focus:bg-white focus:border-[#0d9e6e]/20 transition-all" 
                            value={patientData.dob}
                            onChange={(e) => setPatientData({...patientData, dob: e.target.value})}
                          />
                        </label>
                        <label className="block group">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-3 group-focus-within:text-[#0d9e6e] transition-colors">{t('bloodGroup')}</span>
                          <select 
                            className="w-full h-14 bg-slate-50 border-2 border-slate-50 rounded-[20px] px-6 outline-none font-bold text-slate-700 focus:bg-white focus:border-[#0d9e6e]/20 transition-all appearance-none"
                            value={patientData.bloodGroup}
                            onChange={(e) => setPatientData({...patientData, bloodGroup: e.target.value})}
                          >
                            <option>A+</option><option>B+</option><option>O+</option><option>AB+</option><option>O-</option>
                          </select>
                        </label>
                      </div>
                      <div className="space-y-8">
                        <label className="block group">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-3 group-focus-within:text-[#0d9e6e] transition-colors">{t('primaryPhone')}</span>
                          <input 
                            type="text" 
                            className="w-full h-14 bg-slate-50 border-2 border-slate-50 rounded-[20px] px-6 outline-none font-bold text-slate-700 focus:bg-white focus:border-[#0d9e6e]/20 transition-all" 
                            value={patientData.phone}
                            onChange={(e) => setPatientData({...patientData, phone: e.target.value})}
                          />
                        </label>
                        <label className="block group">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-3 group-focus-within:text-[#0d9e6e] transition-colors">{t('emergencyContact')}</span>
                          <input 
                            type="text" 
                            className="w-full h-14 bg-slate-50 border-2 border-slate-50 rounded-[20px] px-6 outline-none font-bold text-slate-700 focus:bg-white focus:border-[#0d9e6e]/20 transition-all" 
                            value={patientData.emergency}
                            onChange={(e) => setPatientData({...patientData, emergency: e.target.value})}
                          />
                        </label>
                        <label className="block group">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-3 group-focus-within:text-[#0d9e6e] transition-colors">{t('knownAllergies')}</span>
                          <input 
                            type="text" 
                            className="w-full h-14 bg-slate-50 border-2 border-slate-50 rounded-[20px] px-6 outline-none font-bold text-slate-700 focus:bg-white focus:border-[#0d9e6e]/20 transition-all" 
                            value={patientData.allergies}
                            onChange={(e) => setPatientData({...patientData, allergies: e.target.value})}
                          />
                        </label>
                      </div>
                    </div>

                    <div className="mt-14 pt-10 border-t border-slate-100 flex items-center justify-between">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-2 bg-slate-50 px-4 py-2.5 rounded-2xl text-slate-400 font-bold border border-slate-100 text-[10px] uppercase tracking-widest shadow-sm">
                          <Lock className="w-3.5 h-3.5" /> {t('hipaaCompliant')}
                        </div>
                      </div>
                      <button 
                        type="submit"
                        className="bg-[#0d9e6e] text-white px-10 py-4 rounded-2xl font-black text-sm shadow-xl shadow-[#0d9e6e]/20 hover:shadow-[#0d9e6e]/40 hover:-translate-y-1 transition-all active:scale-95"
                      >
                        {t('updateProfile')}
                      </button>
                    </div>
                  </form>
                  <div className="absolute top-0 right-0 w-64 h-64 bg-slate-50 rounded-full -mr-32 -mt-32 opacity-50" />
                </div>

                <div className="bg-white p-10 rounded-[56px] border border-slate-200 shadow-sm">
                  <h3 className="text-2xl font-black text-slate-800 mb-8 italic uppercase tracking-tight">{t('recentMedicalRecords')}</h3>
                  <div className="space-y-4">
                    {[
                      { title: t('labReportBloodWork'), date: '12 Jan 2026', type: t('clinical') },
                      { title: t('xRayKneeJoint'), date: '05 Feb 2026', type: t('imaging') },
                      { title: t('prescriptionCardiology'), date: '20 Mar 2026', type: t('medication') },
                    ].map((r, i) => (
                      <div key={i} className="flex items-center justify-between p-6 bg-slate-50 rounded-[28px] border-2 border-slate-50 group hover:border-[#0d9e6e]/20 hover:bg-white transition-all">
                        <div className="flex items-center gap-6">
                          <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-black/5", 
                            r.type === t('clinical') ? 'bg-blue-500' : r.type === t('imaging') ? 'bg-purple-500' : 'bg-[#0d9e6e]'
                          )}>
                             <FileText className="w-7 h-7" />
                          </div>
                          <div>
                            <h4 className="text-lg font-black text-slate-800 italic">{r.title}</h4>
                            <div className="flex items-center gap-4 mt-1">
                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest bg-white px-2 py-0.5 rounded-lg border border-slate-100">{r.type}</span>
                              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{r.date}</span>
                            </div>
                          </div>
                        </div>
                        <button className="w-12 h-12 rounded-2xl bg-white border border-slate-200 flex items-center justify-center text-slate-400 hover:text-[#0d9e6e] hover:border-[#0d9e6e]/30 transition-all shadow-sm">
                          <Eye className="w-5 h-5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            )}

            {activeView === 'transfer' && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="space-y-8"
              >
                <div className="bg-white p-10 md:p-14 rounded-[56px] border border-slate-200 shadow-sm">
                  <div className="max-w-2xl">
                    <h2 className="text-3xl font-black text-slate-800 mb-2 italic uppercase tracking-tight">{t('initiateTransfer')}</h2>
                    <p className="text-slate-500 text-sm mb-12 leading-relaxed font-bold">{t('transferDesc')}</p>
                    
                    <div className="space-y-10">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <label className="block">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-3">{t('originFacility')}</span>
                          <select 
                            className="w-full h-14 bg-slate-50 border-2 border-slate-50 rounded-2xl px-6 outline-none font-bold text-slate-700 appearance-none bg-[url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%22%20fill%3D%22none%22%20stroke%3D%22%23cbd5e1%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%3Cpolyline%20points%3D%226%209%2012%2015%2018%209%22%3E%3C%2Fpolyline%3E%3C%2Fsvg%3E')] bg-[length:1.25rem_1.25rem] bg-[right_1rem_center] bg-no-repeat"
                            value={transferForm.from}
                            onChange={(e) => setTransferForm({...transferForm, from: e.target.value})}
                          >
                            {HOSPITALS.map(h => <option key={h.id} value={h.name}>{h.name}</option>)}
                          </select>
                        </label>
                        <label className="block">
                          <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-3">{t('destinationFacility')}</span>
                          <select 
                            className="w-full h-14 bg-slate-50 border-2 border-slate-50 rounded-2xl px-6 outline-none font-bold text-slate-700 appearance-none bg-[url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22%23cbd5e1%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%3Cpolyline%20points%3D%226%209%2012%2015%2018%209%22%3E%3C%2Fpolyline%3E%3C%2Fsvg%3E')] bg-[length:1.25rem_1.25rem] bg-[right_1rem_center] bg-no-repeat"
                            value={transferForm.to}
                            onChange={(e) => setTransferForm({...transferForm, to: e.target.value})}
                          >
                            <option value="">{t('selectDestination')}</option>
                            {HOSPITALS.map(h => <option key={h.id} value={h.name}>{h.name}</option>)}
                          </select>
                        </label>
                      </div>

                      <div>
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-5">{t('recordsInclusionList')}</span>
                        <div className="grid grid-cols-2 gap-4">
                          {[t('clinicalReports'), t('imagingDicom'), t('medicationLogs'), t('surgicalUpdates')].map(item => (
                            <label key={item} className="flex items-center gap-4 p-5 bg-slate-50 rounded-2xl border-2 border-slate-50 cursor-pointer hover:border-[#0d9e6e]/20 hover:bg-white transition-all shadow-sm">
                              <input type="checkbox" className="w-5 h-5 rounded-lg border-slate-300 text-[#0d9e6e] focus:ring-[#0d9e6e]" defaultChecked />
                              <span className="text-xs font-black text-slate-600 uppercase tracking-tight italic">{item}</span>
                            </label>
                          ))}
                        </div>
                      </div>

                      <div className="p-8 bg-amber-50 rounded-[32px] border-2 border-amber-100/50 space-y-4">
                         <div className="flex items-center gap-3">
                           <AlertCircle className="w-5 h-5 text-amber-600" />
                           <h4 className="text-[10px] font-black text-amber-800 uppercase tracking-widest">{t('informedConsent')}</h4>
                         </div>
                         <label className="flex items-start gap-4 cursor-pointer group">
                           <input type="checkbox" className="w-5 h-5 rounded-lg border-amber-300 text-amber-600 focus:ring-amber-600 mt-0.5" required id="consent" />
                           <span className="text-xs text-amber-900/70 font-bold italic leading-relaxed group-hover:text-amber-950 transition-colors">
                             {t('consentStatement')}
                           </span>
                         </label>
                      </div>

                      <button 
                        onClick={handleInitiateTransfer}
                        disabled={transferSubmitted || !transferForm.to || transferForm.from === transferForm.to}
                        className={cn(
                          "w-full py-5 text-white font-black rounded-[28px] shadow-xl transition-all flex items-center justify-center gap-3 active:scale-95",
                          transferSubmitted || !transferForm.to || transferForm.from === transferForm.to ? "bg-slate-300 cursor-not-allowed" : "bg-slate-900 hover:bg-black shadow-slate-900/20"
                        )}
                      >
                        {transferSubmitted ? t('authorizingTransfer') : 
                         transferForm.from === transferForm.to ? "Select Different Destination" :
                         t('finalizeEncryptTransfer')}
                        {!transferSubmitted && <Send className="w-5 h-5" />}
                        {transferSubmitted && <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1 }} className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full" />}
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            )}

            {activeView === 'track' && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.98 }}
                className="space-y-8"
              >
                <div className="bg-white p-10 md:p-14 rounded-[56px] border border-slate-200 shadow-sm">
                  <h2 className="text-3xl font-black text-slate-800 mb-2 italic uppercase tracking-tight">{t('activeTransfers')}</h2>
                  <p className="text-slate-500 text-sm mb-12 leading-relaxed font-bold">{t('monitorStatus')}</p>

                  {transfers.length > 0 ? (
                    <div className="space-y-12">
                      {transfers.map((t_item, idx) => (
                        <div key={t_item.id} className="relative">
                          <div className="flex flex-col md:flex-row md:items-center justify-between p-8 bg-slate-50 rounded-[40px] border-2 border-slate-50 relative z-10">
                            <div className="space-y-6">
                              <div className="flex items-center gap-4">
                                <span className="px-3 py-1 bg-white border border-slate-100 text-[10px] font-black text-slate-400 rounded-lg uppercase tracking-widest">{t_item.id}</span>
                                <span className={cn(
                                  "px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest",
                                  t_item.status === 'Pending' ? "bg-amber-100 text-amber-600" : "bg-[#0d9e6e]/10 text-[#0d9e6e]"
                                )}>{t(t_item.status.charAt(0).toLowerCase() + t_item.status.slice(1).replace(/\s+/g, '') as any)}</span>
                              </div>
                              <div className="flex items-center gap-8">
                                <div className="flex flex-col">
                                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{t('from')}</span>
                                  <span className="text-sm font-black text-slate-700 italic">{t_item.from}</span>
                                </div>
                                <div className="w-12 h-px bg-slate-200 relative">
                                  <ChevronRight className="absolute -right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
                                </div>
                                <div className="flex flex-col">
                                  <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{t('to')}</span>
                                  <span className="text-sm font-black text-slate-700 italic">{t_item.to}</span>
                                </div>
                              </div>
                            </div>
                            <div className="mt-6 md:mt-0 pt-6 md:pt-0 border-t md:border-t-0 md:border-l border-slate-200 md:pl-10 flex items-center justify-between md:block">
                               <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">{t('lastUpdated')}</p>
                               <p className="text-sm font-black text-slate-700">{t_item.date}</p>
                               <button className="hidden md:block mt-6 px-6 py-2.5 bg-white border border-slate-200 text-slate-600 text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-slate-100 transition-colors">
                                 {t('viewLogs')}
                               </button>
                            </div>
                          </div>
                          
                          {/* Timeline visualization */}
                          <div className="max-w-xl mx-auto mt-6 px-8 flex justify-between relative">
                            <div className="absolute top-1/2 left-12 right-12 h-0.5 bg-slate-100 -translate-y-1/2" />
                            {[t('initiated'), t('encrypted'), t('inTransit'), t('verified')].map((step, sIdx) => {
                               const statusOrder = ['Pending', 'In Transit', 'Received', 'Verified'];
                               const currentIdx = statusOrder.indexOf(t_item.status);
                               
                               let isActive = false;
                               if (currentIdx === 0) isActive = sIdx === 0; // Pending -> Initiated only
                               else if (currentIdx === 1) isActive = sIdx <= 2; // In Transit -> Includes Encrypted
                               else if (currentIdx >= 2) isActive = true; // Received or Verified -> All active
                               
                               return (
                                 <div key={step} className="flex flex-col items-center gap-2 relative z-10">
                                   <div className={cn(
                                     "w-4 h-4 rounded-full border-2",
                                     isActive ? "bg-[#0d9e6e] border-[#0d9e6e] shadow-lg shadow-[#0d9e6e]/20" : "bg-white border-slate-200"
                                   )} />
                                   <span className={cn("text-[8px] font-black uppercase tracking-tighter", isActive ? "text-[#0d9e6e]" : "text-slate-300")}>{step}</span>
                                 </div>
                               );
                            })}
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="py-24 text-center">
                      <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center text-slate-200 mx-auto mb-6">
                        <LayoutDashboard className="w-10 h-10" />
                      </div>
                      <h4 className="text-2xl font-black text-slate-300 italic uppercase">{t('noTransferHistory')}</h4>
                      <p className="text-slate-400 font-bold mt-2">{t('noTransferHistoryDesc')}</p>
                      <button 
                        onClick={() => setActiveView('transfer')}
                        className="mt-8 px-6 py-3 bg-slate-100 text-slate-500 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-200 transition-all"
                      >
                        {t('startNewTransfer')}
                      </button>
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

