import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Shield, User, Building2, Lock, Mail, ChevronRight } from 'lucide-react';
import { cn } from '../lib/utils';
import { useLanguage } from '../contexts/LanguageContext';

interface LoginProps {
  onLogin: (role: 'patient' | 'hospital', userData: any) => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [loginType, setLoginType] = useState<'patient' | 'hospital' | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const { t } = useLanguage();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, role: loginType })
      });

      const contentType = response.headers.get("content-type");
      let data;
      if (contentType && contentType.indexOf("application/json") !== -1) {
        data = await response.json();
      } else {
        const text = await response.text();
        data = { message: text };
      }

      if (response.ok) {
        // Success: Trigger parent callback
        onLogin(data.role, data);
      } else {
        // Error handling without exposing server details
        setError(data.message || 'Login failed. Please check your credentials.');
      }
    } catch (err) {
      console.error('Login error:', err);
      setError('Service connection error. Please try again later.');
    }
  };

  return (
    <div className="min-h-screen bg-[#f8fafb] flex items-center justify-center p-6">
      <div className="max-w-md w-full">
        <div className="text-center mb-10">
          <div className="w-16 h-16 bg-[#0d9e6e] rounded-2xl flex items-center justify-center text-white text-2xl font-black mx-auto mb-6 shadow-xl shadow-[#0d9e6e]/20">M</div>
          <h1 className="text-3xl font-black text-slate-800 italic uppercase tracking-tight">MediReach <span className="text-[#0d9e6e]">Karnataka</span></h1>
          <p className="text-slate-400 font-bold mt-2 uppercase tracking-widest text-[10px]">{t('ultraSecured')}</p>
        </div>

        {!loginType ? (
          <div className="space-y-4">
            <h2 className="text-xl font-black text-slate-800 mb-6 text-center italic uppercase tracking-tight">{t('selectLoginType')}</h2>
            <button 
              onClick={() => setLoginType('patient')}
              className="w-full bg-white p-8 rounded-[32px] border-2 border-slate-100 hover:border-[#0d9e6e] text-left transition-all group flex items-center justify-between shadow-sm"
            >
              <div className="flex items-center gap-6">
                <div className="w-14 h-14 bg-blue-50 rounded-2xl flex items-center justify-center text-blue-600 transition-colors group-hover:bg-blue-600 group-hover:text-white">
                  <User className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-800 italic uppercase tracking-tight">{t('patientLogin')}</h3>
                  <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mt-1">Access your records</p>
                </div>
              </div>
              <ChevronRight className="w-6 h-6 text-slate-300 group-hover:text-[#0d9e6e] translate-x-0 group-hover:translate-x-2 transition-all" />
            </button>

            <button 
              onClick={() => setLoginType('hospital')}
              className="w-full bg-white p-8 rounded-[32px] border-2 border-slate-100 hover:border-[#0d9e6e] text-left transition-all group flex items-center justify-between shadow-sm"
            >
              <div className="flex items-center gap-6">
                <div className="w-14 h-14 bg-teal-50 rounded-2xl flex items-center justify-center text-teal-600 transition-colors group-hover:bg-teal-600 group-hover:text-white">
                  <Building2 className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-lg font-black text-slate-800 italic uppercase tracking-tight">{t('hospitalLogin')}</h3>
                  <p className="text-slate-400 text-[10px] font-black uppercase tracking-widest mt-1">Manage health network</p>
                </div>
              </div>
              <ChevronRight className="w-6 h-6 text-slate-300 group-hover:text-[#0d9e6e] translate-x-0 group-hover:translate-x-2 transition-all" />
            </button>
          </div>
        ) : (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white p-10 rounded-[48px] border border-slate-200 shadow-xl"
          >
            <button onClick={() => setLoginType(null)} className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-8 flex items-center gap-2 hover:text-[#0d9e6e] transition-colors">
              <ChevronRight className="w-4 h-4 rotate-180" /> {t('back')}
            </button>

            <h2 className="text-2xl font-black text-slate-800 mb-8 italic uppercase tracking-tight">
              {loginType === 'patient' ? t('patientLogin') : t('hospitalLogin')}
            </h2>

            <form onSubmit={handleLogin} className="space-y-6">
              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">{loginType === 'hospital' ? t('hospitalId') : t('email')}</label>
                <div className="relative">
                  <Mail className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="text" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                    className="w-full h-14 bg-slate-50 border-2 border-slate-50 rounded-2xl pl-14 pr-6 outline-none font-bold text-slate-700 focus:bg-white focus:border-[#0d9e6e]/20 transition-all font-sans" 
                    placeholder={loginType === 'hospital' ? "HOSP001" : "patient@mail.com"}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">{t('password')}</label>
                <div className="relative">
                  <Lock className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  <input 
                    type="password" 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    className="w-full h-14 bg-slate-50 border-2 border-slate-50 rounded-2xl pl-14 pr-6 outline-none font-bold text-slate-700 focus:bg-white focus:border-[#0d9e6e]/20 transition-all font-sans" 
                    placeholder="••••••••"
                  />
                </div>
              </div>

              {error && <p className="text-red-500 text-[10px] font-black uppercase tracking-widest text-center">{error}</p>}

              <button 
                type="submit"
                className="w-full bg-[#0d9e6e] text-white h-14 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-[#0d9e6e]/20 hover:shadow-[#0d9e6e]/40 transition-all active:scale-95 flex items-center justify-center gap-3"
              >
                {t('login')} <ChevronRight className="w-4 h-4" />
              </button>
            </form>
          </motion.div>
        )}

        <div className="mt-12 flex items-center justify-center gap-2 text-slate-400">
          <Shield className="w-4 h-4" />
          <span className="text-[10px] font-black uppercase tracking-[0.2em]">Verified by Karnataka Health Board</span>
        </div>
      </div>
    </div>
  );
};
