import React, { useState, useEffect, useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { HOSPITALS } from '../data';
import { DISEASE_PRICES } from '../diseaseData';
import { Check, X, Shield, Award, IndianRupee, Star, MapPin, Search, Filter, ArrowUpDown, Brain, Phone, Navigation, Calendar, Loader2, Info } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../contexts/LanguageContext';

interface CompareHospitalsProps {
  onBookAppointment?: (hospitalId?: string, doctorId?: string, diseaseInfo?: { name: string; price: number }, fromCompare?: boolean) => void;
}

export const CompareHospitals: React.FC<CompareHospitalsProps> = ({ onBookAppointment }) => {
  const [compareMode, setCompareMode] = useState<'hospital' | 'disease'>('hospital');
  const [selectedIds, setSelectedIds] = useState<string[]>(['h1', 'h2']);
  const { t, language } = useLanguage();

  const insuranceLinks: Record<string, string> = {
    'Ayushman Bharat': 'https://pmjay.gov.in/',
    'Star Health': 'https://www.starhealth.in/',
    'HDFC ERGO': 'https://www.hdfcergo.com/',
    'ICICI Lombard': 'https://www.icicilombard.com/',
    'Care Health': 'https://www.careinsurance.com/',
    'ESI': 'https://www.esic.gov.in/',
    'CGHS': 'https://cghs.gov.in/',
    'Jyothi Sanjeevini': 'https://arogya.karnataka.gov.in/',
    'Vajpayee Arogyasree': 'https://arogya.karnataka.gov.in/'
  };

  // Disease Comparison States
  const [diseaseSearch, setDiseaseSearch] = useState('');
  const [filterDistrict, setFilterDistrict] = useState('all');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterInsurance, setFilterInsurance] = useState(false);
  const [filterEmergency, setFilterEmergency] = useState(false);
  const [sortBy, setSortBy] = useState<'cost' | 'rating' | 'waiting' | 'best'>('best');

  const toggleHospital = (id: string) => {
    if (selectedIds.includes(id)) {
      if (selectedIds.length > 2) {
        setSelectedIds(selectedIds.filter(i => i !== id));
      }
    } else {
      if (selectedIds.length < 3) {
        setSelectedIds([...selectedIds, id]);
      }
    }
  };

  const comparedHospitals = selectedIds.map(id => HOSPITALS.find(h => h.id === id)!);

  const getWinnerValue = (field: keyof typeof comparedHospitals[0], type: 'min' | 'max') => {
    const values = comparedHospitals.map(h => h[field] as number);
    const winVal = type === 'max' ? Math.max(...values) : Math.min(...values);
    return winVal;
  };

  const chartData = comparedHospitals.map(h => ({
    name: h.name.split(' ')[0],
    fee: h.avg_fee,
    rating: h.rating,
    distance: h.distance_km
  }));

  // Disease filtering logic and statistics
  const { matchedDiseases, stats, selectedDiseaseName } = useMemo(() => {
    const results = DISEASE_PRICES.filter(dp => {
      const matchesSearch = diseaseSearch.trim() !== '' && 
                           (dp.disease_name.toLowerCase().includes(diseaseSearch.toLowerCase()) || 
                            dp.category.toLowerCase().includes(diseaseSearch.toLowerCase()));
      const matchesDistrict = filterDistrict === 'all' || dp.district.toLowerCase() === filterDistrict.toLowerCase();
      const matchesCategory = filterCategory === 'all' || dp.category.toLowerCase() === filterCategory.toLowerCase();
      const matchesInsurance = !filterInsurance || dp.insurance_supported;
      const matchesEmergency = !filterEmergency || dp.emergency_available;
      
      return matchesSearch && matchesDistrict && matchesCategory && matchesInsurance && matchesEmergency;
    });

    if (results.length === 0) return { matchedDiseases: [], stats: null, selectedDiseaseName: '' };

    // Group by disease or just pick the first matched name for stats
    const diseaseName = results[0].disease_name;
    const sameDiseaseHospitals = results.filter(r => r.disease_name === diseaseName);

    const minItem = sameDiseaseHospitals.reduce((prev, curr) => prev.total_estimated_cost < curr.total_estimated_cost ? prev : curr);
    const maxItem = sameDiseaseHospitals.reduce((prev, curr) => prev.total_estimated_cost > curr.total_estimated_cost ? prev : curr);
    const avgCost = sameDiseaseHospitals.reduce((acc, curr) => acc + curr.total_estimated_cost, 0) / sameDiseaseHospitals.length;

    // Custom Best Balanced Logic
    const calculateBalancedScore = (dp: typeof DISEASE_PRICES[0]) => {
      let score = (dp.rating * 20); // Base rating contribution

      if (dp.urgency_level === 'High') {
        // Severe Priority: Emergency > ICU > Specialist > Distance > Cost
        if (dp.emergency_available) score += 50;
        if (dp.icu_facility_available) score += 40;
        if (dp.doctor_available) score += 30; // Specialist availability
        
        // Penalize distance (every km matters in emergency)
        score -= (dp.distance_km * 5);
        
        // Cost is secondary for severe
        const costRatio = 1 - (dp.total_estimated_cost / maxItem.total_estimated_cost);
        score += (costRatio * 10);
      } else {
        // Normal Priority: Affordability > Distance > Rating > Wait time
        const costRatio = 1 - (dp.total_estimated_cost / maxItem.total_estimated_cost);
        score += (costRatio * 50); // High weight for cost
        
        score -= (dp.distance_km * 2);
        score += (dp.rating * 20);
        score -= (dp.waiting_time_mins / 5);
        
        if (dp.insurance_supported) score += 15;
      }

      return score;
    };

    const sortedHospitals = [...sameDiseaseHospitals].sort((a, b) => calculateBalancedScore(b) - calculateBalancedScore(a));
    const bestBalanced = sortedHospitals[0];

    // Final sorting for the list based on user preference
    let displayList = [...sameDiseaseHospitals];
    if (sortBy === 'cost') displayList.sort((a, b) => a.total_estimated_cost - b.total_estimated_cost);
    else if (sortBy === 'rating') displayList.sort((a, b) => b.rating - a.rating);
    else if (sortBy === 'waiting') displayList.sort((a, b) => a.waiting_time_mins - b.waiting_time_mins);
    else displayList = sortedHospitals;

    return {
      matchedDiseases: displayList,
      selectedDiseaseName: diseaseName,
      stats: {
        min: minItem.total_estimated_cost,
        minHospital: minItem.hospital_name,
        max: maxItem.total_estimated_cost,
        maxHospital: maxItem.hospital_name,
        avg: Math.round(avgCost),
        diff: maxItem.total_estimated_cost - minItem.total_estimated_cost,
        savings: maxItem.total_estimated_cost - minItem.total_estimated_cost,
        bestBalancedId: bestBalanced.id,
        urgency: bestBalanced.urgency_level
      }
    };
  }, [diseaseSearch, filterDistrict, filterCategory, filterInsurance, filterEmergency, sortBy]);

  const bestRecommended = stats ? matchedDiseases.find(d => d.id === stats.bestBalancedId) : null;

  const uniqueDistricts = Array.from(new Set(DISEASE_PRICES.map(d => d.district)));
  const uniqueCategories = Array.from(new Set(DISEASE_PRICES.map(d => d.category)));

  return (
    <div className="bg-[#f8fafb] min-h-screen py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">{t('compareHospitalsTitle')}</h1>
          <p className="text-gray-600 max-w-2xl mx-auto">{t('compareStats')}</p>
        </div>

        {/* Tab Switcher */}
        <div className="flex justify-center mb-12">
          <div className="bg-white p-1 rounded-2xl shadow-sm border border-gray-100 flex gap-1">
            <button
              onClick={() => setCompareMode('hospital')}
              className={cn(
                "px-6 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2",
                compareMode === 'hospital' ? "bg-[#0d9e6e] text-white shadow-md shadow-[#0d9e6e]/20" : "text-gray-500 hover:bg-gray-50"
              )}
            >
              <Shield className="w-4 h-4" />
              {t('compareModeHospital')}
            </button>
            <button
              onClick={() => setCompareMode('disease')}
              className={cn(
                "px-6 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center gap-2",
                compareMode === 'disease' ? "bg-[#0d9e6e] text-white shadow-md shadow-[#0d9e6e]/20" : "text-gray-500 hover:bg-gray-50"
              )}
            >
              <IndianRupee className="w-4 h-4" />
              {t('compareModeDisease')}
            </button>
          </div>
        </div>

        {compareMode === 'hospital' ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            {/* Selection Sidebar/Row */}
            <div className="mb-12 overflow-x-auto pb-4 scrollbar-hide">
              <div className="flex gap-4">
                {HOSPITALS.map((h) => (
                  <button
                    key={h.id}
                    onClick={() => toggleHospital(h.id)}
                    className={cn(
                      "px-6 py-4 rounded-2xl border-2 transition-all shrink-0 text-left min-w-[200px]",
                      selectedIds.includes(h.id) 
                        ? "border-[#0d9e6e] bg-[#0d9e6e]/5 shadow-sm" 
                        : "border-white bg-white hover:border-gray-200 shadow-sm"
                    )}
                  >
                    <div className="flex justify-between items-center mb-1">
                      <span className={cn("text-[10px] font-black uppercase tracking-widest", selectedIds.includes(h.id) ? "text-[#0d9e6e]" : "text-gray-400")}>
                        {t(h.type.toLowerCase() as any)}
                      </span>
                      {selectedIds.includes(h.id) && <Check className="w-4 h-4 text-[#0d9e6e]" />}
                    </div>
                    <p className="hospital-name text-gray-900 text-sm line-clamp-1">{h.name}</p>
                    <p className="text-[10px] text-gray-500">₹{h.avg_fee} Fee • {h.rating.toFixed(1)} ★</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Comparison Table */}
            <div className="grid grid-cols-1 gap-8 mb-20">
              <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="bg-gray-50/50">
                      <th className="p-8 text-left text-xs font-black text-gray-400 uppercase tracking-[0.2em] w-1/4">{t('criteria')}</th>
                      {comparedHospitals.map(h => (
                        <th key={h.id} className="p-8 text-center min-w-[250px]">
                          <div className="flex flex-col items-center gap-2">
                            <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center text-gray-400 mb-2">
                              <Shield className="w-6 h-6" />
                            </div>
                            <h4 className="hospital-name text-gray-900 text-lg mb-1">{h.name}</h4>
                            <span className="text-[10px] bg-[#0d9e6e]/10 text-[#0d9e6e] px-2 py-0.5 rounded font-black tracking-widest uppercase">
                              {t(h.type.toLowerCase() as any)}
                            </span>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {/* Rating */}
                    <tr>
                      <td className="p-8 bg-gray-50/30">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-amber-50 rounded-lg flex items-center justify-center text-amber-500 shadow-sm">
                            <Star className="w-4 h-4 fill-amber-500" />
                          </div>
                          <span className="text-sm font-bold text-gray-700">{t('patientRating')}</span>
                        </div>
                      </td>
                      {comparedHospitals.map(h => {
                        const isWinner = h.rating === getWinnerValue('rating', 'max');
                        return (
                          <td key={h.id} className={cn("p-8 text-center text-lg font-bold transition-all", isWinner ? "bg-[#0d9e6e]/5 text-[#0d9e6e]" : "text-gray-900")}>
                            {h.rating.toFixed(1)} / 5.0
                            {isWinner && <p className="text-[10px] uppercase tracking-widest mt-1">{t('bestRated')}</p>}
                          </td>
                        );
                      })}
                    </tr>

                    {/* Consultation Fee */}
                    <tr>
                      <td className="p-8 bg-gray-50/30">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-green-50 rounded-lg flex items-center justify-center text-[#0d9e6e] shadow-sm">
                            <IndianRupee className="w-4 h-4" />
                          </div>
                          <span className="text-sm font-bold text-gray-700">{t('consultationFee')}</span>
                        </div>
                      </td>
                      {comparedHospitals.map(h => {
                        const isWinner = h.avg_fee === getWinnerValue('avg_fee', 'min');
                        return (
                          <td key={h.id} className={cn("p-8 text-center text-lg font-bold transition-all", isWinner ? "bg-[#0d9e6e]/5 text-[#0d9e6e]" : "text-gray-900")}>
                            ₹{h.avg_fee === 0 ? t('free') : h.avg_fee}
                            {isWinner && <p className="text-[10px] uppercase tracking-widest mt-1">{t('mostAffordable')}</p>}
                          </td>
                        );
                      })}
                    </tr>

                    {/* Distance */}
                    <tr>
                      <td className="p-8 bg-gray-50/30">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-teal-50 rounded-lg flex items-center justify-center text-teal-600 shadow-sm">
                            <MapPin className="w-4 h-4" />
                          </div>
                          <span className="text-sm font-bold text-gray-700">{t('distance')}</span>
                        </div>
                      </td>
                      {comparedHospitals.map(h => {
                        const isWinner = h.distance_km === getWinnerValue('distance_km', 'min');
                        return (
                          <td key={h.id} className={cn("p-8 text-center text-lg font-bold transition-all", isWinner ? "bg-[#0d9e6e]/5 text-[#0d9e6e]" : "text-gray-900")}>
                            {h.distance_km.toFixed(1)} km
                            {isWinner && <p className="text-[10px] uppercase tracking-widest mt-1">{t('nearest')}</p>}
                          </td>
                        );
                      })}
                    </tr>

                    {/* Emergency */}
                    <tr>
                      <td className="p-8 bg-gray-50/30">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-red-50 rounded-lg flex items-center justify-center text-red-500 shadow-sm">
                            <Award className="w-4 h-4" />
                          </div>
                          <span className="text-sm font-bold text-gray-700">{t('emergency')}</span>
                        </div>
                      </td>
                      {comparedHospitals.map(h => (
                        <td key={h.id} className="p-8 text-center">
                          <div className="flex justify-center">
                            {h.emergency ? <Check className="text-[#0d9e6e]" /> : <X className="text-red-400" />}
                          </div>
                        </td>
                      ))}
                    </tr>

                    {/* Beds */}
                    <tr>
                      <td className="p-8 bg-gray-50/30">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center text-blue-500 shadow-sm">
                            <Shield className="w-4 h-4" />
                          </div>
                          <span className="text-sm font-bold text-gray-700">{t('inPatientBeds')}</span>
                        </div>
                      </td>
                      {comparedHospitals.map(h => {
                        const isWinner = h.beds === getWinnerValue('beds', 'max');
                        return (
                          <td key={h.id} className={cn("p-8 text-center font-bold text-lg", isWinner ? "text-[#0d9e6e]" : "text-gray-900")}>
                            {h.beds}
                          </td>
                        );
                      })}
                    </tr>

                    {/* Action Row */}
                    <tr>
                      <td className="p-8 bg-gray-50/30"></td>
                      {comparedHospitals.map(h => (
                        <td key={h.id} className="p-8 text-center">
                          <button 
                            onClick={() => onBookAppointment?.(h.id, undefined, undefined, true)}
                            className="bg-[#0d9e6e] text-white px-6 py-2.5 rounded-xl font-bold hover:bg-[#0bc385] transition-all shadow-md shadow-[#0d9e6e]/20"
                          >
                            {t('bookNow')}
                          </button>
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Charts Visualization */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-20">
              <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
                <h3 className="text-xl font-bold text-gray-900 mb-8 border-b border-gray-100 pb-4">{t('consultationFeeSpectrum')}</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 11, fontWeight: 'bold' }} />
                      <YAxis hide />
                      <Tooltip 
                        cursor={{ fill: 'transparent' }}
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            return (
                              <div className="bg-gray-900 text-white p-3 rounded-xl shadow-xl text-xs font-bold">
                                ₹{payload[0].value} {t('consultation')}
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Bar dataKey="fee" radius={[10, 10, 0, 0]} barSize={40}>
                        {chartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={index === 0 ? '#0d9e6e' : index === 1 ? '#0891b2' : '#ca8a04'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              <div className="bg-white p-8 rounded-3xl border border-gray-100 shadow-sm">
                <h3 className="text-xl font-bold text-gray-900 mb-8 border-b border-gray-100 pb-4">{t('reliabilityRatings')}</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={chartData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                      <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 11, fontWeight: 'bold' }} />
                      <YAxis hide />
                      <Tooltip 
                        cursor={{ fill: 'transparent' }}
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            return (
                              <div className="bg-gray-900 text-white p-3 rounded-xl shadow-xl text-xs font-bold">
                                {Number(payload[0].value).toFixed(1)} {t('starRating')}
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Bar dataKey="rating" radius={[10, 10, 0, 0]} barSize={40}>
                        {chartData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={index === 0 ? '#0d9e6e' : index === 1 ? '#0891b2' : '#ca8a04'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
            className="space-y-8"
          >
            {/* Disease Comparison Header */}
            <div className="bg-white rounded-3xl p-8 border border-gray-100 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-[#0d9e6e]/5 rounded-full -mr-32 -mt-32 blur-3xl" />
              
              <div className="relative z-10 text-center mb-10">
                <h2 className="text-3xl font-black text-gray-900 mb-2 flex justify-center items-center gap-3">
                  <IndianRupee className="w-8 h-8 text-[#0d9e6e]" />
                  {t('diseasePriceCompare')}
                </h2>
                <p className="text-gray-500 font-medium">{t('searchDiseaseSubtitle')}</p>
              </div>

              <div className="max-w-3xl mx-auto space-y-6">
                {/* Search Box Styled Like Symptom Checker */}
                <div className="relative group">
                  <Search className="absolute left-6 top-6 text-gray-400 w-6 h-6 group-focus-within:text-[#0d9e6e] transition-colors" />
                  <textarea
                    placeholder={t('searchDiseasePlaceholder')}
                    value={diseaseSearch}
                    onChange={(e) => setDiseaseSearch(e.target.value)}
                    className="w-full bg-gray-50 border-2 border-gray-100 rounded-[2rem] py-6 pl-16 pr-6 text-xl font-bold focus:bg-white focus:border-[#0d9e6e] focus:ring-4 focus:ring-[#0d9e6e]/10 outline-none transition-all resize-none min-h-[100px] shadow-inner"
                  />
                </div>

                {/* Disease Suggestion Buttons */}
                <div className="flex flex-wrap justify-center gap-2">
                  {[
                    'Fever', 'Dengue', 'Diabetes', 'Chest Pain', 'Heart Attack', 
                    'Stroke', 'Cancer Screening', 'Kidney Failure', 'ICU Admission', 
                    'Accident Trauma', 'Asthma', 'Pneumonia', 'Typhoid', 'Malaria', 
                    'Pregnancy Checkup', 'Dental Pain', 'Skin Allergy', 'Back Pain', 
                    'Joint Pain', 'Migraine'
                  ].map((disease) => (
                    <button
                      key={disease}
                      onClick={() => setDiseaseSearch(disease)}
                      className={cn(
                        "px-4 py-2 rounded-full border text-xs font-black transition-all hover:shadow-md active:scale-95",
                        diseaseSearch.toLowerCase() === disease.toLowerCase() 
                          ? "bg-[#0d9e6e] text-white border-[#0d9e6e]" 
                          : "bg-white text-gray-600 border-gray-200 hover:border-[#0d9e6e] hover:text-[#0d9e6e]"
                      )}
                    >
                      + {disease}
                    </button>
                  ))}
                </div>

                {/* Filters Row */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-8 pt-8 border-t border-gray-100">
                  <div className="flex flex-col gap-2">
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">{t('selectDistrict')}</p>
                    <div className="relative">
                      <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <select
                        value={filterDistrict}
                        onChange={(e) => setFilterDistrict(e.target.value)}
                        className="w-full bg-white border border-gray-200 rounded-2xl py-3 pl-10 pr-4 font-bold text-gray-700 focus:border-[#0d9e6e] outline-none cursor-pointer appearance-none"
                      >
                        <option value="all">{t('all')}</option>
                        {uniqueDistricts.map(d => (
                          <option key={d} value={d}>{d}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">{t('sort') || 'Sort By'}</p>
                    <div className="relative">
                      <ArrowUpDown className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 w-4 h-4" />
                      <select
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value as any)}
                        className="w-full bg-white border border-gray-200 rounded-2xl py-3 pl-10 pr-4 font-bold text-gray-700 focus:border-[#0d9e6e] outline-none cursor-pointer appearance-none"
                      >
                        <option value="best">{t('bestOverall')}</option>
                        <option value="cost">{t('lowestCost')}</option>
                        <option value="rating">{t('highestRating')}</option>
                        <option value="waiting">{t('shortestWaiting')}</option>
                      </select>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={() => setFilterInsurance(!filterInsurance)}
                    className={cn(
                      "flex items-center gap-2 px-6 py-3 rounded-2xl text-xs font-black transition-all border shadow-sm",
                      filterInsurance ? "bg-[#0d9e6e] text-white border-[#0d9e6e]" : "bg-white text-gray-600 border-gray-200"
                    )}
                  >
                    <Shield className="w-4 h-4" />
                    {t('insuranceSupported')}
                  </button>
                  <button
                    onClick={() => setFilterEmergency(!filterEmergency)}
                    className={cn(
                      "flex items-center gap-2 px-6 py-3 rounded-2xl text-xs font-black transition-all border shadow-sm",
                      filterEmergency ? "bg-red-600 text-white border-red-600" : "bg-white text-gray-600 border-gray-200"
                    )}
                  >
                    <Award className="w-4 h-4" />
                    {t('emergency')}
                  </button>
                </div>
              </div>
            </div>

            {diseaseSearch && matchedDiseases.length === 0 && (
              <div className="bg-white p-12 rounded-3xl border border-dashed border-gray-300 text-center">
                <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search className="w-8 h-8 text-gray-300" />
                </div>
                <p className="text-gray-500 font-bold">{t('noPriceDataFound')}</p>
              </div>
            )}

            {/* Summary Statistics */}
            {stats && (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
                <div className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm">
                  <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">{t('lowestCostHospital')}</p>
                  <p className="text-xl font-black text-[#0d9e6e]">₹{stats.min}</p>
                  <p className="text-[10px] text-gray-500 mt-1 line-clamp-1">{stats.minHospital}</p>
                </div>
                <div className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm">
                  <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">{t('highestCostHospital')}</p>
                  <p className="text-xl font-black text-amber-600">₹{stats.max}</p>
                  <p className="text-[10px] text-gray-500 mt-1 line-clamp-1">{stats.maxHospital}</p>
                </div>
                <div className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm">
                  <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">{t('avgCost')}</p>
                  <p className="text-xl font-black text-blue-600">₹{stats.avg}</p>
                </div>
                <div className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm">
                  <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">{t('savingsAmount')}</p>
                  <p className="text-xl font-black text-[#0d9e6e]">₹{stats.savings}</p>
                </div>
                <div className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm">
                  <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-2">{t('costDifference')}</p>
                  <p className="text-xl font-black text-red-600">₹{stats.diff}</p>
                </div>
              </div>
            )}

            {/* Best Recommended Card */}
            {bestRecommended && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-6">
                  <div className="bg-[#0d9e6e]/5 border-2 border-[#0d9e6e] rounded-3xl p-8 relative overflow-hidden group">
                    <div className="absolute top-0 right-0 bg-[#0d9e6e] text-white px-6 py-2 rounded-bl-3xl text-xs font-black uppercase tracking-widest flex items-center gap-2">
                       <Award className="w-3 h-3 fill-white" />
                       {bestRecommended.urgency_level === 'High' ? t('emergencyRecommendedHospital') : t('recommended')}
                    </div>
                    
                    <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
                      <div>
                        <div className="flex items-center gap-3 mb-1">
                          <h3 className="hospital-name text-2xl text-gray-900 mb-2">{bestRecommended.hospital_name}</h3>
                          <span className={cn(
                            "text-[10px] font-black px-2 py-0.5 rounded-full uppercase tracking-tighter",
                            bestRecommended.urgency_level === 'High' ? "bg-red-100 text-red-600" :
                            bestRecommended.urgency_level === 'Medium' ? "bg-amber-100 text-amber-600" :
                            "bg-green-100 text-[#0d9e6e]"
                          )}>
                            {t('severityLevel')}: {t(bestRecommended.urgency_level.toLowerCase() as any)}
                          </span>
                        </div>
                        <p className="text-gray-500 font-medium flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-[#0d9e6e]" /> 
                          {bestRecommended.district}, {bestRecommended.area}
                        </p>
                      </div>
                      <div className="bg-white px-6 py-4 rounded-2xl shadow-sm border border-[#0d9e6e]/20 text-center">
                        <p className="text-[10px] uppercase tracking-widest font-black text-gray-400 mb-1">{t('avgCost')}</p>
                        <p className="text-2xl font-black text-[#0d9e6e]">₹{bestRecommended.total_estimated_cost}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
                       <div className="space-y-1">
                          <p className="text-[10px] text-gray-400 font-black uppercase tracking-wider">{t('patientRating')}</p>
                          <p className="font-bold text-gray-900 flex items-center gap-1">
                            {bestRecommended.rating.toFixed(1)} <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                          </p>
                       </div>
                       <div className="space-y-1">
                          <p className="text-[10px] text-gray-400 font-black uppercase tracking-wider">{t('distance')}</p>
                          <p className="font-bold text-gray-900">{bestRecommended.distance_km.toFixed(1)} km</p>
                       </div>
                       <div className="space-y-1">
                          <p className="text-[10px] text-gray-400 font-black uppercase tracking-wider">{t('waitingTime')}</p>
                          <p className="font-bold text-gray-900">{bestRecommended.waiting_time_mins} {t('mins')}</p>
                       </div>
                       <div className="space-y-1">
                          <p className="text-[10px] text-gray-400 font-black uppercase tracking-wider">ICU / Emergency</p>
                          <p className="font-bold text-gray-900">{bestRecommended.icu_facility_available ? 'Yes' : 'No'} / {bestRecommended.emergency_available ? 'Yes' : 'No'}</p>
                       </div>
                    </div>

                    <p className="p-4 bg-white/60 rounded-xl text-sm italic text-gray-600 border border-[#0d9e6e]/10 mb-8">
                       {t('reasonForRecommendation')}
                    </p>

                    {bestRecommended.urgency_level === 'High' && (
                       <div className="mb-8 p-4 bg-red-50 border-2 border-red-200 rounded-2xl flex items-start gap-4">
                          <Info className="w-6 h-6 text-red-600 shrink-0" />
                          <div>
                            <p className="font-black text-red-600 text-sm uppercase tracking-widest mb-1">{t('criticalAdvice')}</p>
                            <p className="text-red-700 font-bold leading-tight">{t('severeConditionWarning')}</p>
                          </div>
                       </div>
                    )}

                    <div className="flex flex-wrap gap-3">
                      <button 
                        onClick={() => onBookAppointment?.(bestRecommended.hospital_id, undefined, { name: selectedDiseaseName, price: bestRecommended.total_estimated_cost }, true)}
                        className="bg-[#0d9e6e] text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-[#0b8a60] transition-colors shadow-lg shadow-[#0d9e6e]/20"
                      >
                        <Calendar className="w-4 h-4" /> {t('bookAppointment')}
                      </button>
                      <button className="bg-white text-gray-900 border border-gray-200 px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-gray-50 transition-colors">
                        <Phone className="w-4 h-4 text-[#0d9e6e]" /> {t('callNow')}
                      </button>
                      <button className="bg-white text-gray-900 border border-gray-200 px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-gray-50 transition-colors">
                        <Navigation className="w-4 h-4 text-teal-600" /> {t('getRoute')}
                      </button>
                    </div>
                  </div>
                </div>

                <div className="space-y-6">
                  <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
                    <h4 className="font-bold text-gray-900 mb-4">{t('treatmentPriceEstimates')}</h4>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-gray-500">{t('consultationFee')}</span>
                        <span className="font-bold">₹{bestRecommended.consultation_fee}</span>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-gray-500">{t('testFee')}</span>
                        <span className="font-bold">₹{bestRecommended.diagnostic_test_fee}</span>
                      </div>
                      <div className="flex justify-between items-center text-sm">
                        <span className="text-gray-500">{t('medicineEstimate')}</span>
                        <span className="font-bold">₹{bestRecommended.medicine_estimate}</span>
                      </div>
                      <div className="flex justify-between items-center text-sm pb-4 border-b border-gray-50">
                        <span className="text-gray-500">{t('procedureEstimate')}</span>
                        <span className="font-bold">₹{bestRecommended.procedure_estimate}</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-gray-900">{t('avgCost')}</span>
                        <span className="font-black text-[#0d9e6e] text-lg">₹{bestRecommended.total_estimated_cost}</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-amber-50 p-6 rounded-3xl border border-amber-100">
                    <h4 className="font-bold text-amber-900 mb-3 flex items-center gap-2">
                       <Shield className="w-4 h-4" /> {t('insurance')} & {t('scheme')}
                    </h4>
                    <div className="space-y-2">
                      <p className="text-xs font-bold text-amber-800">
                        {bestRecommended.insurance_supported ? "✓ Private Insurance Accepted" : "× No Private Insurance"}
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {bestRecommended.schemes_supported.map(s => (
                          <a 
                            key={s} 
                            href={insuranceLinks[s] || '#'} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="bg-white px-2 py-0.5 rounded text-[10px] font-bold text-amber-700 border border-amber-200 hover:bg-amber-100 transition-colors"
                          >
                            {s}
                          </a>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Other Results Table */}
            <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
               <div className="p-6 border-b border-gray-50 flex justify-between items-center">
                  <h3 className="font-bold text-gray-900">{t('hospitalCostComparisonFor')} {selectedDiseaseName} ({matchedDiseases.length})</h3>
               </div>
               <div className="overflow-x-auto">
                 <table className="w-full">
                    <thead className="bg-gray-50/50">
                       <tr className="text-left">
                          <th className="p-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('severityLevel')}</th>
                           <th className="p-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('hospital')}</th>
                          <th className="p-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('district')}</th>
                          <th className="p-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('specialists')}</th>
                          <th className="p-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('minAmount')}</th>
                          <th className="p-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('maxAmount')}</th>
                          <th className="p-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('avgCost')}</th>
                          <th className="p-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('rating')}</th>
                          <th className="p-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('waitingTime')}</th>
                          <th className="p-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('insurance')}</th>
                          <th className="p-6 text-[10px] font-black text-gray-400 uppercase tracking-widest">{t('status')}</th>
                          <th className="p-6 text-[10px] font-black text-gray-400 uppercase tracking-widest"></th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                       {matchedDiseases.map(d => (
                         <tr key={d.id} className={cn("hover:bg-gray-50/50 transition-colors", d.id === bestRecommended?.id && "bg-[#0d9e6e]/5")}>
                             <td className="p-6">
                                <span className={cn(
                                  "text-[8px] font-black px-2 py-1 rounded-full uppercase tracking-tighter whitespace-nowrap shadow-sm",
                                  d.urgency_level === 'High' ? "bg-red-500 text-white" :
                                  d.urgency_level === 'Medium' ? "bg-amber-500 text-white" :
                                  "bg-[#0d9e6e] text-white"
                                )}>
                                  {t(d.urgency_level.toLowerCase() as any)}
                                </span>
                             </td>
                            <td className="p-6">
                               <div className="flex items-center gap-2">
                                 <p className="font-bold text-gray-900">{d.hospital_name}</p>
                                 {d.id === bestRecommended?.id && (
                                   <span className="bg-[#0d9e6e] text-white text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-tighter">
                                     {d.urgency_level === 'High' ? t('emergencyRecommended') : t('recommended')}
                                   </span>
                                 )}
                                 {d.total_estimated_cost === stats?.min && (
                                   <span className="bg-blue-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-tighter">
                                     {d.hospital_id.startsWith('gov') ? t('governmentOption') : t('budgetFriendly')}
                                   </span>
                                 )}
                                 {d.icu_facility_available && (
                                   <span className="bg-amber-600 text-white text-[8px] font-black px-1.5 py-0.5 rounded uppercase tracking-tighter">
                                     {t('icuAvailable')}
                                   </span>
                                 )}
                               </div>
                               <span className="text-[10px] text-gray-500 font-medium">{d.area}</span>
                            </td>
                            <td className="p-6">
                               <span className="text-sm font-medium text-gray-600">{d.district}</span>
                            </td>
                            <td className="p-6">
                               <span className="text-sm font-medium text-gray-600">{d.specialist_required}</span>
                            </td>
                            <td className={cn("p-6 text-sm font-bold", d.total_estimated_cost === stats?.min ? "text-green-600" : "text-gray-900")}>
                               ₹{d.min_estimated_cost}
                            </td>
                            <td className={cn("p-6 text-sm font-bold", d.total_estimated_cost === stats?.max ? "text-red-600" : "text-gray-900")}>
                               ₹{d.max_estimated_cost}
                            </td>
                            <td className="p-6">
                               <span className="text-lg font-black text-[#0d9e6e]">₹{d.total_estimated_cost}</span>
                               <div className="text-[9px] text-gray-400 mt-1 font-medium leading-tight">
                                 {t('consultationFee').split(' ')[0]}: ₹{d.consultation_fee} | 
                                 {t('diagnosticTestFee').split(' ')[0]}: ₹{d.diagnostic_test_fee} | 
                                 {t('medicineEstimate').split(' ')[0]}: ₹{d.medicine_estimate} | 
                                 {t('procedureEstimate').split(' ')[0]}: ₹{d.procedure_estimate}
                               </div>
                            </td>
                            <td className="p-6">
                               <div className="flex items-center gap-1 font-bold text-gray-900">
                                  {d.rating.toFixed(1)} <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                               </div>
                            </td>
                            <td className="p-6">
                               <span className="text-sm font-bold text-gray-900">{d.waiting_time_mins} {t('mins')}</span>
                            </td>
                            <td className="p-6">
                               <div className="flex flex-col gap-1">
                                 <span className={cn("text-[8px] font-black uppercase px-1.5 py-0.5 rounded w-fit", d.insurance_supported ? "bg-blue-50 text-blue-600" : "bg-gray-50 text-gray-400")}>
                                   {d.insurance_supported ? "YES" : "NO"}
                                 </span>
                                 {d.insurance_supported && d.schemes_supported.length > 0 && (
                                   <div className="flex flex-wrap gap-1">
                                     {d.schemes_supported.map(s => (
                                       <a 
                                         key={s} 
                                         href={insuranceLinks[s] || '#'} 
                                         target="_blank" 
                                         rel="noopener noreferrer"
                                         className="text-[7px] font-bold text-blue-500 hover:underline"
                                       >
                                         {s}
                                       </a>
                                     ))}
                                   </div>
                                 )}
                               </div>
                            </td>
                            <td className="p-6">
                               <div className="flex items-center gap-2">
                                  {d.emergency_available && <Award className="w-4 h-4 text-red-500" title="Emergency Available" />}
                                  {d.icu_facility_available && <Shield className="w-4 h-4 text-blue-500" title="ICU Available" />}
                                  {d.doctor_available && <Check className="w-4 h-4 text-[#0d9e6e]" title="Doctor Available" />}
                               </div>
                            </td>
                            <td className="p-6 text-right">
                               <div className="flex gap-2 justify-end">
                                 <button className="bg-[#0d9e6e]/10 text-[#0d9e6e] p-2 rounded-lg hover:bg-[#0d9e6e]/20 transition-all">
                                   <Phone className="w-4 h-4" />
                                 </button>
                                 <button className="bg-teal-50 text-teal-600 p-2 rounded-lg hover:bg-teal-100 transition-all">
                                   <Navigation className="w-4 h-4" />
                                 </button>
                                 <button 
                                   onClick={() => onBookAppointment?.(d.hospital_id, undefined, { name: selectedDiseaseName, price: d.total_estimated_cost }, true)}
                                   className="bg-gray-900 text-white px-4 py-2 rounded-lg text-xs font-bold hover:bg-black transition-all"
                                 >
                                    {t('bookNow')}
                                 </button>
                               </div>
                            </td>
                         </tr>
                       ))}
                    </tbody>
                 </table>
                 {matchedDiseases.length === 0 && (
                   <div className="p-20 text-center">
                      <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                         <Search className="w-8 h-8 text-gray-300" />
                      </div>
                      <p className="text-gray-500 font-bold">{t('noResults')}</p>
                      <p className="text-gray-400 text-sm">{t('adjustFilters')}</p>
                   </div>
                 )}
               </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
};
