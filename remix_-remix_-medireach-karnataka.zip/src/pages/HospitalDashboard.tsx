import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Users, Calendar, ArrowLeftRight, CheckCircle2, XCircle, 
  Eye, LogOut, LayoutDashboard, Search, Bell, Clock, Building2,
  Phone, User as UserIcon, Shield, Activity, Pill, AlertCircle, FileText
} from 'lucide-react';
import { cn } from '../lib/utils';
import { useLanguage } from '../contexts/LanguageContext';

interface HospitalDashboardProps {
  hospitalUser: { id: string, name: string };
  onLogout: () => void;
}

export const HospitalDashboard: React.FC<HospitalDashboardProps> = ({ hospitalUser, onLogout }) => {
  const [activeTab, setActiveTab] = useState<'records' | 'appointments' | 'transfers'>('records');
  const { t } = useLanguage();

  const [patients, setPatients] = useState<any[]>([]);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [transfers, setTransfers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [patientsRes, appointmentsRes, transfersRes] = await Promise.all([
          fetch('/api/hospital/patients'),
          fetch('/api/hospital/appointments'),
          fetch('/api/hospital/transfers')
        ]);
        
        if (patientsRes.ok) setPatients(await patientsRes.json());
        if (appointmentsRes.ok) setAppointments(await appointmentsRes.json());
        if (transfersRes.ok) setTransfers(await transfersRes.json());
      } catch (err) {
        console.error("Hospital dashboard fetch error:", err);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const updateAppointmentStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/hospital/appointments/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        setAppointments(prev => prev.map(apt => apt.id === id ? { ...apt, status } : apt));
      }
    } catch (err) {
      console.error("Update appointment error:", err);
    }
  };

  const updateTransferStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/hospital/transfers/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        setTransfers(prev => prev.map(trn => trn.id === id ? { ...trn, status } : trn));
      }
    } catch (err) {
      console.error("Update transfer error:", err);
    }
  };

  const [selectedPatient, setSelectedPatient] = useState<any>(null);

  return (
    <div className="min-h-screen bg-[#f8fafb] flex">
      {/* Sidebar */}
      <div className="w-80 bg-white border-r border-slate-200 flex flex-col p-8 fixed h-full z-20">
        <div className="flex items-center gap-3 mb-10 px-2">
          <div className="w-10 h-10 bg-[#0d9e6e] rounded-xl flex items-center justify-center text-white font-black">H</div>
          <h1 className="text-xl font-black text-slate-800 italic uppercase tracking-tight">MediReach <span className="text-[#0d9e6e]">Network</span></h1>
        </div>

        <div className="space-y-2 flex-grow">
          <button 
            onClick={() => setActiveTab('records')}
            className={cn(
              "w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-sm font-black uppercase tracking-widest transition-all",
              activeTab === 'records' ? "bg-slate-900 text-white shadow-xl shadow-slate-900/20" : "text-slate-400 hover:bg-slate-50"
            )}
          >
            <Users className="w-5 h-5" /> {t('hosp_patientRecords')}
          </button>
          <button 
            onClick={() => setActiveTab('appointments')}
            className={cn(
              "w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-sm font-black uppercase tracking-widest transition-all",
              activeTab === 'appointments' ? "bg-slate-900 text-white shadow-xl shadow-slate-900/20" : "text-slate-400 hover:bg-slate-50"
            )}
          >
            <Calendar className="w-5 h-5" /> {t('hosp_appointments')}
          </button>
          <button 
            onClick={() => setActiveTab('transfers')}
            className={cn(
              "w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-sm font-black uppercase tracking-widest transition-all",
              activeTab === 'transfers' ? "bg-slate-900 text-white shadow-xl shadow-slate-900/20" : "text-slate-400 hover:bg-slate-50"
            )}
          >
            <ArrowLeftRight className="w-5 h-5" /> {t('hosp_transferRequests')}
          </button>
        </div>

        <div className="pt-8 border-t border-slate-100">
          <div className="bg-slate-50 p-6 rounded-[32px] mb-6">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-[#0d9e6e] shadow-sm">
                <Building2 className="w-6 h-6" />
              </div>
              <div className="overflow-hidden">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{hospitalUser.id}</p>
                <p className="text-sm font-black text-slate-800 italic line-clamp-1">{hospitalUser.name}</p>
              </div>
            </div>
            <button 
              onClick={onLogout}
              className="w-full flex items-center justify-center gap-2 py-3 bg-red-50 text-red-600 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-red-100 transition-colors"
            >
              <LogOut className="w-4 h-4" /> {t('logout')}
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 ml-80 p-12">
        <header className="flex justify-between items-center mb-12">
          <div>
            <h2 className="text-3xl font-black text-slate-800 italic uppercase tracking-tight">{t(activeTab === 'records' ? 'hosp_patientRecords' : activeTab === 'appointments' ? 'hosp_appointments' : 'hosp_transferRequests')}</h2>
            <p className="text-slate-400 font-bold mt-1 uppercase tracking-widest text-[10px]">Hospital Administration Dashboard • Real-time Data Sync</p>
          </div>
          <div className="flex items-center gap-6">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-300" />
              <input 
                type="text" 
                placeholder="Search resources..."
                className="w-72 h-12 bg-white border border-slate-200 rounded-2xl pl-12 pr-6 outline-none font-bold text-sm focus:ring-2 focus:ring-[#0d9e6e]/10 transition-all font-sans"
              />
            </div>
            <button className="w-12 h-12 bg-white border border-slate-200 rounded-2xl flex items-center justify-center text-slate-400 relative">
              <Bell className="w-5 h-5" />
              <div className="absolute top-3 right-3 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></div>
            </button>
          </div>
        </header>

        <AnimatePresence mode="wait">
          {activeTab === 'records' && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-6">
              <div className="bg-white rounded-[40px] border border-slate-200 shadow-sm overflow-hidden">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-100">
                      <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('patientName')}</th>
                      <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">ID</th>
                      <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('hosp_age')}</th>
                      <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('bloodGroup')}</th>
                      <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('insurance')}</th>
                      <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest"></th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {patients.map(p => (
                      <tr key={p.id} className="hover:bg-slate-50/50 transition-colors group">
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-4">
                            <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600 font-black text-sm uppercase">{p.name.charAt(0)}</div>
                            <span className="text-sm font-black text-slate-800 italic uppercase tracking-tight">{p.name}</span>
                          </div>
                        </td>
                        <td className="px-8 py-6 text-xs font-bold text-slate-500 uppercase tracking-widest">{p.id}</td>
                        <td className="px-8 py-6 text-sm font-black text-slate-700">{p.age} Y</td>
                        <td className="px-8 py-6">
                          <span className="px-2 py-1 bg-red-50 text-red-600 text-[10px] font-black rounded-lg uppercase tracking-widest border border-red-100">{p.blood}</span>
                        </td>
                        <td className="px-8 py-6 text-[10px] font-black text-slate-400 uppercase tracking-widest">{p.insurance}</td>
                        <td className="px-8 py-6 text-right">
                          <button 
                            onClick={() => setSelectedPatient(p)}
                            className="bg-white border border-slate-200 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest text-[#0d9e6e] opacity-0 group-hover:opacity-100 transition-all hover:bg-[#0d9e6e] hover:text-white"
                          >
                            {t('hosp_viewPatientRecord')}
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </motion.div>
          )}

          {activeTab === 'appointments' && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-6">
              <div className="grid grid-cols-1 gap-4">
                {appointments.map(apt => (
                  <div key={apt.id} className="bg-white p-8 rounded-[36px] border border-slate-200 shadow-sm flex items-center justify-between group">
                    <div className="flex items-center gap-8">
                       <div className="flex flex-col items-center justify-center w-20 h-20 bg-slate-50 rounded-[24px] border-2 border-dashed border-slate-200">
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Date</p>
                          <p className="text-xs font-black text-slate-800">{apt.date}</p>
                       </div>
                       <div>
                          <div className="flex items-center gap-3 mb-2">
                             <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest bg-slate-50 px-2 py-0.5 rounded-lg border border-slate-100">{apt.id}</span>
                             <span className={cn(
                               "px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-widest border",
                               apt.status === 'Pending' ? "bg-amber-50 text-amber-600 border-amber-100" :
                               apt.status === 'Confirmed' ? "bg-blue-50 text-blue-600 border-blue-100" :
                               apt.status === 'Completed' ? "bg-[#0d9e6e]/10 text-[#0d9e6e] border-[#0d9e6e]/20" :
                               "bg-red-50 text-red-600 border-red-100"
                             )}>{t(apt.status.toLowerCase() as any)}</span>
                          </div>
                          <h3 className="text-xl font-black text-slate-800 italic uppercase tracking-tight mb-2">{apt.patient}</h3>
                          <div className="flex items-center gap-6">
                             <div className="flex items-center gap-2 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                               <UserIcon className="w-3.5 h-3.5 text-[#0d9e6e]" /> {apt.doctor}
                             </div>
                             <div className="flex items-center gap-2 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                               <Shield className="w-3.5 h-3.5 text-blue-500" /> {apt.dept}
                             </div>
                             <div className="flex items-center gap-2 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                               <Clock className="w-3.5 h-3.5 text-slate-300" /> {apt.time}
                             </div>
                          </div>
                       </div>
                    </div>
                    
                    <div className="flex items-center gap-3">
                       {apt.status === 'Pending' && (
                         <button 
                           onClick={() => updateAppointmentStatus(apt.id, 'Confirmed')}
                           className="bg-[#0d9e6e] text-white px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-[#0d9e6e]/20 hover:scale-105 transition-all"
                         >
                           {t('hosp_confirmAppointment')}
                         </button>
                       )}
                       {apt.status === 'Confirmed' && (
                         <button 
                           onClick={() => updateAppointmentStatus(apt.id, 'Completed')}
                           className="bg-slate-900 text-white px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-slate-900/20 hover:scale-105 transition-all"
                         >
                           {t('hosp_markCompleted')}
                         </button>
                       )}
                       {(apt.status === 'Pending' || apt.status === 'Confirmed') && (
                         <button 
                           onClick={() => updateAppointmentStatus(apt.id, 'Cancelled')}
                           className="bg-white border border-slate-200 text-red-500 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-red-50 transition-all"
                         >
                           {t('hosp_cancelAppointment')}
                         </button>
                       )}
                       {apt.status === 'Completed' && (
                         <div className="flex items-center gap-2 text-[#0d9e6e] bg-[#0d9e6e]/5 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-[#0d9e6e]/20">
                            <CheckCircle2 className="w-4 h-4" /> {t('hosp_completed')}
                         </div>
                       )}
                       {apt.status === 'Cancelled' && (
                         <div className="flex items-center gap-2 text-red-500 bg-red-50 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-red-100">
                            <XCircle className="w-4 h-4" /> {t('hosp_cancelled')}
                         </div>
                       )}
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {activeTab === 'transfers' && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="space-y-6">
              <div className="grid grid-cols-1 gap-6">
                {transfers.map(trn => (
                  <div key={trn.id} className="bg-white p-10 rounded-[48px] border border-slate-200 shadow-sm relative overflow-hidden group">
                    <div className="flex justify-between items-start relative z-10">
                      <div className="space-y-8">
                        <div>
                          <div className="flex items-center gap-3 mb-3">
                            <span className="px-3 py-1 bg-slate-100 text-[10px] font-black text-slate-400 rounded-lg uppercase tracking-widest">{trn.id}</span>
                            <span className={cn(
                               "px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-widest",
                               trn.status === 'Pending' ? "bg-amber-100 text-amber-600" : "bg-blue-100 text-blue-600"
                             )}>{t(trn.status.toLowerCase() as any)}</span>
                          </div>
                          <h3 className="text-3xl font-black text-slate-800 italic uppercase tracking-tight mb-4">{trn.patient}</h3>
                          
                          <div className="flex items-center gap-12">
                             <div className="flex flex-col">
                               <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1">Source Hospital</p>
                               <div className="flex items-center gap-2 text-sm font-black text-slate-600 uppercase tracking-tight italic">
                                  <Building2 className="w-4 h-4 text-[#0d9e6e]" /> {trn.from}
                               </div>
                             </div>
                             <div className="w-px h-10 bg-slate-100"></div>
                             <div className="flex flex-col">
                               <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1">Records Requested</p>
                               <div className="flex items-center gap-2 text-sm font-black text-slate-600 uppercase tracking-tight italic">
                                  <FileText className="w-4 h-4 text-blue-500" /> {trn.records}
                               </div>
                             </div>
                             <div className="w-px h-10 bg-slate-100"></div>
                             <div className="flex flex-col">
                               <p className="text-[10px] font-black text-slate-300 uppercase tracking-widest mb-1">Consent Status</p>
                               <div className="flex items-center gap-2 text-sm font-black text-[#0d9e6e] uppercase tracking-tight italic">
                                  <Shield className="w-4 h-4 text-[#0d9e6e]" /> {trn.consent}
                               </div>
                             </div>
                          </div>
                        </div>

                        {trn.status === 'Pending' && (
                          <div className="flex items-center gap-4">
                            <button 
                              onClick={() => updateTransferStatus(trn.id, 'Received')}
                              className="bg-[#0d9e6e] text-white px-10 py-4 rounded-2xl font-black text-sm uppercase tracking-widest shadow-xl shadow-[#0d9e6e]/20 hover:scale-105 transition-all"
                            >
                              {t('hosp_acceptTransfer')}
                            </button>
                            <button 
                              onClick={() => updateTransferStatus(trn.id, 'Rejected')}
                              className="bg-white border-2 border-slate-100 text-slate-400 px-10 py-4 rounded-2xl font-black text-sm uppercase tracking-widest hover:border-red-100 hover:text-red-500 transition-all"
                            >
                              {t('hosp_rejectTransfer')}
                            </button>
                          </div>
                        )}
                        {trn.status === 'Received' && (
                          <div className="flex items-center gap-2 text-[#0d9e6e] bg-[#0d9e6e]/5 px-8 py-4 rounded-2xl font-black text-sm uppercase tracking-widest border border-[#0d9e6e]/20 w-fit">
                            <CheckCircle2 className="w-5 h-5" /> {t('received')}
                          </div>
                        )}
                      </div>
                      
                      <div className="bg-slate-50 p-8 rounded-[40px] border border-slate-100 max-w-xs">
                         <div className="flex items-center gap-3 mb-4">
                            <Bell className="w-5 h-5 text-amber-500" />
                            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Network Alert</h4>
                         </div>
                         <p className="text-xs font-bold text-slate-500 leading-relaxed italic">
                           "System verified: Patient Basavaraju M. has authorized digital record sync via blockchain key #MYS-9482."
                         </p>
                      </div>
                    </div>
                    <div className="absolute top-0 right-0 w-64 h-64 bg-slate-50 rounded-full -mr-32 -mt-32 opacity-30" />
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Patient Profile Modal */}
      <AnimatePresence>
        {selectedPatient && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-6 sm:p-12">
            <motion.div 
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }} 
              exit={{ opacity: 0 }} 
              onClick={() => setSelectedPatient(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-4xl bg-white rounded-[56px] shadow-2xl overflow-hidden"
            >
              <div className="p-10 md:p-14 overflow-y-auto max-h-[90vh]">
                <div className="flex justify-between items-start mb-12">
                   <div className="flex items-center gap-8">
                      <div className="w-24 h-24 bg-blue-50 rounded-[32px] flex items-center justify-center text-blue-600 font-black text-3xl shadow-inner">{selectedPatient.name.charAt(0)}</div>
                      <div>
                         <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{selectedPatient.id}</p>
                         <h2 className="text-4xl font-black text-slate-800 italic uppercase tracking-tight">{selectedPatient.name}</h2>
                         <div className="flex items-center gap-6 mt-4">
                            <div className="flex items-center gap-2 text-slate-500 font-black text-[10px] uppercase tracking-widest">
                               <Activity className="w-4 h-4 text-[#0d9e6e]" /> {selectedPatient.age} {t('hosp_age')}
                            </div>
                            <div className="flex items-center gap-2 text-slate-500 font-black text-[10px] uppercase tracking-widest">
                               <Shield className="w-4 h-4 text-red-500" /> {selectedPatient.blood} {t('bloodGroup')}
                            </div>
                            <div className="flex items-center gap-2 text-slate-500 font-black text-[10px] uppercase tracking-widest">
                               <Phone className="w-4 h-4 text-blue-500" /> {selectedPatient.phone}
                            </div>
                         </div>
                      </div>
                   </div>
                   <button 
                     onClick={() => setSelectedPatient(null)}
                     className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-400 hover:text-slate-800 transition-colors"
                   >
                     <XCircle className="w-6 h-6" />
                   </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                   <div className="space-y-10">
                      <div className="bg-slate-50 p-8 rounded-[40px] border border-slate-100">
                         <h4 className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6"><AlertCircle className="w-4 h-4 text-amber-500" /> {t('hosp_chronicConditions')}</h4>
                         <p className="text-xl font-black text-slate-800 italic uppercase tracking-tight">{selectedPatient.chronic}</p>
                      </div>
                      <div className="bg-slate-50 p-8 rounded-[40px] border border-slate-100">
                         <h4 className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6"><Shield className="w-4 h-4 text-red-500" /> {t('knownAllergies')}</h4>
                         <p className="text-xl font-black text-red-600 italic uppercase tracking-tight">{selectedPatient.allergies}</p>
                      </div>
                   </div>
                   <div className="space-y-10">
                      <div className="bg-slate-50 p-8 rounded-[40px] border border-slate-100">
                         <h4 className="flex items-center gap-2 text-[10px] font-black text-slate-400 uppercase tracking-widest mb-6"><Pill className="w-4 h-4 text-[#0d9e6e]" /> {t('hosp_currentMedications')}</h4>
                         <p className="text-xl font-black text-[#0d9e6e] italic uppercase tracking-tight">{selectedPatient.meds}</p>
                      </div>
                      <div className="bg-slate-900 p-8 rounded-[40px] text-white overflow-hidden relative group">
                         <h4 className="flex items-center gap-2 text-[10px] font-black text-white/40 uppercase tracking-widest mb-6 relative z-10"><Shield className="w-4 h-4 text-blue-400" /> {t('insuranceDetails') || t('insurance')}</h4>
                         <p className="text-xl font-black italic uppercase tracking-tight relative z-10">{selectedPatient.insurance}</p>
                         <div className="absolute -right-8 -top-8 w-32 h-32 bg-white/10 rounded-full blur-3xl group-hover:scale-125 transition-transform" />
                      </div>
                   </div>
                </div>

                <div className="mt-12 pt-10 border-t border-slate-100">
                   <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-8 px-2">{t('recentMedicalRecords')}</h4>
                   <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                      {[
                        { title: 'Lab Report', date: 'Jan 2026', icon: <Activity className="w-5 h-5" /> },
                        { title: 'Cardiology', date: 'Dec 2025', icon: <Activity className="w-5 h-5" /> },
                        { title: 'Vaccination', date: 'Nov 2025', icon: <FileText className="w-5 h-5" /> },
                      ].map((doc, i) => (
                        <div key={i} className="flex items-center gap-4 p-5 bg-white border border-slate-100 rounded-2xl hover:border-[#0d9e6e] cursor-pointer transition-all hover:translate-y-1">
                           <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center text-slate-400">{doc.icon}</div>
                           <div>
                              <p className="text-xs font-black text-slate-800 uppercase tracking-tight">{doc.title}</p>
                              <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest">{doc.date}</p>
                           </div>
                        </div>
                      ))}
                   </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
