import React, { useState, useMemo, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { Search, Filter, Phone, MapPin, Star, Clock, Shield, Award, ChevronRight, Navigation, IndianRupee } from 'lucide-react';
import { HOSPITALS } from '../data';
import { cn } from '../lib/utils';
import { useLanguage } from '../contexts/LanguageContext';

// Controller to handle programmatic map pan/zoom
const MapController = ({ center, zoom }: { center: [number, number], zoom: number }) => {
  const map = useMap();
  useEffect(() => {
    map.setView(center, zoom, { animate: true });
  }, [center, zoom, map]);
  return null;
};

// Fix for Leaflet default icon issues in React
const defaultIcon = L.icon({
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

L.Marker.prototype.options.icon = defaultIcon;

interface FindHospitalsProps {
  onHospitalSelect: (id: string) => void;
  onBookAppointment: (hospitalId: string) => void;
}

export const FindHospitals: React.FC<FindHospitalsProps> = ({ onHospitalSelect, onBookAppointment }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('Bengaluru Urban');
  const [selectedType, setSelectedType] = useState<string>('All');
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>('All');
  const [sortBy, setSortBy] = useState<string>('distance');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const { t } = useLanguage();
  
  const districtCenters: { [key: string]: { center: [number, number], zoom: number } } = {
    'Mysuru': { center: [12.2958, 76.6394], zoom: 13 },
    'Bengaluru Urban': { center: [12.9716, 77.5946], zoom: 12 },
    'Mandya': { center: [12.5222, 76.8973], zoom: 14 },
    'Hassan': { center: [13.0068, 76.1027], zoom: 14 },
    'Tumakuru': { center: [13.3379, 77.1179], zoom: 14 },
    'Chamarajanagar': { center: [11.9261, 76.9437], zoom: 13 }
  };

  const [mapConfig, setMapConfig] = useState(districtCenters['Bengaluru Urban']);

  const districts = ['Mysuru', 'Bengaluru Urban', 'Mandya', 'Hassan', 'Tumakuru', 'Chamarajanagar'];

  const filteredHospitals = useMemo(() => {
    return HOSPITALS.filter(h => {
      const matchesDistrict = h.district === selectedDistrict;
      const matchesSearch = h.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           h.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           h.area.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesType = selectedType === 'All' || h.type === selectedType;
      const matchesSpecialty = selectedSpecialty === 'All' || h.specialties.includes(selectedSpecialty);
      return matchesDistrict && matchesSearch && matchesType && matchesSpecialty;
    }).sort((a, b) => {
      if (sortBy === 'distance') return a.distance_km - b.distance_km;
      if (sortBy === 'rating') return b.rating - a.rating;
      if (sortBy === 'fee') return a.avg_fee - b.avg_fee;
      return 0;
    });
  }, [selectedDistrict, searchQuery, selectedType, selectedSpecialty, sortBy]);

  const handleDistrictChange = (district: string) => {
    setSelectedDistrict(district);
    setMapConfig(districtCenters[district]);
  };

  const handleGetDirections = (lat: number, lng: number) => {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, '_blank');
  };

  return (
    <div className="flex flex-col lg:flex-row h-[calc(100vh-100px)] md:h-[calc(100vh-104px)] overflow-hidden font-sans">
      {/* Search & Filter Sidebar */}
      <div className="w-full lg:w-96 bg-white border-r border-slate-200 flex flex-col h-full shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 bg-white z-10">
          <h2 className="text-xl font-black text-slate-800 mb-6 flex items-center gap-2 uppercase tracking-tight font-display">
            {t('findCareCenters')}
          </h2>
          
          <div className="space-y-4 mb-6">
            <div>
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">{t('selectDistrict')}</label>
              <select 
                value={selectedDistrict}
                onChange={(e) => handleDistrictChange(e.target.value)}
                className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-[#0d9e6e]/20 transition-all font-sans"
              >
                {districts.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
              <input
                type="text"
                placeholder={`${t('search')}...`}
                className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#0d9e6e] outline-none transition-all bg-slate-50/30 font-medium text-sm font-sans"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {[t('all'), t('government'), t('private'), t('trust')].map(type => (
              <button 
                key={type}
                onClick={() => setSelectedType(type === t('all') ? 'All' : type === t('government') ? 'Government' : type === t('private') ? 'Private' : 'Trust')}
                className={cn(
                  "px-3 py-1.5 text-[9px] uppercase font-black rounded-lg border-2 transition-all tracking-wider", 
                  (selectedType === 'All' && type === t('all')) || (selectedType === 'Government' && type === t('government')) || (selectedType === 'Private' && type === t('private')) || (selectedType === 'Trust' && type === t('trust'))
                    ? "bg-[#0d9e6e] text-white border-[#0d9e6e]" 
                    : "bg-white text-slate-500 border-slate-100 hover:border-slate-300"
                )}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          <div className="flex items-center justify-between px-2 mb-2">
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">{filteredHospitals.length} {t('matchingFacilities')}</span>
            <select 
              className="text-[10px] font-black text-[#0d9e6e] bg-transparent outline-none cursor-pointer uppercase tracking-widest border-none"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              <option value="distance">{t('distanceFirst')}</option>
              <option value="rating">{t('topRated')}</option>
              <option value="fee">{t('budgetFirst')}</option>
            </select>
          </div>

          <div className="space-y-4 pb-20">
            {filteredHospitals.length > 0 ? filteredHospitals.map((hospital) => (
              <div 
                key={hospital.id}
                onClick={() => {
                  setSelectedId(hospital.id);
                  setMapConfig({ center: [hospital.lat, hospital.lng], zoom: 15 });
                }}
                className={cn(
                  "p-5 rounded-2xl border-2 transition-all cursor-pointer group relative overflow-hidden",
                  selectedId === hospital.id ? "border-[#0d9e6e] bg-[#0d9e6e]/5 shadow-sm" : "border-slate-50 bg-white hover:border-slate-200"
                )}
              >
                <div className="flex justify-between items-start mb-3">
                  <div className="flex gap-2">
                    <div className="bg-[#0d9e6e]/10 text-[#0d9e6e] text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-wider">
                      {hospital.type === 'Government' ? t('government') : hospital.type === 'Private' ? t('private') : t('trust')}
                    </div>
                    {hospital.emergency && (
                      <div className="bg-red-50 text-red-600 text-[9px] font-black px-2 py-0.5 rounded flex items-center gap-1 uppercase tracking-wider">
                        <div className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse" /> 24/7 ER
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                    <span className="text-xs font-black text-slate-700">{hospital.rating.toFixed(1)}</span>
                  </div>
                </div>
                <h3 className="hospital-name text-lg text-slate-800 mb-2 group-hover:text-[#0d9e6e] transition-colors">{hospital.name}</h3>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter mb-4 flex items-center gap-2">
                  <MapPin className="w-3 h-3 text-[#0d9e6e]" /> {hospital.area} • {(hospital.distance_km).toFixed(1)} KM
                </p>
                
                <div className="flex items-center gap-4 mb-5 border-t border-slate-100 pt-4">
                  <div className="flex flex-col">
                    <span className="text-[8px] uppercase font-black text-slate-400 tracking-widest mb-0.5">{t('averageFee')}</span>
                    <span className="text-[11px] font-black text-slate-800">₹{hospital.avg_fee === 0 ? t('free') : hospital.avg_fee}</span>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[8px] uppercase font-black text-slate-400 tracking-widest mb-0.5">{t('specialty')}</span>
                    <span className="text-[11px] font-black text-slate-800">{hospital.specialties.length} {t('core')}</span>
                  </div>
                </div>

                <div className="flex gap-2 relative z-20">
                  <button 
                    onClick={(e) => { e.stopPropagation(); handleGetDirections(hospital.lat, hospital.lng); }}
                    className="p-2.5 bg-slate-100 rounded-xl hover:bg-slate-200 transition-colors text-slate-600"
                    title={t('getDirections')}
                  >
                    <Navigation className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); onHospitalSelect(hospital.id); }}
                    className="flex-1 py-2.5 text-[10px] font-black uppercase tracking-widest text-slate-600 bg-slate-50 rounded-xl hover:bg-slate-100 transition-colors border border-slate-100"
                  >
                    {t('details')}
                  </button>
                  <button 
                    onClick={(e) => { e.stopPropagation(); onBookAppointment(hospital.id); }}
                    className="flex-1 py-2.5 text-[10px] font-black uppercase tracking-widest text-white bg-[#0d9e6e] rounded-xl hover:bg-[#0bc385] shadow-lg shadow-[#0d9e6e]/20 transition-all active:scale-95"
                  >
                    {t('booking')}
                  </button>
                </div>
              </div>
            )) : (
              <div className="py-20 text-center">
                <Search className="w-12 h-12 text-slate-200 mx-auto mb-4" />
                <p className="text-slate-400 font-bold italic uppercase text-xs font-sans">{t('noFacilitiesMatched')}</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Map View */}
      <div className="flex-1 bg-gray-100 relative z-0">
        <MapContainer 
          center={mapConfig.center} 
          zoom={mapConfig.zoom} 
          style={{ height: '100%', width: '100%' }}
        >
          <MapController center={mapConfig.center} zoom={mapConfig.zoom} />
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          {filteredHospitals.map((hospital) => (
            <Marker 
              key={hospital.id} 
              position={[hospital.lat, hospital.lng]}
              eventHandlers={{
                click: () => {
                  setSelectedId(hospital.id);
                  setMapConfig({ center: [hospital.lat, hospital.lng], zoom: 15 });
                },
              }}
            >
              <Popup>
                <div className="p-1 font-sans">
                  <h4 className="hospital-name text-sm text-gray-900 mb-1">{hospital.name}</h4>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-[10px] font-bold bg-[#0d9e6e] text-white px-1.5 py-0.5 rounded">
                      {hospital.type === 'Government' ? t('government') : hospital.type === 'Private' ? t('private') : t('trust')}
                    </span>
                    <span className="text-[10px] font-bold text-gray-600 flex items-center gap-0.5">
                      <Star className="w-2.5 h-2.5 text-amber-500 fill-amber-500" /> {hospital.rating.toFixed(1)}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <button 
                      onClick={() => onHospitalSelect(hospital.id)}
                      className="py-1.5 bg-slate-800 text-white text-[10px] font-bold rounded flex items-center justify-center gap-1 hover:bg-slate-900 transition-colors"
                    >
                      {t('profile')} <ChevronRight className="w-3 h-3" />
                    </button>
                    <button 
                      onClick={() => handleGetDirections(hospital.lat, hospital.lng)}
                      className="py-1.5 bg-[#0d9e6e] text-white text-[10px] font-bold rounded flex items-center justify-center gap-1 hover:bg-[#0bc385] transition-colors"
                    >
                      <Navigation className="w-3 h-3" /> {t('directions')}
                    </button>
                  </div>
                </div>
              </Popup>
            </Marker>
          ))}
        </MapContainer>

        {/* Quick Location Buttons for Districts */}
        <div className="absolute bottom-6 left-6 right-6 md:right-auto flex gap-2 overflow-x-auto pb-2 scrollbar-hide z-[1000] px-4">
          {districts.map(d => (
            <button 
              key={d}
              onClick={() => handleDistrictChange(d)}
              className={cn(
                "px-4 py-2 rounded-full shadow-lg text-xs font-black uppercase tracking-widest flex items-center gap-2 whitespace-nowrap transition-all",
                selectedDistrict === d ? "bg-[#0d9e6e] text-white" : "bg-white text-slate-600 hover:bg-slate-50"
              )}
            >
              <MapPin className="w-3.5 h-3.5" /> {d}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
