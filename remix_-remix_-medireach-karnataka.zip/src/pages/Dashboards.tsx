import React, { useState } from 'react';
import { LayoutGrid, Users, Phone, ShieldCheck, CheckCircle, XCircle, TrendingUp, Hospital, UserCog, Stethoscope, ChevronRight } from 'lucide-react';
import { HOSPITALS, DOCTORS } from '../data';
import { cn } from '../lib/utils';
import { useLanguage } from '../contexts/LanguageContext';

export const AdminDashboard: React.FC = () => {
  const { t } = useLanguage();
  const [transfers, setTransfers] = useState<any[]>(() => {
    const saved = localStorage.getItem('medireach_transfers');
    return saved ? JSON.parse(saved) : [
      { id: 'TX78901234', patientName: 'Rahul Sharma', from: 'JSS Hospital', to: 'Manipal Hospital', status: 'In Transit', date: '2024-05-20' },
      { id: 'TX78901235', patientName: 'Priya Verma', from: 'KR Hospital', to: 'Apollo BGS', status: 'Pending', date: '2024-05-21' },
      { id: 'TX78901236', patientName: 'Ananya Rao', from: 'Fortis Hospital', to: 'Victoria Hospital', status: 'Received', date: '2024-05-19' }
    ];
  });

  const stats = [
    { label: t('totalHospitals'), value: HOSPITALS.length, icon: <Hospital className="w-5 h-5" />, color: 'bg-blue-500' },
    { label: t('totalDoctors'), value: DOCTORS.length, icon: <Stethoscope className="w-5 h-5" />, color: 'bg-teal-500' },
    { label: t('pendingTransfers'), value: transfers.filter(t => t.status === 'Pending').length, icon: <TrendingUp className="w-5 h-5" />, color: 'bg-amber-500' },
    { label: t('activeAdmissions'), value: 124, icon: <Users className="w-5 h-5" />, color: 'bg-purple-500' },
  ];

  return (
    <div className="bg-[#f8fafb] min-h-screen py-12 px-4 md:px-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex items-center justify-between">
          <h1 className="text-3xl font-black text-slate-800 tracking-tight font-display">MediReach <span className="text-[#0d9e6e]">{t('commandCenter')}</span></h1>
          <button className="bg-slate-900 text-white px-6 py-2 rounded-xl text-sm font-bold flex items-center gap-2 shadow-lg shadow-slate-200">
            <UserCog className="w-4 h-4" /> {t('adminControls')}
          </button>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((s, i) => (
            <div key={i} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
              <div className={`w-10 h-10 ${s.color} text-white rounded-xl flex items-center justify-center mb-4 shadow-lg shadow-${s.color.split('-')[1]}-200`}>
                {s.icon}
              </div>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{s.label}</p>
              <h3 className="text-2xl font-black text-slate-800 tracking-tight">{s.value}</h3>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm">
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-xl font-black text-slate-800 font-display">{t('secureDataTransferLog')}</h3>
                <span className="px-3 py-1 bg-[#0d9e6e]/10 text-[#0d9e6e] text-[10px] font-black uppercase rounded-full tracking-widest">{t('liveUpdates')}</span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="text-left border-b border-slate-50">
                      <th className="pb-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('id')}</th>
                      <th className="pb-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('patient')}</th>
                      <th className="pb-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('route')}</th>
                      <th className="pb-4 text-[10px] font-black text-slate-400 uppercase tracking-widest">{t('status')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {transfers.map((t_item, i) => (
                      <tr key={i} className="group">
                        <td className="py-4 text-xs font-black text-slate-400 font-mono">#{t_item.id.slice(-6)}</td>
                        <td className="py-4">
                          <p className="text-sm font-black text-slate-800">{t_item.patientName}</p>
                          <p className="text-[10px] text-slate-400 font-bold">{t_item.date}</p>
                        </td>
                        <td className="py-4">
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-slate-600">{t_item.from}</span>
                            <ChevronRight className="w-3 h-3 text-slate-300" />
                            <span className="text-xs font-bold text-slate-600">{t_item.to}</span>
                          </div>
                        </td>
                        <td className="py-4">
                          <span className={cn(
                            "px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest",
                            t_item.status === 'Pending' ? "bg-amber-100 text-amber-600" :
                            t_item.status === 'In Transit' ? "bg-blue-100 text-blue-600" :
                            "bg-green-100 text-green-600"
                          )}>
                            {t(t_item.status.toLowerCase().replace(/\s+/g, '') as any)}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <div className="bg-white p-8 rounded-[40px] border border-slate-100 shadow-sm">
              <h3 className="text-xl font-black text-slate-800 mb-8 font-display">{t('verificationQueue')}</h3>
              <div className="space-y-4">
                {[
                  { name: 'Dr. Sameer Khan', type: t('specialistVerification'), status: 'Pending' },
                  { name: 'Cauvery Hospital', type: t('facilityOnboarding'), status: 'Pending' },
                  { name: 'Jan Aushadhi #456', type: t('pharmacyAudit'), status: 'Pending' },
                ].map((item, i) => (
                  <div key={i} className="group p-4 bg-slate-50 hover:bg-[#0d9e6e]/5 rounded-2xl border border-slate-100 transition-colors">
                    <div className="flex items-center justify-between mb-1">
                      <p className="hospital-name text-slate-800 text-sm tracking-tight">{item.name}</p>
                      <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                    </div>
                    <p className="text-[10px] uppercase font-black text-slate-400 tracking-widest mb-4">{item.type}</p>
                    <div className="flex gap-2">
                      <button className="flex-1 py-2 bg-white text-[#0d9e6e] text-[10px] font-black uppercase tracking-widest rounded-lg border border-slate-200 hover:border-[#0d9e6e] transition-all">{t('approve')}</button>
                      <button className="px-3 py-2 bg-white text-red-500 rounded-lg border border-slate-200 hover:border-red-500 transition-all"><XCircle className="w-4 h-4" /></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-slate-900 p-8 rounded-[40px] text-white relative overflow-hidden">
               <div className="relative z-10">
                 <h3 className="text-xl font-black mb-6 font-display">{t('systemHealth')}</h3>
                 <div className="space-y-4">
                   <div className="flex justify-between items-center text-[10px] font-black uppercase tracking-widest mb-1">
                     <span>{t('serverLoad')}</span>
                     <span className="text-[#0d9e6e]">{t('healthy')} (12%)</span>
                   </div>
                   <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden">
                     <div className="h-full bg-[#0d9e6e]" style={{ width: '12%' }} />
                   </div>
                 </div>
               </div>
               <div className="absolute -bottom-12 -right-12 w-48 h-48 bg-[#0d9e6e]/20 rounded-full blur-3xl" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
