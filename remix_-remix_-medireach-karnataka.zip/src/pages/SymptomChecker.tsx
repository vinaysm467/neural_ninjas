import React, { useState } from 'react';
import { AlertCircle, Activity, Heart, Info, Clock, ArrowRight, ShieldAlert, CheckCircle, RefreshCcw } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../contexts/LanguageContext';

interface Result {
  urgency: 'low' | 'medium' | 'high';
  advice: string;
  specialist: string;
  doNotDo: string;
}

export const SymptomChecker: React.FC = () => {
  const [symptoms, setSymptoms] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Result | null>(null);
  const { t } = useLanguage();

  const quickSymptoms = [
    'fever', 'cough', 'chestPain', 'headache', 'vomiting', 'stomachPain', 
    'dizziness', 'skinRash', 'breathingDifficulty', 'toothPain', 'jointPain'
  ];

  const triage = async () => {
    if (!symptoms.trim()) return;
    
    setLoading(true);
    setResult(null);

    try {
      const response = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: symptoms })
      });

      if (!response.ok) throw new Error('AI analysis failed');
      
      const data = await response.json();
      const analysisText = data.analysis;
      
      // Map AI response to the UI Result structure
      // For demo purposes, we still check urgency locally or let AI decide
      // But here we use a hybrid approach to maintain the UI design
      const text = symptoms.toLowerCase();
      let res: Result;

      const highUrgency = ['chest pain', 'heart attack', 'stroke', 'shortness of breath', 'difficulty breathing', 'unconscious', 'severe bleeding', "can't breathe", 'paralysis', 'seizure', 'severe head injury'];
      const mediumUrgency = ['fever', 'vomiting', 'diarrhea', 'dizziness', 'headache', 'abdominal pain', 'dehydration', 'high temperature', 'body ache', 'nausea'];

      let urgency: 'low' | 'medium' | 'high' = 'low';
      if (highUrgency.some(term => text.includes(term))) urgency = 'high';
      else if (mediumUrgency.some(term => text.includes(term))) urgency = 'medium';

      res = {
        urgency,
        advice: analysisText,
        specialist: urgency === 'high' ? t('highUrgencySpecialist') : urgency === 'medium' ? t('mediumUrgencySpecialist') : t('lowUrgencySpecialist'),
        doNotDo: urgency === 'high' ? t('highUrgencyDoNotDo') : urgency === 'medium' ? t('mediumUrgencyDoNotDo') : t('lowUrgencyDoNotDo')
      };

      setResult(res);
    } catch (err) {
      console.error('Triage error:', err);
      // Fallback to local triage if AI fails
      const text = symptoms.toLowerCase();
      let res: Result;
      const highUrgency = ['chest pain', 'heart attack', 'stroke', 'shortness of breath', 'difficulty breathing', 'unconscious', 'severe bleeding', "can't breathe", 'paralysis', 'seizure', 'severe head injury'];
      const mediumUrgency = ['fever', 'vomiting', 'diarrhea', 'dizziness', 'headache', 'abdominal pain', 'dehydration', 'high temperature', 'body ache', 'nausea'];

      if (highUrgency.some(term => text.includes(term))) {
        res = { urgency: 'high', advice: t('highUrgencyTitle'), specialist: t('highUrgencySpecialist'), doNotDo: t('highUrgencyDoNotDo') };
      } else if (mediumUrgency.some(term => text.includes(term))) {
        res = { urgency: 'medium', advice: t('mediumUrgencyTitle'), specialist: t('mediumUrgencySpecialist'), doNotDo: t('mediumUrgencyDoNotDo') };
      } else {
        res = { urgency: 'low', advice: t('lowUrgencyTitle'), specialist: t('lowUrgencySpecialist'), doNotDo: t('lowUrgencyDoNotDo') };
      }
      setResult(res);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-[#f8fafb] min-h-screen py-12 px-4">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white p-8 md:p-12 rounded-[40px] border border-gray-100 shadow-sm">
          <div className="flex items-center gap-4 mb-8">
            <div className="p-4 bg-[#0d9e6e]/10 rounded-3xl text-[#0d9e6e]">
              <Activity className="w-8 h-8" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900 tracking-tight">{t('symptomChecker')}</h1>
              <p className="text-gray-500 font-medium">{t('quickAssessmentGuidance')}</p>
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <label className="text-xs font-black text-gray-400 uppercase tracking-widest mb-4 block">{t('howFeeling')}</label>
              <textarea 
                className="w-full p-6 text-lg border-2 border-gray-50 rounded-3xl focus:ring-4 focus:ring-[#0d9e6e]/10 outline-none min-h-[160px] bg-gray-50/50 transition-all placeholder:text-gray-300"
                placeholder={`${t('search')}...`}
                value={symptoms}
                onChange={(e) => setSymptoms(e.target.value)}
              />
            </div>

            <div className="flex flex-wrap gap-2">
              {quickSymptoms.map(tag => (
                <button
                  key={tag}
                  onClick={() => {
                    const translatedTag = t(tag as any);
                    setSymptoms(prev => prev ? `${prev}, ${translatedTag}` : translatedTag);
                  }}
                  className="px-4 py-2 bg-white border border-gray-100 text-xs font-bold text-gray-600 rounded-full hover:border-[#0d9e6e] hover:text-[#0d9e6e] transition-all"
                >
                  + {t(tag as any)}
                </button>
              ))}
            </div>

            <button 
              onClick={triage}
              disabled={loading || symptoms.trim().length < 3}
              className="w-full py-5 bg-[#0d9e6e] text-white font-bold rounded-3xl shadow-lg hover:shadow-xl hover:bg-[#0bc385] transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? (
                <>
                  <RefreshCcw className="w-5 h-5 animate-spin" /> {t('analyzingSymptoms')}
                </>
              ) : (
                <>
                  {t('analyzeHealthNow')} <ArrowRight className="w-5 h-5" />
                </>
              )}
            </button>
          </div>

          <div className="mt-12 p-6 bg-red-50 rounded-3xl border border-red-100 flex items-start gap-4">
            <ShieldAlert className="w-6 h-6 text-red-600 shrink-0 mt-1" />
            <div>
              <h4 className="text-sm font-bold text-red-800 uppercase tracking-widest mb-1">{t('criticalDisclaimer')}</h4>
              <p className="text-xs text-red-700 leading-relaxed">
                {t('criticalDisclaimerDesc')}
              </p>
            </div>
          </div>
        </div>

        <AnimatePresence>
          {result && (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-8 space-y-6"
            >
              <div className={cn(
                "p-8 rounded-[40px] border-4 shadow-xl overflow-hidden relative",
                result.urgency === 'high' ? "bg-white border-red-600" : 
                result.urgency === 'medium' ? "bg-white border-amber-500" : "bg-white border-green-500"
              )}>
                <div className="flex items-center justify-between mb-8">
                  <div className={cn(
                    "px-4 py-2 rounded-2xl font-black text-xs uppercase tracking-widest text-white shadow-lg",
                    result.urgency === 'high' ? "bg-red-600" : 
                    result.urgency === 'medium' ? "bg-amber-500" : "bg-green-500"
                  )}>
                    {t(result.urgency as any)} {t('urgency')}
                  </div>
                  <Clock className="w-6 h-6 text-gray-400" />
                </div>

                <div className="space-y-8">
                  <div className="flex items-start gap-6">
                    <div className="w-16 h-16 rounded-3xl bg-gray-50 flex items-center justify-center shrink-0 border border-gray-100">
                      <Activity className={cn("w-8 h-8", result.urgency === 'high' ? "text-red-600" : result.urgency === 'medium' ? "text-amber-500" : "text-green-500")} />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 mb-2">{t('recommendedAction')}</h3>
                      <p className="text-gray-600 italic text-lg leading-relaxed">{result.advice}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100">
                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">{t('specialistRequired')}</p>
                      <p className="font-bold text-gray-900">{result.specialist}</p>
                    </div>
                    <div className="p-6 bg-gray-50 rounded-3xl border border-gray-100">
                      <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">{t('criticalAdvice')}</p>
                      <p className="text-xs text-gray-700 font-bold leading-relaxed">{result.doNotDo}</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};
