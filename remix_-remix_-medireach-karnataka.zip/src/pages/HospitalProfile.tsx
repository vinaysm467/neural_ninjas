import React, { useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { MapPin, Phone, Star, Clock, Shield, Award, ChevronLeft, Calendar, Info, Users, ShieldCheck, Map as MapIcon, CheckCircle, Navigation, Siren, Pill, Activity, IndianRupee } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { DISEASE_PRICES } from '../diseaseData';

// Fix for Leaflet default icon issues in React
const defaultIcon = L.icon({
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});
L.Marker.prototype.options.icon = defaultIcon;
import { Hospital, Doctor } from '../types';
import { DOCTORS } from '../data';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';

interface HospitalProfileProps {
  hospital: Hospital;
  onBack: () => void;
  onBookAppointment: (hospitalId: string, doctorId?: string) => void;
}

export const HospitalProfile: React.FC<HospitalProfileProps> = ({ hospital, onBack, onBookAppointment }) => {
  const [activeTab, setActiveTab ] = useState('overview');
  const hospitalDoctors = DOCTORS.filter(d => d.hospital_id === hospital.id);
  const hospitalPrices = DISEASE_PRICES.filter(p => p.hospital_id === hospital.id);
  const { t, language } = useLanguage();

  const stats = [
    { label: t('beds'), value: hospital.beds, icon: <div className="w-5 h-5" /> },
    { label: t('established'), value: hospital.established, icon: <div className="w-5 h-5" /> },
    { label: t('specialists'), value: hospitalDoctors.length, icon: <div className="w-5 h-5" /> },
    { label: t('insurance'), value: hospital.insurance_accepted.length, icon: <div className="w-5 h-5" /> },
  ];

    const handleGetDirections = () => {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${hospital.lat},${hospital.lng}`, '_blank');
  };

  return (
    <div className="bg-[#f8fafb] min-h-screen pb-20">
      {/* Hero */}
      <div className="relative h-64 md:h-96 w-full overflow-hidden">
        <img 
          src="https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=1600&auto=format&fit=crop" 
          className="w-full h-full object-cover"
          alt={hospital.name}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        
        <div className="absolute top-6 left-6 right-6 flex justify-between items-start">
          <button 
            onClick={onBack}
            className="p-2 bg-white/20 backdrop-blur-md rounded-full text-white hover:bg-white/40 transition-all border border-white/30"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
        </div>

        <div className="absolute bottom-10 left-6 right-6">
          <div className="max-w-7xl mx-auto">
            <div className="flex flex-wrap items-center gap-3 mb-4">
              <span className="bg-[#0d9e6e] text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-widest border border-white/20 shadow-lg">
                {hospital.type === 'Government' ? t('government') : hospital.type === 'Private' ? t('private') : t('trust')} {t('hospitalTypeProvider')}
              </span>
              {hospital.emergency && (
                <span className="bg-red-600 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-widest flex items-center gap-1 shadow-lg">
                  <Clock className="w-3 h-3" /> {t('twentyFourSevenEmergency')}
                </span>
              )}
              {hospital.accreditation.map(a => (
                <span key={a} className="bg-blue-600 text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-widest shadow-lg">
                  {a}
                </span>
              ))}
            </div>
            <h1 className="hospital-name text-4xl md:text-6xl text-white mb-6 drop-shadow-md uppercase tracking-tight">{hospital.name}</h1>
            <div className="flex flex-col md:flex-row md:items-center gap-4 text-white/90">
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="w-4 h-4 text-[#0d9e6e]" /> {hospital.address}
              </div>
              <div className="hidden md:block text-white/30">|</div>
              <div className="flex items-center gap-2 text-sm">
                <Phone className="w-4 h-4 text-[#0d9e6e]" /> {hospital.phone}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 -mt-6 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-3 space-y-8">
            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {stats.map((s, i) => (
                <div key={i} className="bg-white p-4 rounded-2xl border border-gray-100 shadow-sm text-center">
                  <p className="text-[10px] uppercase font-bold text-gray-400 tracking-widest mb-1">{s.label}</p>
                  <p className="text-xl font-bold text-gray-900">{s.value}</p>
                </div>
              ))}
            </div>

            {/* Tabs */}
            <div className="bg-white rounded-3xl border border-gray-100 shadow-sm overflow-hidden">
              <div className="flex border-b border-gray-100 overflow-x-auto scrollbar-hide">
                {[
                  { id: 'overview', label: t('overview'), icon: <Info className="w-4 h-4" /> },
                  { id: 'treatments', label: t('treatments'), icon: <Pill className="w-4 h-4" /> },
                  { id: 'doctors', label: t('doctors'), icon: <Users className="w-4 h-4" /> },
                  { id: 'facilities', label: t('facilities'), icon: <ShieldCheck className="w-4 h-4" /> },
                  { id: 'location', label: t('location'), icon: <MapIcon className="w-4 h-4" /> },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={cn(
                      "flex items-center gap-2 px-8 py-5 text-sm font-bold transition-all whitespace-nowrap border-b-2",
                      activeTab === tab.id 
                        ? "text-[#0d9e6e] border-[#0d9e6e] bg-[#0d9e6e]/5" 
                        : "text-gray-500 border-transparent hover:text-gray-700 hover:bg-gray-50"
                    )}
                  >
                    {tab.icon}
                    {tab.label}
                  </button>
                ))}
              </div>

              <div className="p-8">
                {activeTab === 'overview' && (
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 mb-4">{t('aboutHospital')}</h3>
                      <p className="text-gray-600 leading-relaxed italic">
                        {hospital.name} {language === 'kn' ? 'ಒಂದು ಪ್ರಮುಖ ಆರೋಗ್ಯ ಕೇಂದ್ರವಾಗಿದೆ' : 'is a leading healthcare destination in'} {hospital.district}, {language === 'kn' ? 'ಇದನ್ನು' : 'established in'} {hospital.established} {language === 'kn' ? 'ರಲ್ಲಿ ಸ್ಥಾಪಿಸಲಾಯಿತು' : ''}. 
                        {language === 'kn' ? 'ವಿಶೇಷತೆಗಳು:' : 'Specializing in'} {(hospital.specialties || []).join(', ')}.
                      </p>
                    </div>

                    {/* Emergency & Ambulance Section */}
                    <div className="bg-red-50 p-6 rounded-3xl border border-red-100">
                      <div className="flex items-center gap-3 mb-4 text-red-600">
                        <Siren className="w-5 h-5 animate-pulse" />
                        <h3 className="text-lg font-black uppercase tracking-tight font-display">{t('emergencyAndAmbulance')}</h3>
                      </div>
                      <div className="flex flex-col md:flex-row items-center justify-between gap-6">
                        <div>
                          <p className="text-xs font-black text-red-600/50 uppercase tracking-widest mb-1">{t('assignedUnit')}</p>
                          <p className="text-base font-black text-slate-800">{hospital.name} {t('ambulance')}</p>
                          <p className="text-[10px] font-bold text-slate-500 uppercase tracking-tighter">{t('responseTime')}: 5-10 {t('mins')} • {hospital.district} {t('network')}</p>
                        </div>
                        <div className="flex gap-2 w-full md:w-auto">
                          <button 
                            onClick={handleGetDirections}
                            className="flex-1 bg-white text-slate-800 px-6 py-3 rounded-xl border border-slate-200 text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2"
                          >
                            <Navigation className="w-4 h-4" /> {t('getRoute')}
                          </button>
                          <a 
                            href={`tel:${hospital.phone}`}
                            className="flex-1 bg-red-600 text-white px-8 py-3 rounded-xl text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 shadow-lg shadow-red-100"
                          >
                            <Phone className="w-4 h-4" /> {t('callER')}
                          </a>
                        </div>
                      </div>
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-900 mb-4">{t('keySpecialties')}</h3>
                      <div className="flex flex-wrap gap-2">
                        {hospital.specialties.map(s => (
                          <span key={s} className="px-4 py-2 bg-gray-50 text-gray-700 text-sm font-bold rounded-xl border border-gray-100 uppercase tracking-wide">
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="pt-6 border-t border-gray-100 grid grid-cols-1 md:grid-cols-2 gap-8">
                      <div>
                        <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">{t('insuranceAccepted')}</h4>
                        <div className="grid grid-cols-2 gap-3">
                          {hospital.insurance_accepted.map(i => (
                            <div key={i} className="flex items-center gap-2 text-sm text-gray-700 font-medium">
                              <CheckCircle className="w-4 h-4 text-[#0d9e6e]" /> {i}
                            </div>
                          ))}
                        </div>
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-gray-400 uppercase tracking-widest mb-4">{t('serviceExcellence')}</h4>
                        <div className="space-y-3">
                          <div className="flex items-center gap-3">
                            <span className="p-2 bg-amber-50 rounded-lg text-amber-600 font-bold">4.8</span>
                            <span className="text-sm text-gray-600 font-medium">{t('patientSatisfaction')}</span>
                          </div>
                          <div className="flex items-center gap-3">
                            <span className="p-2 bg-teal-50 rounded-lg text-teal-600 font-bold">99%</span>
                            <span className="text-sm text-gray-600 font-medium">{t('criticalSurgerySuccess')}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'treatments' && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="text-xl font-bold text-gray-900">{t('treatmentPriceEstimates')}</h3>
                      <div className="flex items-center gap-2 text-[10px] bg-amber-50 text-amber-700 px-3 py-1 rounded-full font-bold uppercase tracking-widest border border-amber-100">
                        <Info className="w-3 h-3" /> {t('priceDisclaimer').split('.')[0]}
                      </div>
                    </div>
                    
                    <div className="bg-white border border-gray-100 rounded-2xl overflow-hidden shadow-sm">
                      <table className="w-full text-left border-collapse">
                        <thead>
                          <tr className="bg-gray-50/50 border-b border-gray-100">
                            <th className="px-6 py-4 text-[10px] font-black uppercase text-gray-400 tracking-widest">{t('treatment')}</th>
                            <th className="px-6 py-4 text-[10px] font-black uppercase text-gray-400 tracking-widest">{t('category')}</th>
                            <th className="px-6 py-4 text-[10px] font-black uppercase text-gray-400 tracking-widest text-right">{t('minPrice')}</th>
                            <th className="px-6 py-4 text-[10px] font-black uppercase text-gray-400 tracking-widest text-right">{t('maxPrice')}</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-50">
                          {hospitalPrices.length > 0 ? hospitalPrices.map((p) => (
                            <tr key={p.id} className="hover:bg-gray-50/50 transition-colors group">
                              <td className="px-6 py-4">
                                <p className="font-bold text-gray-900 flex items-center gap-2">
                                  <Activity className="w-3 h-3 text-[#0d9e6e]" /> {p.disease_name}
                                </p>
                              </td>
                              <td className="px-6 py-4">
                                <span className="text-xs font-bold text-gray-400 uppercase tracking-tight">{p.category}</span>
                              </td>
                              <td className="px-6 py-4 text-right font-black text-gray-900 italic">
                                ₹{p.min_estimated_cost.toLocaleString('en-IN')}
                              </td>
                              <td className="px-6 py-4 text-right font-bold text-gray-400">
                                ₹{p.max_estimated_cost.toLocaleString('en-IN')}
                              </td>
                            </tr>
                          )) : (
                            <tr>
                              <td colSpan={4} className="px-6 py-12 text-center text-gray-400 italic">
                                {t('noPriceDataFound')}
                              </td>
                            </tr>
                          )}
                        </tbody>
                      </table>
                    </div>

                    <div className="bg-[#0d9e6e]/5 p-6 rounded-3xl border border-[#0d9e6e]/10 flex items-start gap-4">
                      <div className="p-3 bg-white rounded-2xl text-[#0d9e6e] shadow-sm">
                        <IndianRupee className="w-6 h-6" />
                      </div>
                      <div>
                        <h4 className="text-sm font-black text-slate-800 uppercase tracking-widest mb-1">{t('financialAssistance')}</h4>
                        <p className="text-xs text-slate-500 font-medium leading-relaxed">
                          {t(hospital.type === 'Government' ? 'governmentOption' : 'budgetFriendly')} • {t('insuranceSupported')}: {hospital.insurance_accepted.slice(0, 3).join(', ')}...
                        </p>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'doctors' && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {hospitalDoctors.map((doctor) => (
                      <div key={doctor.id} className="p-4 rounded-2xl border border-gray-100 flex items-center gap-4 hover:border-[#0d9e6e]/50 transition-all">
                        <img 
                          src={`https://ui-avatars.com/api/?name=${doctor.name}&background=0d9e6e&color=fff`} 
                          className="w-16 h-16 rounded-xl object-cover"
                          alt={doctor.name}
                        />
                        <div className="flex-1">
                          <h4 className="font-bold text-gray-900">{doctor.name}</h4>
                          <p className="text-xs text-[#0d9e6e] font-bold uppercase">{doctor.specialty}</p>
                          <p className="text-[10px] text-gray-400 font-medium mt-1 uppercase tracking-widest">{doctor.qualification}</p>
                        </div>
                        <button 
                          onClick={() => onBookAppointment(hospital.id, doctor.id)}
                          className="p-2 text-[#0d9e6e] hover:bg-[#0d9e6e]/10 rounded-lg transition-colors"
                        >
                          <Calendar className="w-5 h-5" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {activeTab === 'facilities' && (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    {hospital.facilities.map(f => (
                      <div key={f} className="p-6 bg-gray-50 rounded-2xl border border-gray-100 flex flex-col items-center text-center">
                        <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center text-[#0d9e6e] shadow-sm mb-4">
                          <ShieldCheck className="w-6 h-6" />
                        </div>
                        <h4 className="font-bold text-gray-900 mb-1">{f}</h4>
                        <p className="text-xs text-gray-500">World-class {f.toLowerCase()} unit with specialized staffing.</p>
                      </div>
                    ))}
                  </div>
                )}
                
                {activeTab === 'location' && (
                  <div className="space-y-6">
                    <div className="h-96 rounded-2xl overflow-hidden border border-slate-200 shadow-inner z-0 relative">
                      <MapContainer 
                        center={[hospital.lat, hospital.lng]} 
                        zoom={15} 
                        style={{ height: '100%', width: '100%' }}
                      >
                        <TileLayer
                          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        />
                        <Marker position={[hospital.lat, hospital.lng]}>
                          <Popup>
                            <div className="p-1 font-sans">
                              <h4 className="font-black text-slate-800 text-sm mb-1">{hospital.name}</h4>
                              <p className="text-[10px] text-slate-500 font-bold">{hospital.address}</p>
                            </div>
                          </Popup>
                        </Marker>
                      </MapContainer>
                    </div>
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-6 bg-slate-50 rounded-2xl border border-slate-100">
                      <div className="flex items-start gap-4">
                        <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-[#0d9e6e] shadow-sm shrink-0 border border-slate-100">
                          <MapPin className="w-6 h-6" />
                        </div>
                        <div>
                          <p className="font-black text-slate-800 uppercase text-[10px] tracking-widest mb-1">{t('officialAddress')}</p>
                          <p className="text-sm text-slate-600 font-medium">{hospital.address}</p>
                        </div>
                      </div>
                      <button 
                        onClick={handleGetDirections}
                        className="bg-slate-800 text-white px-8 py-3.5 rounded-xl font-bold text-sm flex items-center justify-center gap-2 hover:bg-slate-900 transition-all shadow-lg active:scale-95"
                      >
                        <Navigation className="w-4 h-4" /> {t('getDirections')}
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm sticky top-32">
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-1">
                  <Star className="w-5 h-5 text-amber-500 fill-amber-500" />
                  <span className="text-2xl font-black text-gray-900">{hospital.rating.toFixed(1)}</span>
                </div>
                <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">{hospital.total_reviews} {t('reviews')}</span>
              </div>
              
              <div className="space-y-6 mb-8">
                <div>
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-1">{t('averageFee')}</p>
                  <p className="text-2xl font-bold text-gray-900">₹{hospital.avg_fee === 0 ? t('free') : hospital.avg_fee}</p>
                </div>
                <div className="p-4 bg-teal-50 rounded-2xl border border-teal-100 flex items-center gap-4">
                  <div className="w-10 h-10 bg-white rounded-full flex items-center justify-center text-teal-600 shadow-sm shrink-0">
                    <Shield className="w-5 h-5" />
                  </div>
                  <div>
                    <h5 className="text-[10px] font-bold text-teal-800 uppercase tracking-widest">{t('verifiedFacility')}</h5>
                    <p className="text-xs text-teal-700 leading-tight">{t('karnatakaHealthBoard')}</p>
                  </div>
                </div>
              </div>

              <button 
                onClick={() => onBookAppointment(hospital.id)}
                className="w-full py-4 bg-[#0d9e6e] text-white font-bold rounded-2xl shadow-lg hover:shadow-xl hover:bg-[#0bc385] transition-all flex items-center justify-center gap-2 mb-4"
              >
                <Calendar className="w-5 h-5" /> {t('bookAppointment')}
              </button>
              
              <div className="flex flex-col gap-3">
                <p className="text-[10px] text-slate-400 uppercase font-black text-center tracking-[0.2em] mb-2">Quick Contact</p>
                
                <div className="grid grid-cols-1 gap-2 mb-2">
                  <a href={`tel:${hospital.phone}`} className="flex flex-col items-center justify-center p-4 border border-slate-100 rounded-xl text-slate-700 hover:bg-[#0d9e6e]/5 hover:border-[#0d9e6e]/30 transition-all gap-1 group">
                    <Phone className="w-5 h-5 text-[#0d9e6e]" />
                    <span className="text-xs font-bold uppercase tracking-widest text-slate-400 group-hover:text-[#0d9e6e]">{t('callNow')}</span>
                  </a>
                </div>

                <div className="flex items-center justify-between gap-2 pt-4 border-t border-slate-50">
                  <a href={hospital.maps_url} target="_blank" rel="noopener noreferrer" className="flex-1 bg-slate-100 rounded-xl text-slate-600 hover:text-red-500 hover:bg-red-50 transition-all flex flex-col items-center justify-center p-3 border border-slate-100 gap-1 group">
                    <MapPin className="w-4 h-4 text-red-500" />
                    <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400 group-hover:text-red-500">{t('map')}</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
