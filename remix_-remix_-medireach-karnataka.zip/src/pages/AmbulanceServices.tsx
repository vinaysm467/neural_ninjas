import React, { useState, useMemo } from 'react';
import { Phone, Search, MapPin, Navigation, Truck, Siren, AlertCircle, ChevronRight, Activity, ShieldCheck, Building2 } from 'lucide-react';
import { AMBULANCES, HOSPITALS } from '../data';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../contexts/LanguageContext';

export const AmbulanceServices: React.FC = () => {
  const [selectedDistrict, setSelectedDistrict] = useState<string>('Mysuru');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('All');
  const [sortByNearest, setSortByNearest] = useState(true);
  const { t } = useLanguage();

  const districts = ['Mysuru', 'Bengaluru Urban', 'Mandya', 'Hassan', 'Tumakuru', 'Chamarajanagar'];
  const ambulanceTypes = ['All', 'Advanced', 'ICU', 'Neonatal'];

  const filteredAmbulances = useMemo(() => {
    return AMBULANCES.filter(amb => {
      const matchesDistrict = amb.district === selectedDistrict;
      const matchesSearch = amb.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           amb.area.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           amb.linked_hospital.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesType = selectedType === 'All' || amb.type === selectedType;
      
      return matchesDistrict && matchesSearch && matchesType;
    }).sort((a, b) => {
      if (sortByNearest) return a.distance_km - b.distance_km;
      return 0;
    });
  }, [selectedDistrict, searchQuery, selectedType, sortByNearest]);

  const handleCall = (phone: string) => {
    window.location.href = `tel:${phone}`;
  };

  const handleGetRoute = (lat: number, lng: number) => {
    window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, '_blank');
  };

  const handleNearestHospital = () => {
    window.open('https://www.google.com/maps/search/nearest+hospital+near+me', '_blank');
  };

  return (
    <div className="bg-[#f8fafb] min-h-screen pb-20 font-sans">
      {/* Hero / Emergency Contacts Section */}
      <div className="bg-slate-900 text-white py-12 px-6 relative overflow-hidden">
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-[#dc2626] rounded-xl flex items-center justify-center animate-pulse">
                  <Siren className="w-6 h-6 text-white" />
                </div>
                <h1 className="text-3xl font-black tracking-tight font-display uppercase">{t('ambulance')}</h1>
              </div>
              <p className="text-slate-400 font-medium max-w-xl">
                {t('ambulanceHeroDesc')}
              </p>
            </div>

            <div className="flex shrink-0">
              <button 
                onClick={() => handleCall('108')}
                className="flex items-center gap-4 bg-[#dc2626] px-10 py-6 rounded-3xl hover:bg-[#b91c1c] transition-all group border border-white/10 shadow-2xl shadow-red-500/20"
              >
                <Phone className="w-8 h-8 animate-bounce" />
                <div className="text-left">
                  <p className="text-[10px] font-black uppercase tracking-widest opacity-80">{t('emergencyAmbulance')}</p>
                  <p className="text-3xl font-black leading-none">108</p>
                </div>
              </button>
            </div>
          </div>
        </div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#0d9e6e]/10 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2" />
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Filters Sidebar */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white p-6 rounded-[32px] border border-slate-100 shadow-sm sticky top-28">
              <h3 className="text-sm font-black text-slate-800 uppercase tracking-widest mb-6 flex items-center gap-2">
                <Search className="w-4 h-4 text-[#0d9e6e]" /> {t('filter')}
              </h3>

              <div className="space-y-4">
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2 px-1">{t('selectDistrict')}</label>
                    <select 
                      value={selectedDistrict}
                      onChange={(e) => setSelectedDistrict(e.target.value)}
                      className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-[#0d9e6e]/20"
                    >
                      {districts.map(d => <option key={d} value={d}>{t(d.toLowerCase().replace(/\s+/g, '') as any)}</option>)}
                    </select>
                </div>

                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1 px-1">{t('vehicleType')}</label>
                  <div className="flex flex-wrap gap-2 pt-1">
                    {['All', 'Advanced', 'ICU', 'Neonatal'].map(type => (
                      <button
                        key={type}
                        onClick={() => setSelectedType(type)}
                        className={cn(
                          "px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider border-2 transition-all",
                          selectedType === type 
                            ? "bg-[#0d9e6e] text-white border-[#0d9e6e] shadow-md shadow-[#0d9e6e]/20" 
                            : "bg-white text-slate-500 border-slate-50 hover:border-slate-200"
                        )}
                      >
                        {type === 'All' ? t('all') : 
                         type === 'Advanced' ? t('advanced') :
                         type === 'ICU' ? t('icu') :
                         t('neonatal')}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-4 mt-4 border-t border-slate-100">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">{t('nearFirst')}</span>
                    <button 
                      onClick={() => setSortByNearest(!sortByNearest)}
                      className={cn(
                        "w-12 h-6 rounded-full transition-all relative",
                        sortByNearest ? "bg-[#0d9e6e]" : "bg-slate-200"
                      )}
                    >
                      <div className={cn(
                        "absolute top-1 w-4 h-4 rounded-full bg-white transition-all shadow-sm",
                        sortByNearest ? "right-1" : "left-1"
                      )} />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Results List */}
          <div className="lg:col-span-8">
            <div className="flex items-center justify-between mb-6 px-2">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-slate-400" />
                <h2 className="text-lg font-black text-slate-800 tracking-tight">{filteredAmbulances.length} {t('responsesIdentified')}</h2>
              </div>
            </div>

            <div className="space-y-4">
              <AnimatePresence>
                {filteredAmbulances.length > 0 ? (
                  filteredAmbulances.map((amb, index) => (
                    <motion.div
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      key={amb.id}
                      className={cn(
                        "bg-white p-5 rounded-[32px] border-2 transition-all group overflow-hidden relative",
                        index === 0 && sortByNearest ? "border-[#0d9e6e] ring-4 ring-[#0d9e6e]/5" : "border-white hover:border-slate-200"
                      )}
                    >
                      {/* Nearest Badge */}
                      {index === 0 && sortByNearest && (
                        <div className="absolute top-0 right-0">
                          <div className="bg-[#0d9e6e] text-white px-4 py-1.5 rounded-bl-2xl text-[9px] font-black uppercase tracking-widest flex items-center gap-1.5 shadow-sm">
                            <Activity className="w-3 h-3" /> {t('nearestAvailable')}
                          </div>
                        </div>
                      )}

                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                        <div className="flex items-start gap-5">
                          <div className={cn(
                            "w-16 h-16 rounded-2xl flex items-center justify-center shrink-0 transition-transform group-hover:scale-105",
                            amb.type === 'ICU' ? "bg-red-50 text-red-500" :
                            amb.type === 'Advanced' ? "bg-blue-50 text-blue-500" :
                            "bg-slate-50 text-slate-500"
                          )}>
                            <Truck className="w-8 h-8" />
                          </div>
                          
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h3 className="text-lg font-black text-slate-800 tracking-tight">{amb.name}</h3>
                              <span className="px-2 py-0.5 bg-slate-100 text-slate-500 text-[9px] font-black uppercase rounded-lg tracking-widest">
                                {amb.type === 'ICU' ? t('icu') : 
                                 amb.type === 'Advanced' ? t('advanced') :
                                 amb.type === 'Basic' ? t('basic') :
                                 t('neonatal')}
                              </span>
                              <span className="px-2 py-0.5 bg-green-50 text-[#0d9e6e] text-[9px] font-black uppercase rounded-lg tracking-widest">
                                {amb.availability === 'Available' ? t('available') : amb.availability}
                              </span>
                            </div>
                            
                            <div className="flex items-center gap-3 text-[11px] font-bold text-slate-400 uppercase tracking-tight">
                              <div className="flex items-center gap-1">
                                <MapPin className="w-3 h-3 text-[#0d9e6e]" /> {amb.area}, {amb.district}
                              </div>
                              <div className="w-1 h-1 bg-slate-300 rounded-full" />
                              <div className="flex items-center gap-1">
                                <Building2 className="w-3 h-3 text-[#0d9e6e]" /> {t('linked')}: {amb.linked_hospital}
                              </div>
                            </div>

                            <div className="flex items-center gap-6 mt-4 pt-4 border-t border-slate-50">
                              <div className="flex flex-col">
                                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-0.5">{t('estimatedArrival')}</span>
                                <span className="text-sm font-black text-[#0d9e6e]">{amb.estimated_arrival}</span>
                              </div>
                              <div className="w-px h-8 bg-slate-100" />
                              <div className="flex flex-col">
                                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-0.5">{t('travelDistance')}</span>
                                <span className="text-sm font-black text-slate-800">{amb.distance_km} KM</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="flex gap-2 shrink-0">
                          <button 
                            onClick={() => handleGetRoute(amb.lat, amb.lng)}
                            className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-slate-100 text-slate-600 px-6 py-4 rounded-2xl text-[11px] font-black uppercase tracking-widest hover:bg-slate-200 transition-all"
                          >
                            <Navigation className="w-4 h-4" /> {t('getRoute')}
                          </button>
                          <button 
                            onClick={() => handleCall(amb.phone)}
                            className="flex-1 md:flex-none flex items-center justify-center gap-2 bg-slate-900 text-white px-8 py-4 rounded-2xl text-[11px] font-black uppercase tracking-widest hover:bg-[#0d9e6e] transition-all shadow-lg shadow-slate-200 relative overflow-hidden group"
                          >
                            <span className="relative z-10 flex items-center gap-2">
                              <Phone className="w-4 h-4" /> {t('callNow')}
                            </span>
                            <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent group-hover:translate-x-full transition-transform duration-700 -translate-x-full" />
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  ))
                ) : (
                  <div className="py-20 text-center bg-white rounded-[40px] border border-dashed border-slate-200">
                    <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-6">
                      <AlertCircle className="w-10 h-10 text-slate-300" />
                    </div>
                    <p className="text-slate-400 font-bold italic text-sm">{t('noResponseUnits')}</p>
                    <button 
                      onClick={() => { setSearchQuery(''); setSelectedType('All'); }}
                      className="mt-4 text-[#0d9e6e] text-xs font-black uppercase tracking-widest hover:underline"
                    >
                      {t('resetAllFilters')}
                    </button>
                  </div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
