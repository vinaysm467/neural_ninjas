import React, { useState } from 'react';
import { motion } from 'motion/react';
import { useLanguage } from '../contexts/LanguageContext';
import { User, Phone, Calendar, Building2, MapPin, ChevronRight, ArrowLeft, ShieldCheck, Stethoscope } from 'lucide-react';
import { cn } from '../lib/utils';

interface ServiceBookingFormProps {
  initialService: string;
  initialProvider?: string;
  onConfirm: (details: any) => void;
  onCancel: () => void;
}

const HOSPITALS = [
  'Apollo Homecare (BGS)',
  'JSS Hospital',
  'Manipal Hospital',
  'Narayana Health',
  'Portea Medical',
  'Shri Manjunatha Home Nursing',
  'HealthVibes'
];

const SERVICES = [
  'Single Visit (Injection/Dressing)',
  '12-Hour Shift Care',
  '24-Hour Residential Nursing',
  'Physiotherapy Assessment',
  'Standard Treatment Session',
  'General Physician Visit',
  'Specialist Home Visit',
  'Semi-skilled Attendant (12h)',
  'Blood Sample Collection',
  'Post-op care',
  'ICU-at-home',
  'Geriatric care',
  'Cardiac recovery'
];

export const ServiceBookingForm: React.FC<ServiceBookingFormProps> = ({ initialService, initialProvider, onConfirm, onCancel }) => {
  const { t } = useLanguage();
  const [formData, setFormData] = useState({
    patientName: '',
    age: '',
    phone: '',
    address: '',
    hospital: initialProvider || '',
    service: initialService || '',
    serviceDate: '',
    notes: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onConfirm({ ...formData, serviceName: formData.service });
  };

  return (
    <motion.div 
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className="container mx-auto px-4 py-12 max-w-3xl font-sans"
    >
      <button 
        onClick={onCancel}
        className="flex items-center gap-2 text-slate-400 font-black uppercase tracking-widest text-[10px] mb-8 hover:text-[#0d9e6e] transition-colors"
      >
        <ArrowLeft size={14} /> Back to Services
      </button>

      <div className="bg-white border-2 border-slate-100 rounded-[48px] p-10 shadow-xl">
        <header className="mb-10 text-center">
          <h2 className="text-3xl font-black text-slate-800 italic uppercase tracking-tighter mb-2">
            Service <span className="text-[#0d9e6e]">Registration</span>
          </h2>
          <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">
            Fill in patient details for {formData.service || "selected service"}
          </p>
        </header>

        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Service Selection */}
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 ml-2">Service Required</label>
            <div className="relative">
              <Stethoscope className="absolute left-4 top-1/2 -translate-y-1/2 text-[#0d9e6e]" size={18} />
              <select 
                required
                value={formData.service}
                onChange={e => setFormData({...formData, service: e.target.value})}
                className="w-full h-14 bg-slate-50 border-2 border-[#0d9e6e]/10 rounded-2xl pl-12 pr-10 outline-none focus:border-[#0d9e6e]/40 focus:bg-white transition-all font-bold text-slate-700 appearance-none bg-[url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%3E%3Cpath%20fill%3D%22%23cbd5e1%22%20d%3D%22M7%2010l5%205%205-5z%22/%3E%3C/svg%3E')] bg-no-repeat bg-[right_1rem_center]"
              >
                <option value="">Select Service</option>
                {SERVICES.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Patient Name */}
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 ml-2">Patient Name</label>
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input 
                  type="text" 
                  required
                  value={formData.patientName}
                  onChange={e => setFormData({...formData, patientName: e.target.value})}
                  className="w-full h-14 bg-slate-50 border-2 border-slate-50 rounded-2xl pl-12 pr-6 outline-none focus:border-[#0d9e6e]/20 focus:bg-white transition-all font-bold text-slate-700"
                  placeholder="Full Name"
                />
              </div>
            </div>

            {/* Age */}
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 ml-2">{t('hosp_age')}</label>
              <div className="relative">
                <Calendar className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input 
                  type="number" 
                  required
                  value={formData.age}
                  onChange={e => setFormData({...formData, age: e.target.value})}
                  className="w-full h-14 bg-slate-50 border-2 border-slate-50 rounded-2xl pl-12 pr-6 outline-none focus:border-[#0d9e6e]/20 focus:bg-white transition-all font-bold text-slate-700"
                  placeholder="Years"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Phone */}
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 ml-2">Contact Number</label>
              <div className="relative">
                <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <input 
                  type="tel" 
                  required
                  value={formData.phone}
                  onChange={e => setFormData({...formData, phone: e.target.value})}
                  className="w-full h-14 bg-slate-50 border-2 border-slate-50 rounded-2xl pl-12 pr-6 outline-none focus:border-[#0d9e6e]/20 focus:bg-white transition-all font-bold text-slate-700"
                  placeholder="+91"
                />
              </div>
            </div>

            {/* Preferred Hospital */}
            <div>
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 ml-2">Select Hospital / Agency</label>
              <div className="relative">
                <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300" size={18} />
                <select 
                  required
                  value={formData.hospital}
                  onChange={e => setFormData({...formData, hospital: e.target.value})}
                  className="w-full h-14 bg-slate-50 border-2 border-slate-50 rounded-2xl pl-12 pr-6 outline-none focus:border-[#0d9e6e]/20 focus:bg-white transition-all font-bold text-slate-700 appearance-none"
                >
                  <option value="">Choose Provider</option>
                  {HOSPITALS.map(h => <option key={h} value={h}>{h}</option>)}
                </select>
              </div>
            </div>
          </div>

          {/* Address */}
          <div>
            <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3 ml-2">Residential Address (Mysore)</label>
            <div className="relative">
              <MapPin className="absolute left-4 top-5 text-slate-300" size={18} />
              <textarea 
                required
                value={formData.address}
                onChange={e => setFormData({...formData, address: e.target.value})}
                className="w-full h-32 bg-slate-50 border-2 border-slate-50 rounded-2xl pl-12 pr-6 py-4 outline-none focus:border-[#0d9e6e]/20 focus:bg-white transition-all font-bold text-slate-700 resize-none"
                placeholder="House No, Street, Landmark..."
              />
            </div>
          </div>

          <div className="bg-[#0d9e6e]/5 p-6 rounded-3xl border border-[#0d9e6e]/10 flex items-start gap-4">
            <ShieldCheck className="text-[#0d9e6e] mt-1" size={24} />
            <div>
              <h4 className="text-xs font-black text-slate-800 uppercase tracking-wide mb-1">Data Privacy Guarantee</h4>
              <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest leading-relaxed">
                Your medical details are encrypted and shared only with the selected provider via Mysore Health Security protocol.
              </p>
            </div>
          </div>

          <button 
            type="submit"
            className="w-full h-16 bg-slate-900 text-white rounded-2xl font-black uppercase text-sm tracking-[0.2em] shadow-xl shadow-slate-200 hover:bg-[#0d9e6e] transition-all flex items-center justify-center gap-3"
          >
            Confirm & Proceed <ChevronRight size={20} />
          </button>
        </form>
      </div>
    </motion.div>
  );
};
