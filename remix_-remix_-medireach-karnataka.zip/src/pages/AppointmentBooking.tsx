import React, { useState, useEffect } from 'react';
import { DOCTORS, HOSPITALS } from '../data';
import { Calendar, Clock, User, Phone, Mail, FileText, CheckCircle2, ChevronRight, ArrowLeft, Stethoscope, MapPin, Search, Shield, Award } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../contexts/LanguageContext';

interface BookingProps {
  initialHospitalId?: string;
  initialDoctorId?: string;
  diseaseInfo?: { name: string; price: number } | null;
  onSuccess: (tab?: string) => void;
  onBack: () => void;
}

export const AppointmentBooking: React.FC<BookingProps> = ({ 
  initialHospitalId, 
  initialDoctorId, 
  diseaseInfo,
  onSuccess,
  onBack 
}) => {
  const [step, setStep] = useState(initialHospitalId ? 2 : 1);
  const [formData, setFormData] = useState({
    hospitalId: initialHospitalId || '',
    doctorId: initialDoctorId || '',
    patientName: '',
    phone: '',
    email: '',
    date: '',
    time: '',
    reason: '',
    type: 'Regular'
  });
  const { t } = useLanguage();

  const selectedHospital = HOSPITALS.find(h => h.id === formData.hospitalId);
  const selectedDoctor = DOCTORS.find(d => d.id === formData.doctorId);
  const availableDoctors = DOCTORS.filter(d => d.hospital_id === formData.hospitalId);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const response = await fetch('/api/appointments', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          hospitalName: selectedHospital?.name,
          doctorName: selectedDoctor?.name,
          dept: selectedDoctor?.specialty
        })
      });
      if (response.ok) {
        setStep(3); // Confirmation step
      } else {
        const errorData = await response.json();
        alert(errorData.message || "Failed to book appointment. Please login.");
      }
    } catch (err) {
      console.error("Booking error:", err);
      alert("Network error occurred.");
    }
  };

  const dates = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i);
    return d.toISOString().split('T')[0];
  });

  const times = ['09:00 AM', '10:00 AM', '11:00 AM', '12:00 PM', '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM'];

  return (
    <div className="bg-[#f8fafb] min-h-screen py-10 px-4">
      <div className="max-w-5xl mx-auto">
        <button 
          onClick={onBack}
          className="flex items-center gap-2 text-gray-500 font-bold mb-8 hover:text-[#0d9e6e] transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          {t('back')}
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Summary Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white rounded-[32px] p-6 border border-gray-100 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-[#0d9e6e]/5 rounded-full -mr-8 -mt-8" />
              <div className="w-12 h-12 bg-[#0d9e6e]/10 rounded-2xl flex items-center justify-center text-[#0d9e6e] mb-6">
                <Search className="w-6 h-6" />
              </div>
              
              <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1">{t('bookingAt')}</p>
              <h2 className="text-xl font-black text-gray-900 mb-2 italic">
                {selectedHospital ? selectedHospital.name : t('selectHospitalFirst')}
              </h2>
              
              {selectedHospital && (
                <div className="flex items-center gap-2 text-sm text-gray-500 mb-6">
                  <MapPin className="w-4 h-4 text-[#0d9e6e]" />
                  {selectedHospital.area}, {selectedHospital.district}
                </div>
              )}

              {diseaseInfo && (
                <div className="mt-8 pt-8 border-t border-gray-100">
                  <p className="text-[10px] font-black uppercase tracking-widest text-[#0d9e6e] mb-2">{t('treatmentFor')}</p>
                  <h3 className="text-2xl font-black text-gray-900 mb-4 tracking-tight uppercase">{diseaseInfo.name}</h3>
                  <div className="bg-gray-50 rounded-2xl p-4 border border-gray-100">
                    <p className="text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1">{t('estimatedTotal')}</p>
                    <p className="text-2xl font-black italic text-gray-900">₹{diseaseInfo.price}</p>
                  </div>
                </div>
              )}

              {selectedDoctor && (
                <div className="mt-8 pt-8 border-t border-gray-100 flex items-center gap-4">
                  <img src={`https://ui-avatars.com/api/?name=${selectedDoctor.name}&background=0d9e6e&color=fff`} className="w-14 h-14 rounded-2xl border-2 border-white shadow-sm" />
                  <div>
                    <p className="text-[8px] font-black text-gray-400 uppercase tracking-[0.2em]">{t('consultationWith')}</p>
                    <p className="text-sm font-black text-gray-800 italic">{selectedDoctor.name}</p>
                  </div>
                </div>
              )}
            </div>

            <div className="bg-gray-900 p-8 rounded-[32px] text-white relative overflow-hidden group">
               <div className="relative z-10">
                 <h4 className="text-lg font-black mb-4 italic uppercase tracking-tight flex items-center gap-2">
                   <Shield className="w-5 h-5 text-[#0d9e6e]" /> {t('securedRecord')}
                 </h4>
                 <p className="text-[11px] text-white/60 font-medium leading-relaxed mb-6">
                   {t('bookingShortDesc')}
                 </p>
                 <div className="pt-6 border-t border-white/5 flex items-center gap-2 text-[10px] font-black uppercase tracking-widest">
                   <div className="w-2 h-2 rounded-full bg-[#0d9e6e] animate-pulse" /> {t('liveVerification')}
                 </div>
               </div>
               <div className="absolute -bottom-10 -right-10 w-32 h-32 bg-[#0d9e6e]/10 rounded-full blur-2xl group-hover:bg-[#0d9e6e]/20 transition-all duration-700" />
            </div>
          </div>

          {/* Form Content */}
          <div className="lg:col-span-2">
            <AnimatePresence mode="wait">
              {step === 1 && (
                <motion.div 
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="bg-white p-8 md:p-12 rounded-[40px] border border-gray-100 shadow-sm space-y-10"
                >
                  <div>
                    <h2 className="text-2xl font-black text-gray-900 uppercase tracking-tight italic mb-2">{t('chooseFacility')}</h2>
                    <p className="text-sm font-bold text-gray-400">{t('searchAndSelect')}</p>
                  </div>
                  
                  <div className="space-y-8">
                    <label className="block">
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3 block">{t('selectHospital')}</span>
                      <div className="relative">
                        <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                        <select 
                          className="w-full pl-14 pr-6 py-5 border-2 border-gray-50 bg-gray-50 rounded-2xl focus:bg-white focus:border-[#0d9e6e]/20 outline-none font-bold text-gray-700 transition-all appearance-none"
                          value={formData.hospitalId}
                          onChange={(e) => setFormData({ ...formData, hospitalId: e.target.value, doctorId: '' })}
                          required
                        >
                          <option value="">{t('selectHospital')}</option>
                          {HOSPITALS.map(h => <option key={h.id} value={h.id}>{h.name}</option>)}
                        </select>
                      </div>
                    </label>

                    <div className="space-y-4">
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">{t('selectSpecialist')}</span>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {availableDoctors.length > 0 ? availableDoctors.map(d => (
                          <div 
                            key={d.id}
                            onClick={() => setFormData({ ...formData, doctorId: d.id })}
                            className={cn(
                              "p-5 rounded-3xl border-2 cursor-pointer transition-all flex items-center gap-4",
                              formData.doctorId === d.id ? "border-[#0d9e6e] bg-[#0d9e6e]/5 shadow-sm" : "border-gray-50 bg-gray-50 hover:border-gray-200"
                            )}
                          >
                            <img src={`https://ui-avatars.com/api/?name=${d.name}&background=0d9e6e&color=fff`} className="w-12 h-12 rounded-2xl" />
                            <div className="flex-1">
                              <p className="font-bold text-sm text-gray-900 tracking-tight">{d.name}</p>
                              <p className="text-[9px] text-[#0d9e6e] font-black uppercase tracking-widest mt-1">{t(d.specialty.charAt(0).toLowerCase() + d.specialty.slice(1).replace(/\s+/g, '') as any)}</p>
                            </div>
                          </div>
                        )) : (
                          <div className="col-span-full py-12 text-center bg-gray-50 rounded-[32px] text-gray-400 italic text-sm font-bold border-2 border-dashed border-gray-200">
                            {t('selectHospitalFirst')}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="pt-6">
                    <button 
                      type="button"
                      disabled={!formData.hospitalId || !formData.doctorId}
                      onClick={() => setStep(2)}
                      className="w-full py-5 bg-[#0d9e6e] text-white font-black rounded-3xl hover:bg-[#0bc385] disabled:opacity-50 disabled:grayscale transition-all flex items-center justify-center gap-3 text-lg uppercase tracking-widest shadow-xl shadow-[#0d9e6e]/20"
                    >
                      {t('continue')} <ChevronRight className="w-6 h-6" />
                    </button>
                  </div>
                </motion.div>
              )}

              {step === 2 && (
                <motion.div 
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="bg-white p-8 md:p-12 rounded-[40px] border border-gray-100 shadow-sm space-y-10"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-black text-gray-900 uppercase tracking-tight italic mb-2">{t('patientRecords')}</h2>
                      <p className="text-sm font-bold text-gray-400">{t('enterDetails')}</p>
                    </div>
                    <button type="button" onClick={() => setStep(1)} className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center text-gray-400 hover:text-gray-900 transition-colors">
                      <ArrowLeft className="w-5 h-5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <label className="block">
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-3">{t('patientName')}</span>
                      <input 
                        type="text" 
                        className="w-full px-6 py-5 border-2 border-gray-50 bg-gray-50 rounded-2xl focus:bg-white focus:border-[#0d9e6e]/20 outline-none font-bold text-gray-700 transition-all"
                        placeholder={t('patientName')}
                        value={formData.patientName}
                        onChange={(e) => setFormData({ ...formData, patientName: e.target.value })}
                        required
                      />
                    </label>
                    <label className="block">
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-3">{t('phoneNumber')}</span>
                      <input 
                        type="tel" 
                        className="w-full px-6 py-5 border-2 border-gray-50 bg-gray-50 rounded-2xl focus:bg-white focus:border-[#0d9e6e]/20 outline-none font-bold text-gray-700 transition-all"
                        placeholder="+91 XXXXX XXXXX"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        required
                      />
                    </label>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <label className="block">
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-3">{t('email')}</span>
                      <input 
                        type="email" 
                        className="w-full px-6 py-5 border-2 border-gray-50 bg-gray-50 rounded-2xl focus:bg-white focus:border-[#0d9e6e]/20 outline-none font-bold text-gray-700 transition-all"
                        placeholder="patient@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      />
                    </label>
                    <label className="block">
                      <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-3">{t('appointmentType')}</span>
                      <select 
                        className="w-full px-6 py-5 border-2 border-gray-50 bg-gray-50 rounded-2xl focus:bg-white focus:border-[#0d9e6e]/20 outline-none font-bold text-gray-700 transition-all appearance-none"
                        value={formData.type}
                        onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                      >
                        <option value="Regular">{t('regular')}</option>
                        <option value="Follow-up">{t('followUp')}</option>
                        <option value="Consultation">{t('consultation')}</option>
                      </select>
                    </label>
                  </div>

                  <div className="space-y-4">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">{t('selectDate')}</span>
                    <div className="flex gap-3 overflow-x-auto pb-4 scrollbar-hide">
                      {dates.map(date => (
                        <button
                          key={date}
                          type="button"
                          onClick={() => setFormData({ ...formData, date })}
                          className={cn(
                            "px-6 py-5 rounded-3xl border-2 shrink-0 transition-all font-black text-xs uppercase tracking-tight text-center",
                            formData.date === date ? "border-[#0d9e6e] bg-[#0d9e6e] text-white shadow-lg shadow-[#0d9e6e]/20" : "border-gray-50 bg-gray-50 text-gray-500 hover:border-gray-200"
                          )}
                        >
                          <div className="text-[9px] opacity-60 mb-1">{new Date(date).toLocaleDateString('en-US', { weekday: 'short' })}</div>
                          <div className="text-lg">{new Date(date).getDate()}</div>
                          <div className="text-[9px] opacity-60">{new Date(date).toLocaleDateString('en-US', { month: 'short' })}</div>
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block">{t('selectTimeSlot')}</span>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {times.map(time => (
                        <button
                          key={time}
                          type="button"
                          onClick={() => setFormData({ ...formData, time })}
                          className={cn(
                            "py-4 rounded-2xl border-2 transition-all font-black text-[10px] uppercase tracking-widest",
                            formData.time === time ? "border-[#0d9e6e] bg-[#0d9e6e]/5 text-[#0d9e6e]" : "border-gray-50 bg-gray-50 text-gray-400"
                          )}
                        >
                          {time}
                        </button>
                      ))}
                    </div>
                  </div>

                  <button 
                    onClick={handleSubmit}
                    disabled={!formData.patientName || !formData.phone || !formData.date || !formData.time}
                    className="w-full py-5 bg-gray-900 text-white font-black rounded-3xl hover:bg-black disabled:opacity-50 transition-all text-lg shadow-xl shadow-gray-200 uppercase tracking-widest"
                  >
                    {t('confirmAppointment')}
                  </button>
                </motion.div>
              )}

              {step === 3 && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-white p-12 md:p-16 rounded-[48px] border border-gray-100 shadow-2xl text-center space-y-10 relative overflow-hidden"
                >
                  <div className="absolute top-0 left-0 w-full h-2 bg-[#0d9e6e]" />
                  <div className="w-24 h-24 bg-green-100 text-[#0d9e6e] rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
                    <CheckCircle2 className="w-14 h-14" />
                  </div>
                  <div>
                    <h2 className="text-4xl font-black text-gray-900 mb-2 italic tracking-tight">{t('bookingConfirmed')}</h2>
                    <p className="text-gray-400 font-bold uppercase tracking-widest text-xs">{t('appointmentSuccessfullySynced')}</p>
                  </div>

                  <div className="bg-gray-50 p-10 rounded-[32px] text-left border border-gray-100 space-y-5 max-w-sm mx-auto shadow-inner relative">
                    <div className="absolute top-4 right-6 w-12 h-12 bg-white rounded-2xl flex items-center justify-center border border-gray-100 shadow-sm opacity-50">
                      <Award className="w-6 h-6 text-[#0d9e6e]" />
                    </div>
                    <div className="flex justify-between border-b border-gray-200 pb-4">
                      <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest italic">{t('id')}</span>
                      <span className="text-sm font-black text-[#0d9e6e]">MR-{Math.random().toString(36).substr(2, 6).toUpperCase()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">{t('hospital')}</span>
                      <span className="text-xs font-black text-gray-900">{selectedHospital?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">{t('doctor')}</span>
                      <span className="text-xs font-black text-gray-700">{selectedDoctor?.name}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">{t('scheduled')}</span>
                      <span className="text-xs font-black text-gray-900 uppercase tracking-tighter">{formData.date} at {formData.time}</span>
                    </div>
                    {diseaseInfo && (
                      <div className="flex justify-between pt-4 mt-4 border-t border-gray-200">
                        <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">{t('totalEstimate')}</span>
                        <span className="text-sm font-black text-[#0d9e6e]">₹{diseaseInfo.price}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex flex-col sm:flex-row gap-4">
                    <button 
                      onClick={() => onSuccess('records')}
                      className="flex-1 py-5 bg-gray-900 text-white font-black rounded-3xl hover:bg-black transition-all shadow-xl uppercase tracking-widest text-[11px]"
                    >
                      {t('trackStatus')}
                    </button>
                    <button 
                      onClick={() => onSuccess('home')}
                      className="flex-1 py-5 bg-white border-2 border-gray-100 text-gray-400 font-black rounded-3xl hover:bg-gray-50 transition-all uppercase tracking-widest text-[11px]"
                    >
                      {t('returnToHome')}
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>
    </div>
  );
};
