import React from 'react';
import { motion } from 'motion/react';
import { useLanguage } from '../contexts/LanguageContext';
import { CheckCircle2, Calendar, Phone, ClipboardCheck, ArrowRight, Home } from 'lucide-react';

interface ServiceBookingProcedureProps {
  bookedService: { name: string; provider: string } | null;
  onHome: () => void;
}

export const ServiceBookingProcedure: React.FC<ServiceBookingProcedureProps> = ({ bookedService, onHome }) => {
  const { t } = useLanguage();

  if (!bookedService) return null;

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="container mx-auto px-4 py-20 max-w-4xl font-sans"
    >
      <div className="bg-white border-2 border-slate-100 rounded-[48px] p-12 shadow-2xl shadow-slate-200">
        <div className="flex justify-center mb-10">
          <div className="w-24 h-24 bg-[#0d9e6e]/10 rounded-[32px] flex items-center justify-center text-[#0d9e6e]">
            <CheckCircle2 size={48} strokeWidth={3} />
          </div>
        </div>

        <div className="text-center mb-16">
          <h2 className="text-4xl font-black text-slate-800 italic uppercase tracking-tighter mb-4">
            {t('serviceBooked')}
          </h2>
          <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">
            Your request for <span className="text-[#0d9e6e]">{bookedService.name}</span> with <span className="text-slate-800">{bookedService.provider}</span> has been received.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          <div className="bg-slate-50 p-8 rounded-[32px] border border-slate-100">
            <h3 className="text-sm font-black text-slate-800 uppercase italic mb-6 flex items-center gap-2">
              <ClipboardCheck className="text-[#0d9e6e]" size={18} /> {t('furtherProcedure')}
            </h3>
            <ul className="space-y-4">
              <StepItem number="01" text="Our health coordinator will verify the request within 30 minutes." />
              <StepItem number="02" text="A nurse/professional will be assigned based on your location in Mysore." />
              <StepItem number="03" text="Physical assessment scheduled for home visit within 4-6 hours." />
              <StepItem number="04" text="Confirmation SMS sent with professional details and arrival time." />
            </ul>
          </div>

          <div className="space-y-8">
            <div className="bg-[#0d9e6e] p-8 rounded-[32px] text-white">
              <h4 className="font-black uppercase italic tracking-widest text-[10px] mb-4 opacity-80">Support Contact</h4>
              <p className="text-2xl font-black italic mb-2 tracking-tight">Need immediate help?</p>
              <div className="flex items-center gap-2 text-xl font-black mb-4">
                <Phone size={20} fill="currentColor" /> 96112-21155
              </div>
              <p className="text-[10px] font-bold uppercase tracking-widest opacity-60">Available 24/7 for Home Care Coordination</p>
            </div>
            
            <div className="bg-slate-900 p-8 rounded-[32px] text-white group overflow-hidden relative">
              <div className="relative z-10">
                <h4 className="font-black uppercase italic tracking-widest text-[10px] mb-4 text-[#0d9e6e]">Service Hours</h4>
                <div className="flex items-center gap-3 mb-2">
                  <Calendar size={18} className="text-[#0d9e6e]" />
                  <span className="text-lg font-black italic">Next Available Slot</span>
                </div>
                <p className="text-[10px] font-bold uppercase tracking-widest opacity-60">Today • Standard 2-hour window</p>
              </div>
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button 
            onClick={onHome}
            className="w-full sm:w-auto px-10 py-5 bg-slate-900 text-white font-black uppercase text-xs tracking-[0.2em] rounded-2xl flex items-center justify-center gap-3 hover:bg-[#0d9e6e] transition-colors"
          >
            <Home size={18} /> Back to Dashboard
          </button>
          <button 
            className="w-full sm:w-auto px-10 py-5 border-2 border-slate-100 text-slate-800 font-black uppercase text-xs tracking-[0.2em] rounded-2xl flex items-center justify-center gap-3 hover:border-[#0d9e6e] transition-all"
          >
            Track Request <ArrowRight size={18} />
          </button>
        </div>
      </div>
    </motion.div>
  );
};

const StepItem: React.FC<{ number: string; text: string }> = ({ number, text }) => (
  <li className="flex gap-4 group">
    <span className="text-[#0d9e6e] font-black text-xs tabular-nums group-hover:scale-110 transition-transform">{number}</span>
    <p className="text-slate-500 font-bold uppercase tracking-widest text-[9px] leading-relaxed">{text}</p>
  </li>
);
