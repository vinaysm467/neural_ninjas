import React from 'react';
import { motion } from 'motion/react';
import { useLanguage } from '../contexts/LanguageContext';
import { Phone, MapPin, Clock, ShieldCheck, HeartPulse, Accessibility, Stethoscope, ChevronRight } from 'lucide-react';
import { cn } from '../lib/utils';

interface HospitalHomeCare {
  name: string;
  services: string;
  contact: string;
}

interface ServicePrice {
  name: string;
  price: string;
}

interface SpecialServicesProps {
  onBook: (service: string, provider?: string) => void;
}

const HOSPITALS: HospitalHomeCare[] = [
  { name: 'Apollo Homecare (BGS)', services: 'Post-op care, Physio, ICU-at-home, Nursing.', contact: '1860-500-8585' },
  { name: 'JSS Hospital', services: 'Geriatric care, Home doctor visits, Nursing.', contact: '96112-21155' },
  { name: 'Manipal Hospital', services: 'Lab collection, Wound care, Physiotherapy.', contact: '0821-2550000' },
  { name: 'Narayana Health', services: 'Cardiac recovery, Nursing, Sample collection.', contact: '0806-7506870' }
];

const PRICING = {
  nursing: [
    { name: 'Single Visit (Injection/Dressing)', price: '₹400 – ₹800' },
    { name: '12-Hour Shift Care', price: '₹1,200 – ₹1,900' },
    { name: '24-Hour Residential Nursing', price: '₹1,800 – ₹2,800 / day' }
  ],
  physio: [
    { name: 'Assessment Consultation', price: '₹250 – ₹650' },
    { name: 'Standard Treatment Session', price: '₹600 – ₹1,200' }
  ],
  doctors: [
    { name: 'General Physician Visit', price: '₹1,000 – ₹2,500' },
    { name: 'Specialist Home Visit', price: '₹2,500 – ₹5,000' }
  ],
  elderCare: [
    { name: 'Semi-skilled Attendant (12h)', price: '₹800 – ₹1,200' },
    { name: 'Blood Sample Collection Fee', price: '₹0 – ₹200' }
  ]
};

export const SpecialServices: React.FC<SpecialServicesProps> = ({ onBook }) => {
  const { t } = useLanguage();

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="container mx-auto px-4 py-12 max-w-7xl font-sans"
    >
      <header className="mb-16 text-center">
        <span className="text-[#0d9e6e] font-black uppercase tracking-widest text-xs mb-4 block">Medical Solutions</span>
        <h1 className="text-5xl md:text-7xl font-black text-slate-800 italic uppercase tracking-tighter mb-6">
          {t('homeHealthcare')} <span className="text-[#0d9e6e]">In Mysore</span>
        </h1>
        <p className="max-w-2xl mx-auto text-slate-500 font-bold leading-relaxed uppercase tracking-widest text-[10px]">
          Directory of hospitals and agencies offering home-based medical care, including nursing, physiotherapy, and elderly support.
        </p>
      </header>

      {/* Major Hospitals Section */}
      <section className="mb-20">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-black text-slate-800 italic uppercase tracking-tight flex items-center gap-3">
            <HeartPulse className="text-[#0d9e6e]" /> {t('majorHospitals')}
          </h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {HOSPITALS.map((hospital, idx) => (
            <motion.div
              key={idx}
              whileHover={{ y: -10 }}
              className="bg-white border-2 border-slate-100 rounded-[32px] p-8 shadow-sm hover:shadow-xl hover:border-[#0d9e6e]/20 transition-all group"
            >
              <div className="w-12 h-12 bg-slate-50 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-[#0d9e6e] transition-colors">
                <MapPin className="text-slate-400 group-hover:text-white" />
              </div>
              <h3 className="text-xl font-black text-slate-800 uppercase italic mb-2 tracking-tight">{hospital.name}</h3>
              <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-6 leading-relaxed">
                {hospital.services}
              </p>
              <div className="flex items-center gap-2 text-[#0d9e6e] font-black text-xs mb-6">
                <Phone size={14} /> {hospital.contact}
              </div>
              <button 
                onClick={() => onBook('Home Care', hospital.name)}
                className="w-full bg-slate-900 text-white font-black uppercase text-[10px] tracking-[0.2em] py-4 rounded-2xl hover:bg-[#0d9e6e] transition-colors flex items-center justify-center gap-2"
              >
                {t('bookService')} <ChevronRight size={14} />
              </button>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Pricing Estimates */}
      <section className="mb-20">
        <h2 className="text-2xl font-black text-slate-800 italic uppercase tracking-tight flex items-center gap-3 mb-10">
          <ShieldCheck className="text-[#0d9e6e]" /> {t('pricingEstimates')}
        </h2>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {/* Nursing */}
          <PricingCard 
            title={t('nurseVisits')} 
            icon={<Stethoscope size={20} />} 
            items={PRICING.nursing} 
            onBook={(s) => onBook(s)}
          />
          {/* Physio */}
          <PricingCard 
            title={t('physiotherapy')} 
            icon={<Accessibility size={20} />} 
            items={PRICING.physio} 
            onBook={(s) => onBook(s)}
          />
          {/* Doctors */}
          <PricingCard 
            title={t('doctorConsultations')} 
            icon={<Clock size={20} />} 
            items={PRICING.doctors} 
            onBook={(s) => onBook(s)}
          />
          {/* Elder Care */}
          <PricingCard 
            title={t('elderCare')} 
            icon={<HeartPulse size={20} />} 
            items={PRICING.elderCare} 
            onBook={(s) => onBook(s)}
          />
        </div>
      </section>

      {/* Specialized Agencies */}
      <section className="bg-slate-900 rounded-[48px] p-12 text-white overflow-hidden relative">
        <div className="absolute top-0 right-0 w-96 h-96 bg-[#0d9e6e] blur-[120px] opacity-20 -mr-48 -mt-48" />
        <div className="relative z-10">
          <h2 className="text-3xl font-black italic uppercase tracking-tight mb-8">Specialized Agencies</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <AgencyItem 
              name="Portea Medical" 
              desc="Comprehensive nursing and equipment rentals." 
              onBook={() => onBook('Home Care', 'Portea Medical')}
            />
            <AgencyItem 
              name="Shri Manjunatha Home Nursing" 
              desc="Skilled bedside care and long-term support." 
              onBook={() => onBook('Home Nursing', 'Shri Manjunatha')}
            />
            <AgencyItem 
              name="HealthVibes" 
              desc="Mobile diagnostic testing and physician services." 
              onBook={() => onBook('Diagnostics', 'HealthVibes')}
            />
          </div>
          <div className="mt-12 pt-8 border-t border-white/10 text-[10px] uppercase font-bold tracking-widest text-slate-400">
            Important: Rates are estimates based on standard city averages in Mysore. Prices vary based on complexity, patient condition, and travel distance.
          </div>
        </div>
      </section>
    </motion.div>
  );
};

const PricingCard: React.FC<{ title: string; icon: React.ReactNode; items: ServicePrice[]; onBook: (s: string) => void }> = ({ title, icon, items, onBook }) => (
  <div className="bg-white border-2 border-slate-100 rounded-[40px] p-8">
    <div className="flex items-center gap-3 mb-8">
      <div className="w-10 h-10 bg-[#0d9e6e]/10 rounded-xl flex items-center justify-center text-[#0d9e6e]">
        {icon}
      </div>
      <h3 className="text-lg font-black text-slate-800 uppercase italic tracking-tight">{title}</h3>
    </div>
    <div className="space-y-6">
      {items.map((item, idx) => (
        <div key={idx} className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl hover:bg-slate-50 transition-colors">
          <div>
            <p className="text-sm font-black text-slate-800 uppercase italic">{item.name}</p>
          </div>
          <div className="flex items-center gap-6">
            <span className="text-[#0d9e6e] font-black text-sm">{item.price}</span>
            <button 
              onClick={() => onBook(item.name)}
              className="bg-slate-900 text-white text-[9px] font-black uppercase tracking-widest px-4 py-2 rounded-lg hover:bg-[#0d9e6e] transition-colors"
            >
              Book
            </button>
          </div>
        </div>
      ))}
    </div>
  </div>
);

const AgencyItem: React.FC<{ name: string; desc: string; onBook: () => void }> = ({ name, desc, onBook }) => (
  <div className="group cursor-pointer" onClick={onBook}>
    <h4 className="text-xl font-black text-[#0d9e6e] italic uppercase mb-2 group-hover:translate-x-2 transition-transform">{name}</h4>
    <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest leading-relaxed mb-4">{desc}</p>
    <div className="flex items-center gap-2 text-white font-black text-[9px] uppercase tracking-[0.2em] opacity-60 group-hover:opacity-100 transition-opacity">
      Select Provider <ChevronRight size={10} />
    </div>
  </div>
);
