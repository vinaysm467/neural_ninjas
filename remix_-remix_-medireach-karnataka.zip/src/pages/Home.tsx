import React from 'react';
import { motion } from 'motion/react';
import { Search, Stethoscope, AlertTriangle, Pill, ChevronRight, ShieldCheck, Truck, BarChart3, ClipboardList } from 'lucide-react';
import { HOSPITALS } from '../data';
import { cn } from '../lib/utils';
import { useLanguage } from '../contexts/LanguageContext';

interface HomeProps {
  setActiveTab: (id: string) => void;
}

export const Home: React.FC<HomeProps> = ({ setActiveTab }) => {
  const { t } = useLanguage();
  
  const features = [
    { id: 'hospitals', icon: <Search className="w-5 h-5" />, title: t('findHospitals'), desc: t('findHospitalsDesc'), color: 'text-[#0d9e6e]' },
    { id: 'ambulance', icon: <Truck className="w-5 h-5" />, title: t('ambulance'), desc: t('ambulanceDesc'), color: 'text-red-600' },
    { id: 'doctors', icon: <Stethoscope className="w-5 h-5" />, title: t('doctors'), desc: t('doctorsDesc'), color: 'text-teal-600' },
    { id: 'symptoms', icon: <AlertTriangle className="w-5 h-5" />, title: t('symptomCheck'), desc: t('symptomCheckDesc'), color: 'text-red-500' },
    { id: 'compare', icon: <BarChart3 className="w-5 h-5" />, title: t('compare'), desc: t('compareDesc'), color: 'text-blue-600' },
    { id: 'medicines', icon: <Pill className="w-5 h-5" />, title: t('medicines'), desc: t('medicinesDescHome'), color: 'text-amber-500' },
    { id: 'insurance', icon: <ShieldCheck className="w-5 h-5" />, title: t('insurance'), desc: t('insuranceDescHome'), color: 'text-green-600' },
    { id: 'records', icon: <ClipboardList className="w-5 h-5" />, title: t('myRecords'), desc: t('recordsDesc'), color: 'text-indigo-600' },
  ];

  const stats = [
    { label: t('statsHospitals'), value: '60+', color: 'text-[#0d9e6e]' },
    { label: t('statsDoctors'), value: '300+', color: 'text-[#0891b2]' },
    { label: t('statsAmbulances'), value: '36', color: 'text-red-600' },
    { label: t('statsSavings'), value: '80%', color: 'text-slate-800' },
  ];

  return (
    <div className="bg-[#f8fafb] min-h-screen">
      {/* Hero Section */}
      <section className="py-12 md:py-20 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="bg-white rounded-2xl border border-slate-200 p-8 md:p-16 shadow-sm flex flex-col justify-center relative overflow-hidden min-h-[400px]">
            <div className="absolute -right-24 -top-24 w-64 h-64 bg-[#0d9e6e]/5 rounded-full blur-3xl"></div>
            <div className="absolute -left-12 -bottom-12 w-48 h-48 bg-[#0891b2]/5 rounded-full blur-2xl"></div>
            
            <div className="relative z-10 max-w-2xl">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="inline-flex items-center gap-2 px-3 py-1 bg-[#0d9e6e]/10 text-[#0d9e6e] rounded-full text-[10px] font-black uppercase tracking-widest mb-6"
              >
                <div className="w-1.5 h-1.5 rounded-full bg-[#0d9e6e] animate-pulse" />
                {t('liveKarnataka')}
              </motion.div>
              
              <motion.h1 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-4xl md:text-6xl font-black text-slate-800 leading-[1.1] mb-6 font-display"
              >
                {t('heroTitle')} <br />
                <span className="text-[#0d9e6e]">{t('heroTitleHighlight')}</span>
              </motion.h1>
              
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="text-slate-500 max-w-md text-lg mb-8 font-medium leading-relaxed"
              >
                {t('heroSubtitle')}
              </motion.p>
              
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="flex flex-wrap gap-4"
              >
                <button 
                  onClick={() => setActiveTab('hospitals')}
                  className="bg-[#0d9e6e] text-white px-8 py-3.5 rounded-xl font-bold text-sm shadow-lg shadow-[#0d9e6e]/20 hover:scale-[1.02] active:scale-95 transition-all"
                >
                  {t('findHospitals')}
                </button>
                <button 
                  onClick={() => setActiveTab('symptoms')}
                  className="bg-[#0891b2] text-white px-8 py-3.5 rounded-xl font-bold text-sm hover:scale-[1.02] active:scale-95 transition-all"
                >
                  {t('symptomCheck')}
                </button>
                <button 
                  onClick={() => setActiveTab('doctors')}
                  className="bg-white text-slate-700 border border-slate-200 px-8 py-3.5 rounded-xl font-bold text-sm hover:bg-slate-50 transition-all font-sans"
                >
                  {t('bookAppointment')}
                </button>
              </motion.div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Stats Grid */}
      <section className="px-6 pb-20">
        <div className="max-w-7xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {stats.map((stat, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              viewport={{ once: true }}
              className="bg-white p-6 rounded-2xl border border-slate-200 text-center shadow-sm hover:border-[#0d9e6e]/30 transition-colors"
            >
              <p className={cn("text-3xl font-black mb-1 font-display", stat.color)}>{stat.value}</p>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{stat.label}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Feature Grid */}
      <section className="px-6 pb-24">
        <div className="max-w-7xl mx-auto">
          <div className="mb-12">
            <h2 className="text-2xl font-black text-slate-800 mb-2 font-display uppercase tracking-tight">{t('ecosystemTitle')}</h2>
            <p className="text-slate-500 font-medium">{t('ecosystemSubtitle')}</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, idx) => (
              <motion.div 
                key={idx}
                whileHover={{ y: -5 }}
                onClick={() => setActiveTab(feature.id)}
                className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all cursor-pointer group"
              >
                <div className={cn("mb-6 p-4 bg-slate-50 rounded-xl w-fit group-hover:scale-110 transition-transform", feature.color)}>
                  {feature.icon}
                </div>
                <h3 className="text-lg font-black text-slate-800 mb-3 font-display tracking-tight">{feature.title}</h3>
                <p className="text-slate-500 text-sm leading-relaxed font-medium mb-6">{feature.desc}</p>
                <div className="text-[#0d9e6e] text-xs font-black uppercase tracking-widest flex items-center gap-2">
                  {t('launch')} <ChevronRight className="w-3 h-3" />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Hospitals & Patient ID */}
      <section className="px-6 pb-24">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 font-sans">
          {/* Hospital Preview */}
          <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
            <div className="px-8 py-5 border-b border-slate-100 flex justify-between items-center bg-slate-50/50 uppercase">
              <h3 className="font-black text-slate-800 text-[10px] tracking-[0.2em] font-display">{t('nearbyVerified')}</h3>
              <button onClick={() => setActiveTab('hospitals')} className="text-[#0d9e6e] text-[10px] font-black tracking-widest">{t('viewAll')} →</button>
            </div>
            <div className="divide-y divide-slate-100">
              {HOSPITALS.slice(0, 3).map((h) => (
                <div key={h.id} onClick={() => setActiveTab('hospitals')} className="px-8 py-5 flex items-center justify-between hover:bg-slate-50 transition-colors cursor-pointer group">
                  <div className="flex gap-4 items-center">
                    <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center font-black text-[#0d9e6e] text-xs group-hover:bg-white transition-colors">
                      {h.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <p className="hospital-name text-sm text-slate-800">{h.name}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">{h.address.split(',')[0]} • {h.rating.toFixed(1)} ★ {t('rating')}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="px-2 py-1 bg-[#0d9e6e]/10 text-[#0d9e6e] text-[9px] font-black rounded uppercase tracking-widest">
                      {h.type === 'Government' ? t('government') : h.type === 'Private' ? t('private') : t('trust')}
                    </span>
                    <p className="text-xs font-black text-slate-700 mt-2 font-display">₹{h.avg_fee}/day</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Side Cards */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            <div className="bg-[#0a3622] rounded-2xl p-6 text-white shadow-xl relative overflow-hidden group">
              <div className="absolute -right-8 -top-8 w-32 h-32 bg-white/5 rounded-full group-hover:scale-110 transition-transform"></div>
              <div className="flex items-center justify-between mb-2 uppercase">
                <h3 className="font-black text-[10px] tracking-widest font-display">{t('universalId')}</h3>
                <div className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
                  <ShieldCheck className="w-4 h-4 text-[#0d9e6e]" />
                </div>
              </div>
              <p className="text-3xl font-black text-white mb-1 font-display tracking-tighter">RK-MYS-9482</p>
              <p className="text-[10px] text-white/50 uppercase font-black tracking-[0.2em] mb-6">{t('securedRecord')}</p>
              
              <div className="flex gap-4 border-t border-white/10 pt-4">
                <div>
                  <p className="text-[8px] text-white/40 uppercase font-bold mb-1">{t('bloodGroup')}</p>
                  <p className="text-xs font-black">O+</p>
                </div>
                <div>
                  <p className="text-[8px] text-white/40 uppercase font-bold mb-1">{t('scheme')}</p>
                  <p className="text-xs font-black">Ayushman B.</p>
                </div>
              </div>
            </div>

            <div className="bg-white border-2 border-dashed border-slate-200 rounded-2xl p-6 flex flex-col gap-4">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center text-2xl shadow-inner italic">💊</div>
                <div>
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5">{t('savingsRadar')}</p>
                  <p className="text-sm font-black text-[#0d9e6e] font-display uppercase tracking-tight">{t('janAushadhiActive')}</p>
                </div>
              </div>
              <p className="text-[11px] text-slate-500 font-medium leading-relaxed">
                {t('savingsDesc')}
              </p>
              <button 
                onClick={() => setActiveTab('medicines')}
                className="w-full py-2 bg-slate-100 font-black text-[10px] uppercase tracking-widest text-slate-600 rounded-lg hover:bg-slate-200 transition-colors"
              >
                {t('analyzePrescription')}
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
