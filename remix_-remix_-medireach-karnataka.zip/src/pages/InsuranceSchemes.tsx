import React, { useState, useMemo } from 'react';
import { ShieldCheck, Info, Search, CheckCircle, Award, Users, FileText, ChevronRight, ExternalLink, IndianRupee, Star, MapPin, Phone, Globe } from 'lucide-react';
import { HOSPITALS } from '../data';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';
import { useLanguage } from '../contexts/LanguageContext';

export const InsuranceSchemes: React.FC = () => {
  const [selectedScheme, setSelectedScheme] = useState('Ayushman Bharat');
  const [selectedArea, setSelectedArea] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const { t } = useLanguage();

  const insuranceLinks: Record<string, string> = {
    'Ayushman Bharat': 'https://pmjay.gov.in/',
    'Star Health': 'https://www.starhealth.in/',
    'HDFC ERGO': 'https://www.hdfcergo.com/',
    'ICICI Lombard': 'https://www.icicilombard.com/',
    'Care Health': 'https://www.careinsurance.com/',
    'ESI': 'https://www.esic.gov.in/',
    'CGHS': 'https://cghs.gov.in/',
    'Jan Aushadhi': 'https://janaushadhi.gov.in/',
    'Karnataka Health': 'https://hfwcom.karnataka.gov.in/',
    'Jyothi Sanjeevini': 'https://arogya.karnataka.gov.in/',
    'Vajpayee Arogyasree': 'https://arogya.karnataka.gov.in/'
  };

  const schemes = [
    { 
      id: 'ab', 
      name: 'Ayushman Bharat', 
      translationKey: 'ayushmanBharat',
      description: t('abDesc'),
      color: 'bg-orange-500',
      beneficiaries: t('over10Crore'),
      official_website_url: "https://pmjay.gov.in/"
    },
    { 
      id: 'js', 
      name: 'Jyothi Sanjeevini', 
      translationKey: 'jyothiSanjeevini',
      description: t('jsDesc'),
      color: 'bg-blue-500',
      beneficiaries: t('govtEmployees'),
      official_website_url: "https://arogya.karnataka.gov.in/"
    },
    { 
      id: 'va', 
      name: 'Vajpayee Arogyasree', 
      translationKey: 'vajpayeeArogyasree',
      description: t('vaDesc'),
      color: 'bg-amber-500',
      beneficiaries: t('bplFamilies'),
      official_website_url: "https://arogya.karnataka.gov.in/"
    },
    { 
      id: 'esi', 
      name: 'ESI', 
      translationKey: 'esi',
      description: t('esiDesc'),
      color: 'bg-red-500',
      beneficiaries: t('industrialWorkers'),
      official_website_url: "https://www.esic.gov.in/"
    },
    { 
      id: 'kh', 
      name: 'Karnataka Health', 
      translationKey: 'karnatakaHealth',
      description: 'Health & Family Welfare Dept, Karnataka',
      color: 'bg-emerald-600',
      beneficiaries: 'Karnataka Citizens',
      official_website_url: "https://hfwcom.karnataka.gov.in/"
    },
    { 
      id: 'cghs', 
      name: 'CGHS', 
      translationKey: 'cghs',
      description: t('cghsDesc'),
      color: 'bg-teal-600',
      beneficiaries: t('centralGovtEmployees'),
      official_website_url: "https://cghs.gov.in/"
    },
    { 
      id: 'ja', 
      name: 'Jan Aushadhi', 
      translationKey: 'janAushadhi',
      description: 'Pradhan Mantri Bhartiya Janaushadhi Pariyojana',
      color: 'bg-indigo-600',
      beneficiaries: 'General Public',
      official_website_url: "https://janaushadhi.gov.in/"
    },
    { 
      id: 'private', 
      name: 'Private Insurance', 
      translationKey: 'privateInsurance',
      description: t('privateDesc'),
      color: 'bg-purple-600',
      beneficiaries: t('policyHolders')
    }
  ];

  const areas = useMemo(() => {
    return ['All', ...Array.from(new Set(HOSPITALS.map(h => h.area)))].sort();
  }, []);

  const matchingHospitals = useMemo(() => {
    return HOSPITALS.filter(h => {
      const matchesScheme = (h.insurance_accepted || []).some(s => 
        s.toLowerCase().includes(selectedScheme.toLowerCase()) || 
        (selectedScheme === 'Private Insurance' && (s.toLowerCase().includes('private') || s.toLowerCase().includes('star') || s.toLowerCase().includes('icici')))
      );
      
      const matchesArea = selectedArea === 'All' || h.area === selectedArea;
      
      const matchesSearch = h.name.toLowerCase().includes(searchQuery.toLowerCase());

      return matchesScheme && matchesArea && matchesSearch;
    });
  }, [selectedScheme, selectedArea, searchQuery]);

  return (
    <div className="bg-[#f8fafb] min-h-screen py-12 px-4 shadow-inner">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-20 h-20 bg-[#0d9e6e]/10 rounded-full flex items-center justify-center text-[#0d9e6e] mx-auto mb-6 shadow-lg shadow-[#0d9e6e]/10"
          >
            <ShieldCheck className="w-10 h-10" />
          </motion.div>
          <h1 className="text-4xl font-black text-slate-800 mb-4 font-display">{t('empanelledHospitals')}</h1>
          <p className="text-slate-500 max-w-2xl mx-auto text-lg font-medium">{t('insuranceDesc')}</p>
        </div>

        <div className="bg-white p-10 rounded-[48px] border border-slate-200 shadow-sm mb-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 items-end">
            <div className="lg:col-span-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-4">{t('selectScheme')}</label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {schemes.map(scheme => (
                  <div
                    key={scheme.id}
                    onClick={() => setSelectedScheme(scheme.name)}
                    className={cn(
                      "p-4 rounded-2xl border-2 text-left transition-all group relative cursor-pointer",
                      selectedScheme === scheme.name 
                        ? "border-[#0d9e6e] bg-[#0d9e6e]/5 shadow-inner" 
                        : "border-slate-50 bg-slate-50 hover:border-slate-200"
                    )}
                  >
                    <div className="flex items-center gap-3 mb-1">
                      <div className={cn("w-2.5 h-2.5 rounded-full", scheme.color)} />
                      <span className={cn("text-xs font-black uppercase tracking-tight transition-colors", selectedScheme === scheme.name ? "text-[#0d9e6e]" : "text-slate-600 group-hover:text-slate-900")}>
                        {scheme.translationKey ? t(scheme.translationKey as any) : scheme.name}
                      </span>
                    </div>
                    <p className="text-[10px] text-slate-400 font-bold leading-tight group-hover:text-slate-500 mb-3">{scheme.description}</p>
                    
                    {scheme.official_website_url && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          window.open(scheme.official_website_url, '_blank', 'noopener,noreferrer');
                        }}
                        className="w-full flex items-center justify-center gap-2 bg-white border border-slate-200 rounded-xl text-[9px] font-black uppercase tracking-widest text-slate-500 hover:text-[#0d9e6e] hover:border-[#0d9e6e] transition-all"
                      >
                        <Globe className="w-3 h-3" />
                        {t('visitWebsite')}
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

            <div>
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-4">{t('area')}</label>
              <select 
                value={selectedArea}
                onChange={(e) => setSelectedArea(e.target.value)}
                className="w-full p-4 bg-slate-50 border-2 border-slate-50 rounded-2xl text-sm font-bold text-slate-700 outline-none focus:ring-4 focus:ring-[#0d9e6e]/10 focus:border-[#0d9e6e]/20 appearance-none bg-[url('data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20fill%3D%22none%22%20stroke%3D%22%23cbd5e1%22%20stroke-width%3D%222%22%20stroke-linecap%3D%22round%22%20stroke-linejoin%3D%22round%22%3E%3Cpolyline%20points%3D%226%209%2012%2015%2018%209%22%3E%3C%2Fpolyline%3E%3C%2Fsvg%3E')] bg-[length:1.25rem_1.25rem] bg-[right_1rem_center] bg-no-repeat"
              >
                {areas.map(a => <option key={a} value={a}>{a === 'All' ? t('allAreas') : a}</option>)}
              </select>
            </div>

            <div>
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-4">{t('search')}</label>
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input 
                  type="text" 
                  placeholder={`${t('hospitalName')}...`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-12 pr-4 py-4 bg-slate-50 border-2 border-slate-50 rounded-2xl text-sm font-bold text-slate-700 outline-none focus:ring-4 focus:ring-[#0d9e6e]/10 focus:border-[#0d9e6e]/20"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between mb-8 px-4">
          <div className="flex items-center gap-2">
            <span className="text-sm font-black text-slate-400 uppercase tracking-widest">{matchingHospitals.length} {t('matchingHospitals')}</span>
          </div>
          <div className="px-4 py-1.5 bg-[#0d9e6e] text-white rounded-full text-[10px] font-black uppercase tracking-widest animate-pulse">
            {t('verifiedList')}
          </div>
        </div>

        {matchingHospitals.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
            {matchingHospitals.map((hospital, idx) => (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.05 }}
                key={hospital.id}
                className="bg-white rounded-[40px] border border-slate-200 overflow-hidden shadow-sm hover:shadow-xl transition-all group"
              >
                <div className="h-48 relative overflow-hidden bg-slate-100">
                  <div className="absolute inset-0 flex items-center justify-center text-slate-300 font-black italic uppercase tracking-widest text-4xl opacity-20">MediReach</div>
                  <div className="absolute top-4 left-4 z-10">
                    <span className="bg-white/90 backdrop-blur px-3 py-1 rounded-full text-[10px] font-black text-[#0d9e6e] shadow-sm uppercase tracking-widest border border-white/20">
                      {hospital.type === 'Government' ? t('government') : hospital.type === 'Private' ? t('private') : t('trust')}
                    </span>
                  </div>
                </div>
                <div className="p-8">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex items-center gap-1 text-amber-500">
                      <Star className="w-3.5 h-3.5 fill-amber-500" />
                      <span className="text-xs font-black">{hospital.rating.toFixed(1)}</span>
                    </div>
                    <span className="text-slate-300">•</span>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{hospital.area}, {hospital.district}</span>
                  </div>
                  <h3 className="text-xl font-black text-slate-800 mb-6 group-hover:text-[#0d9e6e] transition-colors line-clamp-1">{hospital.name}</h3>
                  
                  <div className="space-y-4 mb-8">
                    <div className="flex items-start gap-3">
                      <MapPin className="w-4 h-4 text-[#0d9e6e] shrink-0 mt-0.5" />
                      <p className="text-xs text-slate-500 font-bold leading-relaxed line-clamp-2 italic">{hospital.address}</p>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {(hospital.insurance_accepted || []).map((s, i) => (
                        <a 
                          key={i} 
                          href={insuranceLinks[s] || '#'}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={cn(
                          "px-2 py-0.5 rounded-lg text-[9px] font-black uppercase tracking-tighter transition-all hover:scale-105",
                          s.toLowerCase().includes(selectedScheme.toLowerCase()) || 
                          (selectedScheme === 'Private Insurance' && (s.toLowerCase().includes('private') || s.toLowerCase().includes('star') || s.toLowerCase().includes('icici')))
                            ? "bg-[#0d9e6e]/10 text-[#0d9e6e] ring-1 ring-[#0d9e6e]/20" 
                            : "bg-slate-50 text-slate-400"
                        )}>
                          {s}
                        </a>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <button className="flex items-center justify-center gap-2 py-3 bg-slate-50 text-slate-600 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-100 transition-colors">
                      <Phone className="w-3.5 h-3.5" /> {t('callNow')}
                    </button>
                    <button className="flex items-center justify-center gap-2 py-3 bg-[#0d9e6e] text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:shadow-lg hover:shadow-[#0d9e6e]/20 transition-all">
                      {t('directions')} <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <div className="py-32 bg-white rounded-[48px] border-4 border-dashed border-slate-100 text-center mb-20 max-w-4xl mx-auto shadow-sm">
            <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center text-slate-200 mx-auto mb-8">
              <Search className="w-12 h-12" />
            </div>
            <h3 className="text-3xl font-black text-slate-800 mb-4 font-display">{t('noHospitalsFound')}</h3>
            <p className="text-slate-500 text-lg font-medium max-w-md mx-auto mb-8">{t('noHospitalsFoundDesc').replace('{scheme}', selectedScheme).replace('{area}', selectedArea === 'All' ? t('allAreas') : selectedArea)}</p>
            <button 
              onClick={() => { setSelectedArea('All'); setSearchQuery(''); }}
              className="px-8 py-4 bg-slate-800 text-white rounded-2xl text-xs font-black uppercase tracking-[0.2em] hover:bg-[#0d9e6e] transition-all active:scale-95 shadow-lg shadow-slate-900/10"
            >
              {t('searchAllAreas')}
            </button>
          </div>
        )}

        {/* Info Banner */}
        <div className="bg-gray-900 rounded-[48px] p-12 text-white relative overflow-hidden group mb-20">
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {schemes.find(s => s.name === selectedScheme) && (
              <div className="flex flex-col gap-6">
                <div className="p-8 bg-white/5 border border-white/10 rounded-[32px] backdrop-blur-sm group-hover:bg-white/10 transition-all duration-500">
                  <p className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em] mb-4">{t('officialWebsite')}</p>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-2xl font-black italic">{t(schemes.find(s => s.name === selectedScheme)?.translationKey as any)}</p>
                      <p className="text-[10px] font-bold text-white/50 uppercase tracking-widest">{schemes.find(s => s.name === selectedScheme)?.beneficiaries}</p>
                    </div>
                    {schemes.find(s => s.name === selectedScheme)?.official_website_url && (
                      <a 
                        href={schemes.find(s => s.name === selectedScheme)?.official_website_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-6 py-3 bg-[#0d9e6e] text-white rounded-xl text-[10px] font-black uppercase tracking-widest transition-all hover:scale-105 flex items-center gap-2"
                      >
                        {t('visitWebsite')} <ExternalLink className="w-4 h-4" />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            )}
            <div>
              <div className="inline-block px-4 py-1.5 bg-white/10 backdrop-blur rounded-full text-[10px] font-black uppercase tracking-widest mb-6">{t('patientTip')}</div>
              <h2 className="text-3xl font-black mb-6 font-display leading-tight italic uppercase">{t('patientTipTitle')}</h2>
              <p className="text-white/80 font-bold leading-relaxed max-w-md italic">{t('patientTipDesc')}</p>
            </div>
          </div>
          <div className="absolute top-0 right-0 w-96 h-96 bg-[#0d9e6e]/10 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2" />
        </div>
      </div>
    </div>
  );
};

