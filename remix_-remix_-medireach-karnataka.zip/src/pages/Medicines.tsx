import React, { useState, useMemo } from 'react';
import { MEDICINES } from '../data';
import { Search, Pill, ShieldCheck, Info, ChevronRight, Save, Phone, IndianRupee, Tag, Zap, Award, MapPin, Navigation, Filter, ChevronLeft } from 'lucide-react';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { useLanguage } from '../contexts/LanguageContext';

// Fix for Leaflet default icon issues in React
const defaultIcon = L.icon({
  iconUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});
L.Marker.prototype.options.icon = defaultIcon;

const JAN_AUSHADHI_STORES = [
  { id: '1', name: 'K.R. Hospital Kendra', address: 'Ramanuja Road, Near KR Hospital, Mysuru', lat: 12.312, lng: 76.651, phone: '0821-2442345' },
  { id: '2', name: 'Saraswathipuram Kendra', address: 'Near Saraswathipuram Park, 5th Main, Mysuru', lat: 12.302, lng: 76.638, phone: '0821-2544123' },
  { id: '3', name: 'Kuvempunagar Kendra', address: 'Opp. Vishwamanava Double Road Complex, Mysuru', lat: 12.285, lng: 76.626, phone: '0821-2345678' },
  { id: '4', name: 'Jayanagar Kendra', address: 'Near Apollo BGS Hospital, Jayanagar, Mysuru', lat: 12.298, lng: 76.618, phone: '0821-9876543' },
];

// Controller to handle programmatic map pan/zoom
const MapController = ({ center, zoom }: { center: [number, number], zoom: number }) => {
  const map = useMap();
  React.useEffect(() => {
    map.setView(center, zoom, { animate: true });
  }, [center, zoom, map]);
  return null;
};

export const Medicines: React.FC = () => {
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedSavings, setSelectedSavings] = useState<string>('All');
  const [onlyJanAushadhi, setOnlyJanAushadhi] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedStore, setSelectedStore] = useState(JAN_AUSHADHI_STORES[0]);
  const { t } = useLanguage();
  const itemsPerPage = 20;

  const handleGetDirections = (lat?: number, lng?: number) => {
    if (lat && lng) {
      window.open(`https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`, '_blank');
    } else {
      window.open('https://www.google.com/maps/search/Jan+Aushadhi+Kendra+near+me', '_blank');
    }
  };

  const handleDistrictMap = (district: string) => {
    window.open(`https://www.google.com/maps/search/Jan+Aushadhi+Kendra+in+${district}`, '_blank');
  };

  const categories = useMemo(() => {
    return ['All', ...Array.from(new Set(MEDICINES.map(m => m.category)))];
  }, []);

  const filtered = useMemo(() => {
    return MEDICINES.filter(m => {
      const matchesQuery = 
        m.brand_name.toLowerCase().includes(query.toLowerCase()) || 
        m.generic_name.toLowerCase().includes(query.toLowerCase()) ||
        m.problem.toLowerCase().includes(query.toLowerCase());
      
      const matchesCategory = selectedCategory === 'All' || m.category === selectedCategory;
      
      const matchesSavings = selectedSavings === 'All' || 
        (selectedSavings === '75+' && m.savings_percent >= 75) ||
        (selectedSavings === '80+' && m.savings_percent >= 80);

      const matchesJanAushadhi = !onlyJanAushadhi || m.jan_aushadhi_available;

      return matchesQuery && matchesCategory && matchesSavings && matchesJanAushadhi;
    });
  }, [query, selectedCategory, selectedSavings, onlyJanAushadhi]);

  const totalPages = Math.ceil(filtered.length / itemsPerPage);
  const currentItems = filtered.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);

  return (
    <div className="bg-[#f8fafb] min-h-screen py-12 px-4 shadow-inner">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="w-20 h-20 bg-[#0d9e6e]/10 rounded-full flex items-center justify-center text-[#0d9e6e] mx-auto mb-6 shadow-lg shadow-[#0d9e6e]/10"
          >
            <Pill className="w-10 h-10" />
          </motion.div>
          <h1 className="text-4xl font-black text-slate-800 mb-4 font-display">{t('genericMedicines')}</h1>
          <p className="text-slate-500 max-w-2xl mx-auto text-lg font-medium">{t('medicinesDesc')}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 mb-12">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white p-8 rounded-[32px] border border-slate-200 shadow-sm sticky top-32">
              <div className="flex items-center gap-2 mb-8">
                <Filter className="w-5 h-5 text-[#0d9e6e]" />
                <h3 className="text-lg font-black text-slate-800 uppercase tracking-tight">{t('filter')}</h3>
              </div>

              <div className="space-y-8">
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-4">{t('category')}</label>
                    <select 
                      value={selectedCategory}
                      onChange={(e) => { setSelectedCategory(e.target.value); setCurrentPage(1); }}
                      className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-700 outline-none focus:ring-2 focus:ring-[#0d9e6e]/20"
                    >
                      {categories.map(c => <option key={c} value={c}>{c === 'All' ? t('all') : t(c.toLowerCase().replace(/\s+/g, '') as any)}</option>)}
                    </select>
                </div>

                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-4">Min. {t('savingLabel')}</label>
                  <div className="flex flex-wrap gap-2">
                    {['All', '75+', '80+'].map(s => (
                      <button
                        key={s}
                        onClick={() => { setSelectedSavings(s); setCurrentPage(1); }}
                        className={cn(
                          "px-4 py-2 rounded-xl text-xs font-black transition-all",
                          selectedSavings === s 
                            ? "bg-[#0d9e6e] text-white shadow-lg shadow-[#0d9e6e]/20" 
                            : "bg-slate-50 text-slate-500 hover:bg-slate-100"
                        )}
                      >
                        {s === 'All' ? t('any') : `${s}%`}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-100">
                  <label className="flex items-center gap-3 cursor-pointer group">
                    <input 
                      type="checkbox" 
                      checked={onlyJanAushadhi}
                      onChange={(e) => { setOnlyJanAushadhi(e.target.checked); setCurrentPage(1); }}
                      className="w-5 h-5 rounded border-slate-300 text-[#0d9e6e] focus:ring-[#0d9e6e]"
                    />
                    <span className="text-sm font-black text-slate-700 group-hover:text-[#0d9e6e] transition-colors">{t('janAushadhiOnly')}</span>
                  </label>
                </div>

                <div className="pt-6 border-t border-slate-100">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-4">{t('districtFinder')}</label>
                  <div className="grid grid-cols-2 gap-2">
                    {['Mysuru', 'Bengaluru Urban', 'Mandya', 'Hassan', 'Tumakuru', 'Chamarajanagar'].map(d => (
                      <button
                        key={d}
                        onClick={() => handleDistrictMap(d)}
                        className="p-2 bg-slate-50 border border-slate-100 rounded-lg text-[10px] font-black text-slate-600 hover:bg-[#0d9e6e] hover:text-white transition-all uppercase tracking-tighter"
                      >
                        {d} MAP
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Search and Results */}
          <div className="lg:col-span-3">
            <div className="relative mb-8">
              <Search className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-400 w-6 h-6" />
              <input 
                type="text" 
                placeholder={t('searchMedicines')}
                className="w-full pl-16 pr-8 py-5 bg-white border border-slate-200 rounded-[32px] text-lg font-medium focus:ring-4 focus:ring-[#0d9e6e]/10 outline-none shadow-sm transition-all"
                value={query}
                onChange={(e) => { setQuery(e.target.value); setCurrentPage(1); }}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
              {currentItems.length > 0 ? currentItems.map((m) => (
                <motion.div 
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  key={m.id} 
                  className="bg-white p-8 rounded-[40px] border border-slate-200 shadow-sm hover:shadow-xl transition-all group overflow-hidden relative"
                >
                  <div className="flex justify-between items-start mb-6">
                    <div className="flex-1 pr-4">
                      <h3 className="text-xl font-black text-slate-800 mb-1 group-hover:text-[#0d9e6e] transition-colors">{m.brand_name}</h3>
                      <p className="text-[10px] font-black text-[#0d9e6e] uppercase tracking-[0.2em]">{m.generic_name}</p>
                      <span className="inline-block mt-2 px-3 py-1 bg-slate-100 text-slate-500 text-[10px] font-black rounded-full uppercase tracking-widest">{t(m.category.toLowerCase().replace(/\s+/g, '') as any)}</span>
                    </div>
                    <div className="bg-[#0d9e6e] text-white p-3 rounded-2xl flex flex-col items-center shadow-lg shadow-[#0d9e6e]/20 group-hover:scale-110 transition-transform">
                      <span className="text-xl font-black">-{m.savings_percent}%</span>
                      <span className="text-[9px] font-black uppercase tracking-tighter opacity-80">{t('savingLabel')}</span>
                    </div>
                  </div>

                  <div className="space-y-6 mb-8">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 bg-slate-50 rounded-2xl border border-slate-100">
                        <p className="text-[9px] text-slate-400 font-black uppercase tracking-widest mb-1">{t('brandPrice')}</p>
                        <p className="text-lg font-medium text-slate-400 line-through">₹{m.brand_price}</p>
                      </div>
                      <div className="p-4 bg-[#0d9e6e]/5 rounded-2xl border border-[#0d9e6e]/20">
                        <p className="text-[9px] text-[#0d9e6e] font-black uppercase tracking-widest mb-1">{t('genericPrice')}</p>
                        <p className="text-xl font-black text-[#0d9e6e] flex items-center gap-1">₹{m.generic_price} <Zap className="w-4 h-4 fill-[#0d9e6e]" /></p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3 p-4 bg-slate-50/50 border border-slate-100 rounded-2xl group-hover:bg-white transition-colors">
                      <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-[#0d9e6e] shrink-0">
                        <Info className="w-4 h-4" />
                      </div>
                      <div>
                         <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5">{t('indications')}</p>
                         <p className="text-[11px] text-slate-600 font-bold leading-relaxed">{m.uses}</p>
                      </div>
                    </div>
                  </div>

                  <button 
                    onClick={() => handleGetDirections()}
                    className="w-full py-4 bg-slate-800 text-white font-black text-xs uppercase tracking-[0.2em] rounded-2xl hover:bg-[#0d9e6e] hover:shadow-lg hover:shadow-[#0d9e6e]/20 transition-all flex items-center justify-center gap-2 active:scale-95"
                  >
                    {t('janAushadhiKendra')} <ChevronRight className="w-4 h-4" />
                  </button>
                </motion.div>
              )) : (
                <div className="col-span-full py-20 bg-white rounded-[40px] border-2 border-dashed border-slate-200 text-center">
                  <p className="text-slate-400 font-bold text-xl italic mb-2">{t('noMedicinesFound')}</p>
                  <button 
                    onClick={() => { setQuery(''); setSelectedCategory('All'); setSelectedSavings('All'); setOnlyJanAushadhi(false); }}
                    className="text-[#0d9e6e] font-black uppercase text-xs tracking-widest hover:underline"
                  >
                    {t('clearFilters')}
                  </button>
                </div>
              )}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex justify-center items-center gap-4">
                <button 
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(prev => prev - 1)}
                  className="p-3 bg-white border border-slate-200 rounded-xl text-slate-600 disabled:opacity-30 hover:bg-[#0d9e6e] hover:text-white transition-all"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
                <span className="text-sm font-black text-slate-800">{t('pageOf').replace('{current}', currentPage.toString()).replace('{total}', totalPages.toString())}</span>
                <button 
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage(prev => prev + 1)}
                  className="p-3 bg-white border border-slate-200 rounded-xl text-slate-600 disabled:opacity-30 hover:bg-[#0d9e6e] hover:text-white transition-all"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            )}
          </div>
        </div>
        
        {/* Jan Aushadhi Section */}
        <section className="mb-20">
          <div className="flex justify-between items-end mb-8 uppercase">
            <div>
              <h2 className="text-2xl font-black text-slate-800 font-display tracking-tight">{t('janAushadhiLocator')}</h2>
              <p className="text-slate-500 font-bold text-[10px] mt-1 tracking-widest opacity-70">{t('officialKendrasDesc')}</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            <div className="lg:col-span-8 bg-white rounded-[40px] border border-slate-200 overflow-hidden shadow-sm h-[500px] z-0 relative">
              <MapContainer 
                center={[selectedStore.lat, selectedStore.lng]} 
                zoom={14} 
                style={{ height: '100%', width: '100%' }}
              >
                <MapController center={[selectedStore.lat, selectedStore.lng]} zoom={14} />
                <TileLayer
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                {JAN_AUSHADHI_STORES.map(store => (
                  <Marker 
                    key={store.id} 
                    position={[store.lat, store.lng]}
                    eventHandlers={{
                      click: () => setSelectedStore(store),
                    }}
                  >
                    <Popup>
                      <div className="p-1 font-sans">
                        <h4 className="font-black text-slate-800 text-sm mb-1">{store.name}</h4>
                        <p className="text-[10px] text-slate-500 font-bold mb-2">{store.address}</p>
                        <button 
                          onClick={() => handleGetDirections(store.lat, store.lng)}
                          className="w-full bg-[#0d9e6e] text-white py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest"
                        >
                          {t('directions')}
                        </button>
                      </div>
                    </Popup>
                  </Marker>
                ))}
              </MapContainer>
            </div>

            <div className="lg:col-span-4 flex flex-col gap-4">
              {JAN_AUSHADHI_STORES.map(store => (
                <div 
                  key={store.id}
                  onClick={() => setSelectedStore(store)}
                  className={cn(
                    "p-6 rounded-3xl border-2 transition-all cursor-pointer group relative overflow-hidden",
                    selectedStore.id === store.id ? "border-[#0d9e6e] bg-[#0d9e6e]/5" : "border-slate-50 bg-white hover:border-slate-200"
                  )}
                >
                  <div className="flex justify-between items-start mb-3">
                    <div className="w-10 h-10 bg-slate-100 rounded-xl flex items-center justify-center text-[#0d9e6e] shrink-0 group-hover:bg-white transition-colors">
                      <MapPin className="w-5 h-5" />
                    </div>
                    <button 
                      onClick={(e) => { e.stopPropagation(); handleGetDirections(store.lat, store.lng); }}
                      className="p-2.5 bg-white rounded-xl border border-slate-200 text-slate-400 hover:text-[#0d9e6e] hover:border-[#0d9e6e] transition-all shadow-sm"
                    >
                      <Navigation className="w-4 h-4" />
                    </button>
                  </div>
                  <h3 className="font-black text-slate-800 font-display text-sm mb-1">{store.name}</h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-tighter mb-4">{store.address}</p>
                  <div className="flex items-center gap-2 text-[11px] font-black text-slate-600">
                    <Phone className="w-3 h-3 text-[#0d9e6e]" /> {store.phone}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Jan Aushadhi Helpline */}
        <div className="bg-gray-900 rounded-[48px] p-8 md:p-12 text-white relative overflow-hidden">
          <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6 italic tracking-tight">{t('findingGenericsHelp')}</h2>
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-[#0d9e6e] rounded-2xl flex items-center justify-center shadow-lg shadow-[#0d9e6e]/20">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 font-bold uppercase tracking-widest">{t('pmHelpline')}</p>
                    <p className="text-xl font-black">1800-111-565</p>
                  </div>
                </div>
                <div className="p-6 bg-white/5 border border-white/10 rounded-3xl backdrop-blur-sm">
                  <p className="text-sm italic text-gray-300">
                    {t('janAushadhiQuote')}
                  </p>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
               {[
                 { label: t('authentic'), icon: <ShieldCheck className="w-5 h-5" /> },
                 { label: t('quality'), icon: <Award className="w-5 h-5" /> },
                 { label: t('priceMax'), icon: <Tag className="w-5 h-5" /> },
                 { label: t('savingLabel'), icon: <IndianRupee className="w-5 h-5" /> },
               ].map((item, i) => (
                 <div key={i} className="p-6 bg-white/5 border border-white/10 rounded-[32px] flex flex-col items-center text-center">
                   <div className="text-[#0d9e6e] mb-2">{item.icon}</div>
                   <p className="text-[10px] font-black uppercase tracking-widest">{item.label}</p>
                 </div>
               ))}
            </div>
          </div>
          <div className="absolute top-0 right-0 w-64 h-64 bg-[#0d9e6e]/20 rounded-full blur-[120px]" />
        </div>
      </div>
    </div>
  );
};
