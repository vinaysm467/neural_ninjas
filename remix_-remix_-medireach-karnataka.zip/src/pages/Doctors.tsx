import React, { useState, useMemo } from 'react';
import { Search, Filter, Star, Clock, MapPin, Award, CheckCircle, ChevronRight, IndianRupee, Globe } from 'lucide-react';
import { DOCTORS, HOSPITALS } from '../data';
import { cn } from '../lib/utils';
import { motion } from 'motion/react';
import { useLanguage } from '../contexts/LanguageContext';

interface DoctorsProps {
  onBookAppointment: (doctorId: string) => void;
}

export const Doctors: React.FC<DoctorsProps> = ({ onBookAppointment }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDistrict, setSelectedDistrict] = useState<string>('Bengaluru Urban');
  const [selectedSpecialty, setSelectedSpecialty] = useState<string>('All');
  const [selectedFee, setSelectedFee] = useState<string>('All');
  const [selectedExperience, setSelectedExperience] = useState<string>('All');
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>([]);
  const { t } = useLanguage();
  
  const districts = ['Mysuru', 'Bengaluru Urban', 'Mandya', 'Hassan', 'Tumakuru', 'Chamarajanagar'];

  const specialties = useMemo(() => {
    return ['All', ...Array.from(new Set(DOCTORS.map(d => d.specialty)))];
  }, []);

  const languages = useMemo(() => {
    const allLangs = DOCTORS.flatMap(d => d.languages);
    return Array.from(new Set(allLangs)).sort();
  }, []);

  const feeRanges = [
    { label: 'All Fees', value: 'All' },
    { label: 'Under ₹500', value: 'sub500' },
    { label: '₹500 - ₹1000', value: '500-1000' }
  ];

  const filteredDoctors = useMemo(() => {
    return DOCTORS.filter(d => {
      const hospital = HOSPITALS.find(h => h.id === d.hospital_id);
      const matchesDistrict = hospital?.district === selectedDistrict;
      const matchesSearch = d.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                           d.specialty.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesSpecialty = selectedSpecialty === 'All' || d.specialty === selectedSpecialty;
      
      let matchesFee = true;
      if (selectedFee === 'sub500') matchesFee = d.fee < 500;
      else if (selectedFee === '500-1000') matchesFee = d.fee >= 500 && d.fee <= 1000;

      let matchesExp = true;
      if (selectedExperience === '10+') matchesExp = d.experience >= 10;
      else if (selectedExperience === '20+') matchesExp = d.experience >= 20;

      const matchesLanguages = (selectedLanguages || []).length === 0 || 
                              (selectedLanguages || []).some(lang => (d.languages || []).includes(lang));

      return matchesDistrict && matchesSearch && matchesSpecialty && matchesFee && matchesExp && matchesLanguages;
    });
  }, [selectedDistrict, searchQuery, selectedSpecialty, selectedFee, selectedExperience, selectedLanguages]);

  return (
    <div className="bg-[#f8fafb] min-h-screen py-12 px-4 font-sans">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <h1 className="text-3xl font-bold text-slate-800 mb-2 font-display">{t('doctors')} <span className="text-[#0d9e6e]">{selectedDistrict}</span></h1>
            <p className="text-slate-500 font-medium">{t('doctorsDesc')}</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex flex-col">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">{t('selectDistrict')}</label>
              <select
                className="px-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#0d9e6e] outline-none transition-all bg-white font-semibold text-slate-600"
                value={selectedDistrict}
                onChange={(e) => setSelectedDistrict(e.target.value)}
              >
                {districts.map(d => <option key={d} value={d}>{d}</option>)}
              </select>
            </div>
            <div className="flex flex-col">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">{t('searchKeywords')}</label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 w-4 h-4" />
                <input
                  type="text"
                  placeholder={`${t('search')}...`}
                  className="pl-10 pr-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-[#0d9e6e] outline-none transition-all w-full md:w-64 bg-white"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
              <h3 className="font-bold text-slate-800 mb-6 flex items-center gap-2 uppercase text-[10px] tracking-widest text-slate-400">
                <Filter className="w-4 h-4 text-[#0d9e6e]" /> {t('filter')}
              </h3>
              
              <div className="space-y-8">
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-4">{t('consultationFee')}</label>
                  <div className="space-y-3">
                    {[
                      { label: t('allFees'), value: 'All' },
                      { label: t('under500'), value: 'sub500' },
                      { label: t('feeRange500_1000'), value: '500-1000' }
                    ].map((range) => (
                      <label key={range.value} className="flex items-center gap-3 cursor-pointer group">
                        <input 
                          type="radio" 
                          name="fee" 
                          className="w-4 h-4 text-[#0d9e6e] focus:ring-[#0d9e6e] border-slate-300" 
                          checked={selectedFee === range.value}
                          onChange={() => setSelectedFee(range.value)}
                        />
                        <span className={cn("text-sm transition-colors font-medium", selectedFee === range.value ? "text-[#0d9e6e] font-bold" : "text-slate-600 group-hover:text-slate-900")}>
                          {range.label}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-100">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-4">{t('experience')}</label>
                  <div className="space-y-3">
                    {[
                      { label: t('allExperience'), value: 'All' },
                      { label: t('tenPlusYears'), value: '10+' },
                      { label: t('twentyPlusYears'), value: '20+' }
                    ].map((exp) => (
                      <label key={exp.value} className="flex items-center gap-3 cursor-pointer group">
                        <input 
                          type="radio" 
                          name="experience"
                          className="w-4 h-4 text-[#0d9e6e] focus:ring-[#0d9e6e] border-slate-300" 
                          checked={selectedExperience === exp.value}
                          onChange={() => setSelectedExperience(exp.value)}
                        />
                        <span className={cn("text-sm transition-colors font-medium", selectedExperience === exp.value ? "text-[#0d9e6e] font-bold" : "text-slate-600 group-hover:text-slate-900")}>
                          {exp.label}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-100">
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] block mb-4">{t('languagesSpoken')}</label>
                  <div className="space-y-3">
                    {languages.map((lang) => (
                      <label key={lang} className="flex items-center gap-3 cursor-pointer group">
                        <input 
                          type="checkbox" 
                          className="w-4 h-4 rounded border-slate-300 text-[#0d9e6e] focus:ring-[#0d9e6e]" 
                          checked={selectedLanguages.includes(lang)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedLanguages(prev => [...prev, lang]);
                            } else {
                              setSelectedLanguages(prev => prev.filter(l => l !== lang));
                            }
                          }}
                        />
                        <span className={cn("text-sm transition-colors font-medium", selectedLanguages.includes(lang) ? "text-[#0d9e6e] font-bold" : "text-slate-600 group-hover:text-slate-900")}>
                          {t(lang.toLowerCase() as any)}
                        </span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-[#0d9e6e] p-6 rounded-2xl text-white shadow-lg overflow-hidden relative">
              <div className="relative z-10">
                <h4 className="font-bold text-lg mb-2">{t('needUrgentCare')}</h4>
                <p className="text-sm text-white/80 bg-white/10 p-2 rounded mb-4">{t('urgentCareDescStatus')}</p>
                <button className="w-full py-3 bg-white text-[#0d9e6e] font-bold rounded-xl text-sm shadow-sm hover:shadow-md transition-all">
                  {t('joinQueueNow')}
                </button>
              </div>
              <div className="absolute -bottom-8 -right-8 w-24 h-24 bg-white/20 rounded-full blur-2xl" />
            </div>
          </div>

          {/* Doctors Grid */}
          <div className="lg:col-span-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredDoctors.length > 0 ? filteredDoctors.map((doctor) => {
                const hospital = HOSPITALS.find(h => h.id === doctor.hospital_id);
                return (
                  <motion.div 
                    layout
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    key={doctor.id} 
                    className="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-all overflow-hidden"
                  >
                    <div className="p-6">
                      <div className="flex gap-4 mb-6">
                        <div className="w-20 h-20 rounded-2xl bg-slate-50 flex-shrink-0 flex items-center justify-center overflow-hidden border border-slate-100">
                          <img 
                            src={`https://ui-avatars.com/api/?name=${doctor.name}&background=0d9e6e&color=fff&size=128`} 
                            alt={doctor.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-1.5 mb-1">
                            <h3 className="font-black text-slate-800 font-display transition-colors group-hover:text-[#0d9e6e]">{doctor.name}</h3>
                            {doctor.verified && <CheckCircle className="w-4 h-4 text-[#0d9e6e] fill-[#0d9e6e]/10" />}
                          </div>
                          <p className="text-[10px] font-black text-[#0d9e6e] uppercase tracking-widest mb-2">{t(doctor.specialty.charAt(0).toLowerCase() + doctor.specialty.slice(1).replace(/\s+/g, '') as any)}</p>
                          <div className="flex items-center gap-4">
                            <div className="flex items-center gap-1">
                              <Star className="w-3 h-3 text-amber-500 fill-amber-500" />
                              <span className="text-xs font-black text-slate-700">{doctor.rating.toFixed(1)}</span>
                              <span className="text-[9px] text-slate-400 font-bold">({doctor.review_count})</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Award className="w-3 h-3 text-[#0891b2]" />
                              <span className="text-xs font-black text-slate-700">{doctor.experience}{t('yearsExperience')}</span>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-3 mb-6 bg-slate-50/50 p-4 rounded-xl border border-slate-100">
                        <div className="flex items-start gap-3">
                          <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-[#0d9e6e] shrink-0">
                            <MapPin className="w-4 h-4" />
                          </div>
                          <div className="text-[10px] uppercase font-bold text-slate-400 tracking-tight">
                            <p className="text-slate-800 font-black mb-0.5 font-display text-[11px] leading-tight">{hospital?.name}</p>
                            <p className="line-clamp-1 opacity-70">{hospital?.address}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-400 shrink-0">
                            <Clock className="w-4 h-4" />
                          </div>
                          <span className="text-[11px] font-black text-slate-700 font-display uppercase tracking-tighter">
                            {doctor.availability.replace('Mon', t('mon')).replace('Tue', t('tue')).replace('Wed', t('wed')).replace('Thu', t('thu')).replace('Fri', t('fri')).replace('Sat', t('sat')).replace('Sun', t('sun')).replace('Available Today', t('availableToday')).replace('Available Tomorrow', t('availableTomorrow'))}
                          </span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-white border border-slate-200 flex items-center justify-center text-slate-400 shrink-0">
                            <Globe className="w-4 h-4" />
                          </div>
                          <span className="text-[11px] font-black text-[#0891b2] font-display uppercase tracking-tight">{t('fluentIn')}: {(doctor.languages || []).map(l => t(l.toLowerCase().replace(/\s+/g, '') as any)).join(', ')}</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-6 border-t border-slate-100">
                        <div>
                          <p className="text-[9px] text-slate-400 uppercase font-black tracking-[0.2em] mb-1">{t('consultationFee')}</p>
                          <p className="text-2xl font-black text-slate-800 flex items-baseline gap-0.5 font-display">
                            <span className="text-sm font-medium">₹</span>{doctor.fee}
                          </p>
                        </div>
                        <button 
                          onClick={() => onBookAppointment(doctor.id)}
                          className="bg-[#0d9e6e] text-white px-6 py-3 rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-[#0bc385] transition-all flex items-center gap-2 shadow-lg shadow-[#0d9e6e]/20 active:scale-95"
                        >
                          {t('bookNow')} <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                );
              }) : (
                <div className="col-span-full py-20 text-center bg-white rounded-3xl border-2 border-dashed border-gray-100">
                  <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Search className="w-8 h-8 text-gray-200" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-2">{t('noSpecialistsFound')}</h3>
                  <p className="text-gray-500">{t('adjustFilters')}</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
