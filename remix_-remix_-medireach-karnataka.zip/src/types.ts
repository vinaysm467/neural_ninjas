export interface Patient {
  id: string;
  name: string;
  dob: string;
  bloodGroup: string;
  phone: string;
  email: string;
  address: string;
  emergencyContact: string;
  allergies: string;
  chronicConditions: string;
  currentMedications: string;
  insuranceProvider: string;
  insuranceId: string;
  createdAt: string;
}

export interface Hospital {
  id: string;
  name: string;
  district: string;
  area: string;
  type: 'Private' | 'Government' | 'Trust';
  address: string;
  phone: string;
  email: string;
  website_url: string;
  facebook_url: string;
  twitter_url: string;
  maps_url: string;
  lat: number;
  lng: number;
  distance_km: number;
  rating: number;
  total_reviews: number;
  avg_fee: number;
  beds: number;
  emergency: boolean;
  accreditation: string[];
  established: number;
  insurance_accepted: string[];
  facilities: string[];
  specialties: string[];
}

export interface Doctor {
  id: string;
  name: string;
  district: string;
  hospital_id: string;
  hospital_name: string;
  specialty: string;
  qualification: string;
  experience: number;
  fee: number;
  rating: number;
  review_count: number;
  languages: string[];
  availability: string;
  verified: boolean;
  phone: string;
  profile_summary: string;
  image?: string;
}

export interface Booking {
  id: string;
  patientName: string;
  phone: string;
  email: string;
  doctorId: string;
  hospitalId: string;
  date: string;
  time: string;
  reason: string;
  status: 'Pending' | 'Confirmed' | 'Cancelled' | 'Completed';
  createdAt: string;
}

export interface Medicine {
  id: string;
  brand_name: string;
  generic_name: string;
  category: string;
  problem: string;
  dosage_form: string;
  strength: string;
  brand_price: number;
  generic_price: number;
  savings_percent: number;
  uses: string;
  warning: string;
  availability: boolean;
  jan_aushadhi_available: boolean;
}

export interface TransferRequest {
  id: string;
  patientId: string;
  patientName: string;
  fromHospital: string;
  toHospital: string;
  reason: string;
  transferDate: string;
  recordsShared: string[];
  consentGiven: boolean;
  status: 'Pending Review' | 'Completed' | 'Rejected' | 'In Progress';
  createdAt: string;
}

export interface Ambulance {
  id: string;
  name: string;
  district: string;
  area: string;
  phone: string;
  type: 'Basic' | 'Advanced' | 'ICU' | 'Neonatal';
  availability: string;
  estimated_arrival: string;
  distance_km: number;
  linked_hospital: string;
  lat: number;
  lng: number;
  maps_route_url: string;
}

export interface DiseasePrice {
  id: string;
  disease_name: string;
  category: string;
  specialist_required: string;
  urgency_level: 'High' | 'Medium' | 'Low';
  hospital_id: string;
  hospital_name: string;
  district: string;
  area: string;
  consultation_fee: number;
  diagnostic_test_fee: number;
  medicine_estimate: number;
  procedure_estimate: number;
  min_estimated_cost: number;
  max_estimated_cost: number;
  total_estimated_cost: number;
  insurance_supported: boolean;
  schemes_supported: string[];
  rating: number;
  distance_km: number;
  waiting_time_mins: number;
  emergency_available: boolean;
  icu_facility_available: boolean;
  doctor_available: boolean;
  success_score: number;
  patient_satisfaction: number;
  maps_url: string;
  phone: string;
}
