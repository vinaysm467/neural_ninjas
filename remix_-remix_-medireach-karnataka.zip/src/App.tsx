import React, { useState, useEffect } from 'react';
import { EmergencyBar } from './components/EmergencyBar';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { Home } from './pages/Home';
import { FindHospitals } from './pages/FindHospitals';
import { Doctors } from './pages/Doctors';
import { HospitalProfile } from './pages/HospitalProfile';
import { CompareHospitals } from './pages/CompareHospitals';
import { AppointmentBooking } from './pages/AppointmentBooking';
import { SymptomChecker } from './pages/SymptomChecker';
import { Medicines } from './pages/Medicines';
import { InsuranceSchemes } from './pages/InsuranceSchemes';
import { MyHealthRecords } from './pages/MyHealthRecords';
import { AdminDashboard } from './pages/Dashboards';
import { AmbulanceServices } from './pages/AmbulanceServices';
import { Login } from './pages/Login';
import { HospitalDashboard } from './pages/HospitalDashboard';
import { SpecialServices } from './pages/SpecialServices';
import { ServiceBookingForm } from './pages/ServiceBookingForm';
import { ServiceBookingProcedure } from './pages/ServiceBookingProcedure';
import { HOSPITALS } from './data';
import { AnimatePresence, motion } from 'motion/react';
import { LanguageProvider } from './contexts/LanguageContext';
import { DOCTORS, AMBULANCES } from './data';

export default function App() {
  return (
    <LanguageProvider>
      <AppContent />
    </LanguageProvider>
  );
}

function AppContent() {
  const [user, setUser] = useState<{ role: 'patient' | 'hospital' | 'admin', name: string, id: string } | null>(null);
  const [activeTab, setActiveTab ] = useState('home');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check session on mount
    const checkSession = async () => {
      try {
        const response = await fetch('/api/auth/me');
        if (response.ok) {
          const data = await response.json();
          setUser(data);
          // If logged in as hospital, default to dashboard
          if (data.role === 'hospital') setActiveTab('hospital-dashboard');
        }
      } catch (err) {
        console.error('Session check failed:', err);
      } finally {
        setLoading(false);
      }
    };
    checkSession();
  }, []);

  const [selectedHospitalId, setSelectedHospitalId] = useState<string | null>(null);
  const [selectedDoctorId, setSelectedDoctorId] = useState<string | null>(null);
  const [bookingDiseaseInfo, setBookingDiseaseInfo] = useState<{ name: string; price: number } | null>(null);
  const [bookedService, setBookedService] = useState<{ name: string; provider: string } | null>(null);

  // Auto-scroll to top on tab change
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [activeTab]);

  const handleLogin = (role: 'patient' | 'hospital' | 'admin', userData: any) => {
    const newUser = { role, name: userData.name, id: userData.id };
    setUser(newUser);
    if (role === 'patient') setActiveTab('records');
    else if (role === 'hospital') setActiveTab('hospital-dashboard');
    else if (role === 'admin') setActiveTab('admin');
    else setActiveTab('home');
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
      setUser(null);
      setActiveTab('login');
    } catch (err) {
      console.error('Logout error:', err);
      setUser(null);
      setActiveTab('login');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f8fafb]">
        <div className="text-center animate-pulse">
          <div className="w-16 h-16 bg-[#0d9e6e] rounded-2xl flex items-center justify-center text-white text-2xl font-black mx-auto mb-4 shadow-xl shadow-[#0d9e6e]/20">M</div>
          <p className="text-[10px] font-black uppercase text-slate-400 tracking-[0.2em]">MediReach Karnataka Securing Session...</p>
        </div>
      </div>
    );
  }

  const handleHospitalSelect = (id: string) => {
    setSelectedHospitalId(id);
    setActiveTab('hospital_profile');
  };

  const handleBookAppointment = (hospitalId?: string, doctorId?: string, diseaseInfo?: { name: string; price: number }, fromCompare?: boolean) => {
    if (hospitalId) setSelectedHospitalId(hospitalId);
    if (doctorId) setSelectedDoctorId(doctorId);
    setBookingDiseaseInfo(diseaseInfo || null);
    setActiveTab('booking');
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'login':
        return <Login onLogin={handleLogin} />;
      case 'hospital-dashboard':
        if (!user || user.role !== 'hospital') return <Login onLogin={handleLogin} />;
        return <HospitalDashboard hospitalUser={user} onLogout={handleLogout} />;
      case 'home':
        return <Home setActiveTab={setActiveTab} />;
      case 'hospitals':
        return <FindHospitals onHospitalSelect={handleHospitalSelect} onBookAppointment={handleBookAppointment} />;
      case 'ambulance':
        return <AmbulanceServices />;
      case 'hospital_profile':
        const hospital = HOSPITALS.find(h => h.id === selectedHospitalId);
        return hospital ? (
          <HospitalProfile 
            hospital={hospital} 
            onBack={() => setActiveTab('hospitals')} 
            onBookAppointment={handleBookAppointment}
          />
        ) : <Home setActiveTab={setActiveTab} />;
      case 'doctors':
        return <Doctors onBookAppointment={(doctorId) => handleBookAppointment(undefined, doctorId)} />;
      case 'compare':
        return <CompareHospitals onBookAppointment={handleBookAppointment} />;
      case 'booking':
        return (
          <AppointmentBooking 
            initialHospitalId={selectedHospitalId || undefined} 
            initialDoctorId={selectedDoctorId || undefined}
            diseaseInfo={bookingDiseaseInfo}
            onBack={() => {
              if (bookingDiseaseInfo) setActiveTab('compare');
              else if (selectedDoctorId) setActiveTab('doctors');
              else setActiveTab('hospitals');
            }}
            onSuccess={(tab) => setActiveTab(tab || 'home')}
          />
        );
      case 'symptoms':
        return <SymptomChecker />;
      case 'medicines':
        return <Medicines />;
      case 'insurance':
        return <InsuranceSchemes />;
      case 'special_services':
        return (
          <SpecialServices 
            onBook={(service, provider) => {
              setBookedService({ name: service, provider: provider || '' });
              setActiveTab('service_form');
            }} 
          />
        );
      case 'service_form':
        return (
          <ServiceBookingForm 
            initialService={bookedService?.name || ''}
            initialProvider={bookedService?.provider}
            onConfirm={(details) => {
              setBookedService({ name: details.serviceName, provider: details.hospital });
              setActiveTab('booking_procedure');
            }}
            onCancel={() => setActiveTab('special_services')}
          />
        );
      case 'booking_procedure':
        return (
          <ServiceBookingProcedure 
            bookedService={bookedService} 
            onHome={() => setActiveTab('home')} 
          />
        );
      case 'records':
        if (!user) return <Login onLogin={handleLogin} />;
        return <MyHealthRecords />;
      case 'admin':
        if (user?.role !== 'admin') return <Home setActiveTab={setActiveTab} />;
        return <AdminDashboard />;
      default:
        return <Home setActiveTab={setActiveTab} />;
    }
  };

  const isRecordsTab = activeTab === 'records';
  const isHospitalDash = activeTab === 'hospital-dashboard';
  const showLogin = activeTab === 'login' || (!user && (isRecordsTab || isHospitalDash));

  // Hide common UI for login and hospital dashboard
  if (showLogin || (user?.role === 'hospital' && isHospitalDash)) {
    return (
      <div className="min-h-screen flex flex-col font-sans selection:bg-[#0d9e6e] selection:text-white">
        {showLogin ? <Login onLogin={handleLogin} /> : <HospitalDashboard hospitalUser={user!} onLogout={handleLogout} />}
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col font-sans selection:bg-[#0d9e6e] selection:text-white">
      <EmergencyBar onFindAmbulance={() => setActiveTab('ambulance')} />
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} user={user} onLogout={handleLogout} />
      
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.25, ease: "easeOut" }}
          >
            {renderContent()}
          </motion.div>
        </AnimatePresence>
      </main>

      <Footer />
      
      {/* Quick Admin Access (Admin Only) */}
      {user?.role === 'admin' && activeTab !== 'admin' && (
        <div className="fixed bottom-6 right-6 z-[1000]">
          <button 
            onClick={() => setActiveTab('admin')}
            className="w-12 h-12 bg-gray-900 text-white rounded-full flex items-center justify-center shadow-xl hover:scale-110 transition-transform flex-col"
            title="System Admin View"
          >
            <LayoutGrid className="w-5 h-5" />
            <span className="text-[6px] font-bold uppercase mt-0.5">Admin</span>
          </button>
        </div>
      )}
    </div>
  );
}

import { LayoutGrid } from 'lucide-react';

