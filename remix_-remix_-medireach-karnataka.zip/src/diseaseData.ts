import { DiseasePrice } from './types';
import { HOSPITALS } from './data';

// Helper to generate a disease price entry
const createDP = (
  id: string,
  name: string,
  cat: string,
  spec: string,
  urg: 'High' | 'Medium' | 'Low',
  h_id: string,
  h_name: string,
  dist: string,
  area: string,
  fees: { consult: number; test: number; med: number; proc: number },
  ins: boolean,
  schemes: string[],
  rating: number,
  distance: number,
  wait: number,
  em: boolean,
  icu: boolean,
  doc: boolean,
  success: number,
  sat: number,
  phone: string
): DiseasePrice => {
  const total = fees.consult + fees.test + fees.med + fees.proc;
  const min = Math.floor(total * 0.85);
  const max = Math.ceil(total * 1.15);
  return {
    id,
    disease_name: name,
    category: cat,
    specialist_required: spec,
    urgency_level: urg,
    hospital_id: h_id,
    hospital_name: h_name,
    district: dist,
    area: area,
    consultation_fee: fees.consult,
    diagnostic_test_fee: fees.test,
    medicine_estimate: fees.med,
    procedure_estimate: fees.proc,
    min_estimated_cost: min,
    max_estimated_cost: max,
    total_estimated_cost: total,
    insurance_supported: ins,
    schemes_supported: schemes,
    rating,
    distance_km: distance,
    waiting_time_mins: wait,
    emergency_available: em,
    icu_facility_available: icu,
    doctor_available: doc,
    success_score: success,
    patient_satisfaction: sat,
    maps_url: '',
    phone
  };
};

const diseasesList = [
  // Common (Low Severity)
  { name: 'Fever', cat: 'General', spec: 'General Physician', urg: 'Low' },
  { name: 'Common Cold', cat: 'General', spec: 'General Physician', urg: 'Low' },
  { name: 'Headache', cat: 'General', spec: 'General Physician', urg: 'Low' },
  { name: 'Migraine', cat: 'General', spec: 'Neurologist', urg: 'Low' },
  { name: 'Skin Allergy', cat: 'Skin', spec: 'Dermatologist', urg: 'Low' },
  { name: 'Back Pain', cat: 'Bone/Joint', spec: 'Orthopedic', urg: 'Low' },
  { name: 'Joint Pain', cat: 'Bone/Joint', spec: 'Orthopedic', urg: 'Low' },
  { name: 'Dental Pain', cat: 'Dental', spec: 'Dentist', urg: 'Low' },
  
  // Medium
  { name: 'Dengue', cat: 'Infectious', spec: 'Internal Medicine', urg: 'Medium' },
  { name: 'Malaria', cat: 'Infectious', spec: 'General Physician', urg: 'Medium' },
  { name: 'Typhoid', cat: 'Infectious', spec: 'General Physician', urg: 'Medium' },
  { name: 'Asthma', cat: 'Respiratory', spec: 'Pulmonologist', urg: 'Medium' },
  { name: 'Diabetes', cat: 'Diabetes', spec: 'Endocrinologist', urg: 'Medium' },
  { name: 'High Blood Pressure', cat: 'Heart', spec: 'Cardiologist', urg: 'Medium' },
  { name: 'Pregnancy Checkup', cat: 'Women health', spec: 'Gynecologist', urg: 'Low' },
  { name: 'Cancer Screening', cat: 'Oncology', spec: 'Oncologist', urg: 'Medium' },

  // Severe (High Severity)
  { name: 'Chest Pain', cat: 'Heart', spec: 'Cardiologist', urg: 'High' },
  { name: 'Heart Attack', cat: 'Heart', spec: 'Cardiologist', urg: 'High' },
  { name: 'Stroke', cat: 'Neurology', spec: 'Neurologist', urg: 'High' },
  { name: 'Cancer Treatment (Chemo)', cat: 'Oncology', spec: 'Oncologist', urg: 'High' },
  { name: 'Brain Surgery', cat: 'Neurology', spec: 'Neurosurgeon', urg: 'High' },
  { name: 'Kidney Failure', cat: 'Kidney/Urology', spec: 'Nephrologist', urg: 'High' },
  { name: 'ICU Admission', cat: 'Emergency', spec: 'Intensivist', urg: 'High' },
  { name: 'Accident Trauma', cat: 'Emergency', spec: 'Trauma Surgeon', urg: 'High' },
  { name: 'Pneumonia', cat: 'Respiratory', spec: 'Pulmonologist', urg: 'High' },
  { name: 'Emergency Appendectomy', cat: 'Emergency', spec: 'General Surgeon', urg: 'High' }
];

export const DISEASE_PRICES: DiseasePrice[] = [];

let dpId = 1;

// Assign all diseases to all hospitals to ensure complete coverage.
// With 1450 hospitals and 26 diseases, this is ~37k records, manageable for this app.
HOSPITALS.forEach((h) => {
  // Use a deterministic "random" based on hospital id to keep data stable
  const hSeed = h.id.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  
  diseasesList.forEach((d, dIdx) => {
    let consult = 400;
    let baseTotal = 5000;
    
    // Severity Base
    if (d.urg === 'Low') baseTotal = 600;
    else if (d.urg === 'Medium') baseTotal = 8000;
    else baseTotal = 80000;

    // Hospital Tier Adjustment
    if (h.type === 'Government') {
      consult = 0;
      baseTotal *= 0.05;
    } else if (h.type === 'Trust') {
      consult = 150 + (hSeed % 150);
      baseTotal *= 0.7;
    } else if (h.type === 'Private') {
      consult = 400 + (hSeed % 200);
      baseTotal *= 1.3;
    } else { // Fallback
      consult = 700 + (hSeed % 300);
      baseTotal *= 2.8;
    }

    // Add some random variance per hospital-disease combo for data variety
    // Using dIdx and hSeed ensures unique but stable values
    const variance = 0.8 + (((hSeed + dIdx) % 40) / 100);
    baseTotal *= variance;

    const test = Math.floor(baseTotal * 0.3);
    const med = Math.floor(baseTotal * 0.2);
    const proc = Math.floor(baseTotal * 0.5);
    
    DISEASE_PRICES.push(createDP(
      `dp${dpId++}`,
      d.name,
      d.cat,
      d.spec,
      d.urg as any,
      h.id,
      h.name,
      h.district,
      h.area,
      {
        consult,
        test,
        med,
        proc
      },
      true,
      h.insurance_accepted,
      h.rating,
      h.distance_km,
      15 + ((hSeed + dIdx) % 45),
      h.emergency,
      h.facilities.includes('ICU'),
      true,
      85 + ((hSeed + dIdx) % 15),
      80 + ((hSeed + dIdx) % 20),
      h.phone
    ));
  });
});

