import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import dotenv from "dotenv";
import cors from "cors";
import cookieParser from "cookie-parser";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { GoogleGenAI } from "@google/genai";
import { db } from "./db_mock.ts";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const JWT_SECRET = process.env.JWT_SECRET || "medireach-karnataka-super-secret-key-2026";
const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
 
// Security Middleware: Auth Protected Route
const authenticate = (req: any, res: any, next: any) => {
  const token = req.cookies.token;
  if (!token) return res.status(401).json({ message: "Session expired. Please login again." });

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    res.clearCookie("token");
    res.status(401).json({ message: "Invalid session" });
  }
};

async function startServer() {
  const app = express();
  const PORT = 3000;

  // 1. Core Middlewares
  app.use(cors({
    origin: true,
    credentials: true
  }));
  app.use(cookieParser());
  app.use(express.json()); // Removed request size limit

  // 3. API Routes
  
  // Login Route
  app.post("/api/auth/login", (req, res) => {
    const { email, password, role } = req.body;

    if (!email || !password) return res.status(400).json({ message: "Missing credentials" });

    const user = db.findUserByEmail(email);

    if (!user || user.role !== role || !bcrypt.compareSync(password, user.password)) {
      // Log failed attempt for security auditing
      console.warn(`Failed login attempt for ${email} as ${role}`);
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const token = jwt.sign(
      { id: user.id, role: user.role, name: user.name },
      JWT_SECRET,
      { expiresIn: "2h" }
    );

    res.cookie("token", token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      maxAge: 2 * 60 * 60 * 1000
    });

    res.json({ role: user.role, name: user.name, id: user.id });
  });

  // Logout Route
  app.post("/api/auth/logout", (req, res) => {
    res.clearCookie("token");
    res.json({ message: "Logged out safely" });
  });

  // Get Current User
  app.get("/api/auth/me", (req, res) => {
    const token = req.cookies.token;
    if (!token) return res.status(401).json({ message: "No session" });
    try {
      res.json(jwt.verify(token, JWT_SECRET));
    } catch (err) {
      res.status(401).json({ message: "Invalid session" });
    }
  });

  // Patient Routes (Secured)
  app.get("/api/patient/profile", authenticate, (req: any, res) => {
    if (req.user.role !== "patient") return res.status(403).json({ message: "Forbidden" });
    const profile = db.getPatientProfile(req.user.id);
    res.json(profile);
  });

  app.post("/api/patient/profile", authenticate, (req: any, res) => {
    if (req.user.role !== "patient") return res.status(403).json({ message: "Forbidden" });
    const updated = db.updatePatientProfile(req.user.id, req.body);
    res.json(updated);
  });

  app.get("/api/patient/transfers", authenticate, (req: any, res) => {
    if (req.user.role !== "patient") return res.status(403).json({ message: "Forbidden" });
    res.json(db.getTransfersForPatient(req.user.id));
  });

  app.post("/api/patient/transfers", authenticate, (req: any, res) => {
    if (req.user.role !== "patient") return res.status(403).json({ message: "Forbidden" });
    const { from, to, records } = req.body;
    const newTransfer = db.addTransfer({
      id: `TRN-${Math.random().toString(36).substr(2, 6).toUpperCase()}`,
      patientId: req.user.id,
      patientName: req.user.name,
      from, to, records,
      status: "Pending",
      date: new Date().toLocaleDateString("en-IN"),
    });
    res.json(newTransfer);
  });

  // Hospital Routes (Secured)
  app.get("/api/hospital/appointments", authenticate, (req: any, res) => {
    if (req.user.role !== "hospital") return res.status(403).json({ message: "Forbidden" });
    res.json(db.getAppointmentsForHospital(req.user.id));
  });

  app.get("/api/hospital/transfers", authenticate, (req: any, res) => {
    if (req.user.role !== "hospital") return res.status(403).json({ message: "Forbidden" });
    res.json(db.getTransfersForHospital(req.user.id, req.user.name));
  });

  app.get("/api/hospital/patients", authenticate, (req: any, res) => {
    if (req.user.role !== "hospital") return res.status(403).json({ message: "Forbidden" });
    res.json(db.getPatientsByHospital(req.user.id));
  });

  app.patch("/api/hospital/appointments/:id", authenticate, (req: any, res) => {
    if (req.user.role !== 'hospital') return res.status(403).json({ message: "Forbidden" });
    const updated = db.updateAppointmentStatus(req.params.id, req.body.status);
    res.json(updated);
  });

  app.patch("/api/hospital/transfers/:id", authenticate, (req: any, res) => {
    if (req.user.role !== 'hospital') return res.status(403).json({ message: "Forbidden" });
    const updated = db.updateTransferStatus(req.params.id, req.body.status);
    res.json(updated);
  });

  // Patient Endpoints
  app.get("/api/patient/profile", authenticate, (req: any, res) => {
    const profile = db.getPatientProfile(req.user.id);
    res.json(profile);
  });

  app.post("/api/patient/profile", authenticate, (req: any, res) => {
    const updated = db.updatePatientProfile(req.user.id, req.body);
    res.json(updated);
  });

  app.get("/api/patient/transfers", authenticate, (req: any, res) => {
    const transfers = db.getTransfersForPatient(req.user.id);
    res.json(transfers);
  });

  app.post("/api/patient/transfers", authenticate, (req: any, res) => {
    const newTransfer = db.addTransfer({
      id: 'TRN-' + Math.random().toString(36).substr(2, 6).toUpperCase(),
      patientId: req.user.id,
      patientName: req.user.name,
      from: req.body.from,
      to: req.body.to,
      records: req.body.records || 'General',
      status: 'Pending',
      date: new Date().toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' })
    });
    res.json(newTransfer);
  });

  app.post("/api/appointments", authenticate, (req: any, res) => {
    const appointment = db.addAppointment({
      id: 'APT-' + Math.floor(1000 + Math.random() * 9000),
      patientId: req.user.id,
      patientName: req.body.patientName || req.user.name,
      hospitalId: req.body.hospitalId,
      doctorName: req.body.doctorName,
      dept: req.body.dept,
      date: req.body.date,
      time: req.body.time,
      reason: req.body.reason || 'Consultation',
      status: 'Pending'
    });
    res.json(appointment);
  });

  // Gemini Proxy
  app.post("/api/ai/analyze", authenticate, async (req, res) => {
    const { message } = req.body;
    if (!GEMINI_API_KEY) return res.status(500).json({ message: "AI Service Unavailable" });

    try {
      const ai = new GoogleGenAI({ apiKey: GEMINI_API_KEY });
      const prompt = `You are a medical assistant for MediReach Karnataka. Analyze these symptoms briefly and give advice. Input: ${message}`;
      const result = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt
      });
      res.json({ analysis: result.text });
    } catch (error) {
      console.error("Gemini error:", error);
      res.status(500).json({ message: "Error processing analysis" });
    }
  });

  // 4. Vite / Static Files
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => res.sendFile(path.join(distPath, "index.html")));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
