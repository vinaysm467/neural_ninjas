import fs from 'fs';

const districts = ['Mysuru', 'Bengaluru Urban', 'Mandya', 'Hassan', 'Tumakuru', 'Chamarajanagar'];
const hospitals_per_district = 10;
const doctors_per_hospital = 5;

const specialties = [
  'Cardiology', 'Neurology', 'Oncology', 'Pediatrics', 'Orthopedics', 
  'Dermatology', 'Gastroenterology', 'Ophthalmology', 'ENT', 'Gynecology',
  'Pulmonology', 'Psychiatry', 'General Medicine', 'General Surgery', 'Endocrinology'
];

const medicine_categories = [
  { name: 'Analgesics', problem: 'Fever, Body pain, Headache' },
  { name: 'Antidiabetic', problem: 'Type 2 Diabetes' },
  { name: 'Antihypertensive', problem: 'High Blood Pressure' },
  { name: 'Cough Suppressant', problem: 'Cold and Cough' },
  { name: 'Antihistamine', problem: 'Allergy, Skin problems' },
  { name: 'Statin', problem: 'High Cholesterol' },
  { name: 'Anti-Asthmatic', problem: 'Asthma' },
  { name: 'Cardiac', problem: 'Heart problems' },
  { name: 'Skin Care', problem: 'Skin problems' }
];

const names = ['Amit', 'Rajesh', 'Suresh', 'Ananya', 'Meera', 'Rohan', 'Sneha', 'Vikram', 'Priya', 'Karthik', 'Sunita', 'Rahul', 'Aruna', 'Deepak', 'Geeta'];
const surnames = ['Kumar', 'Sharma', 'Patil', 'Iyer', 'Menon', 'Rao', 'Reddy', 'Gowda', 'Nayar', 'Joshi', 'Singh', 'Khan', 'Desai', 'Hegde', 'Saldanha'];

const hospital_names = [
  'LifeCare Hospital', 'Grace Medical Center', 'Unity Health', 'Sterling Hospital', 
  'Pacific Hospital', 'Noble Care', 'Sunrise Medicals', 'City General Hospital',
  'Green Valley Hospital', 'Sacred Heart'
];

const initial_hospitals = [
  {
    id: 'h1',
    name: 'JSS Hospital',
    district: 'Mysuru',
    area: 'Agrahara',
    type: 'Trust',
    address: 'Agrahara, Mysuru, Karnataka 570004',
    phone: '0821-2335555',
    email: 'info@jsshospital.in',
    website_url: 'https://jsshospital.in',
    facebook_url: 'https://facebook.com/jsshospital',
    twitter_url: 'https://twitter.com/jsshospital',
    maps_url: 'https://www.google.com/maps/search/JSS+Hospital+Mysuru',
    lat: 12.2965,
    lng: 76.6548,
    distance_km: 1.2,
    rating: 4.5,
    total_reviews: 1250,
    avg_fee: 300,
    beds: 1800,
    emergency: true,
    accreditation: ['NABH', 'NABL'],
    established: 1973,
    insurance_accepted: ['Star Health', 'Ayushman Bharat', 'Govt Schemes'],
    facilities: ['ICU', 'Pharmacy', 'Radiology'],
    specialties: ['General Medicine', 'Cardiology', 'Pediatrics', 'Orthopedics', 'Neurology']
  },
  {
    id: 'h2',
    name: 'Apollo BGS Hospital',
    district: 'Mysuru',
    area: 'Kuvempunagar',
    type: 'Private',
    address: 'Adhichunchanagiri Road, Kuvempunagar, Mysuru',
    phone: '0821-2568888',
    email: 'contact@apollobgs.com',
    website_url: 'https://apollobgs.com',
    facebook_url: '',
    twitter_url: '',
    maps_url: '',
    lat: 12.2858,
    lng: 76.6261,
    distance_km: 3.5,
    rating: 4.7,
    total_reviews: 800,
    avg_fee: 600,
    beds: 200,
    emergency: true,
    accreditation: ['NABH'],
    established: 2001,
    insurance_accepted: ['Star Health', 'Apollo Munich', 'Private Insurance'],
    facilities: ['ICU', 'Pharmacy'],
    specialties: ['Cardiology', 'Gastroenterology', 'Oncology']
  },
  {
    id: 'h3',
    name: 'Columbia Asia Hospital',
    district: 'Mysuru',
    area: 'Bannimantap',
    type: 'Private',
    address: 'Mysuru-Bengaluru Road, Bannimantap, Mysuru',
    phone: '0821-3989898',
    email: 'info@columbiaasia.com',
    website_url: 'https://columbiaasia.com',
    facebook_url: '',
    twitter_url: '',
    maps_url: '',
    lat: 12.3385,
    lng: 76.6615,
    distance_km: 4.8,
    rating: 4.6,
    total_reviews: 650,
    avg_fee: 750,
    beds: 100,
    emergency: true,
    accreditation: ['NABH'],
    established: 2008,
    insurance_accepted: ['ICICI Lombard', 'HDFC ERGO', 'Private Insurance'],
    facilities: ['ICU', 'Pharmacy'],
    specialties: ['ENT', 'Dermatology', 'Gynecology']
  },
  {
    id: 'h4',
    name: 'KR Hospital',
    district: 'Mysuru',
    area: 'Devaraja Mohalla',
    type: 'Government',
    address: 'Sayyaji Rao Road, Devaraja Mohalla, Mysuru',
    phone: '0821-2423223',
    email: 'contact@krhospital.com',
    website_url: '',
    facebook_url: '',
    twitter_url: '',
    maps_url: '',
    lat: 12.3138,
    lng: 76.6508,
    distance_km: 0.5,
    rating: 3.8,
    total_reviews: 2100,
    avg_fee: 0,
    beds: 1050,
    emergency: true,
    accreditation: [],
    established: 1924,
    insurance_accepted: ['Ayushman Bharat', 'Govt Schemes', 'Arogya Karnataka'],
    facilities: ['General Ward', 'OPD'],
    specialties: ['General Surgery', 'Orthopedics', 'Ophthalmology']
  }
];

const hospitals = [...initial_hospitals];
const doctors = [];
const ambulances = [];
let hospital_id_counter = 5;
let doctor_id_counter = 1;
let ambulance_id_counter = 1;

const ambulance_types = ['Basic', 'Advanced', 'ICU', 'Neonatal'];
const ambulance_service_names = ['Lifeline', 'QuickCare', 'MediPulse', 'SwiftResponse', 'SafeWay', 'EmergencyConnect'];

districts.forEach(district => {
  const districtHospitals = [];
  for (let i = 0; i < hospitals_per_district; i++) {
    const hospital_id = `h_gen_${hospital_id_counter++}`;
    const name = `${district} ${hospital_names[i % hospital_names.length]}`;
    const h_lat = district === 'Mysuru' ? 12.3 + Math.random() * 0.1 : 
                 district === 'Bengaluru Urban' ? 12.9 + Math.random() * 0.1 :
                 district === 'Mandya' ? 12.5 + Math.random() * 0.1 :
                 district === 'Hassan' ? 13.0 + Math.random() * 0.1 :
                 district === 'Tumakuru' ? 13.3 + Math.random() * 0.1 :
                 11.9 + Math.random() * 0.1;
    const h_lng = district === 'Mysuru' ? 76.6 + Math.random() * 0.1 : 
                 district === 'Bengaluru Urban' ? 77.5 + Math.random() * 0.1 :
                 district === 'Mandya' ? 76.8 + Math.random() * 0.1 :
                 district === 'Hassan' ? 76.1 + Math.random() * 0.1 :
                 district === 'Tumakuru' ? 77.1 + Math.random() * 0.1 :
                 76.9 + Math.random() * 0.1;

    const hospital = {
      id: hospital_id,
      name: name,
      district: district,
      area: `${district} Center`,
      type: i % 3 === 0 ? 'Government' : i % 3 === 1 ? 'Private' : 'Trust',
      address: `${i * 10} Main Road, ${district}`,
      phone: `080-${Math.floor(1000000 + Math.random() * 9000000)}`,
      email: `contact@${name.toLowerCase().replace(/ /g, '')}.com`,
      website_url: `https://${name.toLowerCase().replace(/ /g, '')}.com`,
      facebook_url: '',
      twitter_url: '',
      maps_url: '',
      lat: h_lat,
      lng: h_lng,
      distance_km: Math.random() * 10,
      rating: 3.5 + Math.random() * 1.5,
      total_reviews: Math.floor(100 + Math.random() * 2000),
      avg_fee: i % 3 === 0 ? 0 : 200 + Math.floor(Math.random() * 10) * 50,
      beds: 50 + Math.floor(Math.random() * 500),
      emergency: true,
      accreditation: i % 2 === 0 ? ['NABH'] : [],
      established: 1980 + Math.floor(Math.random() * 40),
      insurance_accepted: i % 2 === 0 ? ['Ayushman Bharat', 'Govt Schemes'] : ['Star Health', 'HDFC ERGO'],
      facilities: ['ICU', 'Pharmacy', 'Radiology'],
      specialties: [specialties[Math.floor(Math.random() * specialties.length)], specialties[Math.floor(Math.random() * specialties.length)]]
    };
    hospitals.push(hospital);
    districtHospitals.push(hospital);

    for (let j = 0; j < doctors_per_hospital; j++) {
      doctors.push({
        id: `d_gen_${doctor_id_counter++}`,
        name: `Dr. ${names[Math.floor(Math.random() * names.length)]} ${surnames[Math.floor(Math.random() * surnames.length)]}`,
        district: district,
        hospital_id: hospital_id,
        hospital_name: name,
        specialty: specialties[Math.floor(Math.random() * specialties.length)],
        qualification: 'MD',
        experience: 5 + Math.floor(Math.random() * 25),
        fee: 300 + Math.floor(Math.random() * 10) * 100,
        rating: 4 + Math.random(),
        review_count: Math.floor(Math.random() * 500),
        languages: ['Kannada', 'English'],
        availability: 'Mon-Sat: 10AM - 5PM',
        verified: true,
        phone: `9${Math.floor(100000000 + Math.random() * 900000000)}`,
        profile_summary: 'Specialist with years of experience.'
      });
    }
  }

  // Generate 5+ ambulances per district
  for (let k = 0; k < 6; k++) {
    const amb_lat = district === 'Mysuru' ? 12.25 + Math.random() * 0.1 : 
                 district === 'Bengaluru Urban' ? 12.92 + Math.random() * 0.1 :
                 district === 'Mandya' ? 12.5 + Math.random() * 0.1 :
                 district === 'Hassan' ? 13.0 + Math.random() * 0.1 :
                 district === 'Tumakuru' ? 13.3 + Math.random() * 0.1 :
                 11.9 + Math.random() * 0.1;
    const amb_lng = district === 'Mysuru' ? 76.6 + Math.random() * 0.1 : 
                 district === 'Bengaluru Urban' ? 77.55 + Math.random() * 0.1 :
                 district === 'Mandya' ? 76.85 + Math.random() * 0.1 :
                 district === 'Hassan' ? 76.05 + Math.random() * 0.1 :
                 district === 'Tumakuru' ? 77.15 + Math.random() * 0.1 :
                 76.95 + Math.random() * 0.1;

    const linked_h = districtHospitals[k % districtHospitals.length];

    ambulances.push({
      id: `amb_gen_${ambulance_id_counter++}`,
      name: `${district} ${ambulance_service_names[k % ambulance_service_names.length]} Ambulance`,
      district: district,
      area: linked_h ? linked_h.area : `${district} Center`,
      phone: `9${Math.floor(100000000 + Math.random() * 900000000)}`,
      type: ambulance_types[Math.floor(Math.random() * ambulance_types.length)],
      availability: '24/7',
      estimated_arrival: `${Math.floor(5 + Math.random() * 20)} mins`,
      distance_km: parseFloat((0.5 + Math.random() * 8).toFixed(1)),
      linked_hospital: linked_h ? linked_h.name : 'Independent',
      lat: amb_lat,
      lng: amb_lng,
      maps_route_url: `https://www.google.com/maps/dir/?api=1&destination=${amb_lat},${amb_lng}`
    });
  }
});

const medicines = [];
const medicine_prefixes = ['Z', 'X', 'A', 'M', 'P', 'V', 'L', 'O', 'C', 'G'];
const medicine_suffixes = ['flo', 'dex', 'met', 'pan', 'rin', 'ten', 'pril', 'stat', 'amol', 'cef'];

for (let i = 0; i < 1050; i++) {
  const category_obj = medicine_categories[i % medicine_categories.length];
  const prefix = medicine_prefixes[Math.floor(Math.random() * medicine_prefixes.length)];
  const suffix = medicine_suffixes[Math.floor(Math.random() * medicine_suffixes.length)];
  const brand = `${prefix}${suffix}-${Math.floor(5 + Math.random() * 500)}`;
  const generic_pair = [
    { brand: 'Dolo', generic: 'Paracetamol', price: 30 },
    { brand: 'Allegra', generic: 'Fexofenadine', price: 180 },
    { brand: 'Glycomet', generic: 'Metformin', price: 15 },
    { brand: 'Telma', generic: 'Telmisartan', price: 95 },
    { brand: 'Augmentin', generic: 'Amoxicillin', price: 220 },
    { brand: 'Amlokind', generic: 'Amlodipine', price: 25 },
    { brand: 'Rosuvas', generic: 'Rosuvastatin', price: 210 },
    { brand: 'Ascoril', generic: 'Ambroxol', price: 120 }
  ];
  const base = generic_pair[i % generic_pair.length];
  
  medicines.push({
    id: `m_gen_${i}`,
    brand_name: `${base.brand} ${Math.floor(Math.random() * 1000)}`,
    generic_name: base.generic,
    category: category_obj.name,
    problem: category_obj.problem,
    dosage_form: i % 5 === 0 ? 'Syrup' : 'Tablet',
    strength: i % 5 === 0 ? '100ml' : '500mg',
    brand_price: base.price + Math.floor(Math.random() * 50),
    generic_price: Math.floor(base.price * 0.2),
    savings_percent: 80,
    uses: `Used for ${category_obj.problem.toLowerCase()}.`,
    warning: 'Consult your doctor before use.',
    availability: true,
    jan_aushadhi_available: true
  });
}

const fileContent = `import { Hospital, Doctor, Medicine, Ambulance } from './types';

export const HOSPITALS: Hospital[] = ${JSON.stringify(hospitals, null, 2)};

export const DOCTORS: Doctor[] = ${JSON.stringify(doctors, null, 2)};

export const MEDICINES: Medicine[] = ${JSON.stringify(medicines, null, 2)};

export const AMBULANCES: Ambulance[] = ${JSON.stringify(ambulances, null, 2)};
`;

fs.writeFileSync('src/data.ts', fileContent);
console.log('Data generation complete!');
